enum TransactionType { recharge, callCharge, callEarning, withdrawal, bonus }

class WalletTransaction {
  final String title;
  final String subtitle;
  final double amount; // positive = credit, negative = debit
  final DateTime date;
  final TransactionType type;

  WalletTransaction({
    required this.title,
    required this.subtitle,
    required this.amount,
    required this.date,
    required this.type,
  });
}
