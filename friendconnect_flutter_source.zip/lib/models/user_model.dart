class UserProfile {
  final String id;
  final String name;
  final int age;
  final String language;
  final String country;
  final String city;
  final String gender; // 'male' or 'female'
  final int avatarColorIndex;
  final double rating;
  bool isOnline;
  final bool verified;

  UserProfile({
    required this.id,
    required this.name,
    required this.age,
    required this.language,
    required this.country,
    required this.city,
    required this.gender,
    required this.avatarColorIndex,
    this.rating = 4.8,
    this.isOnline = true,
    this.verified = true,
  });
}
