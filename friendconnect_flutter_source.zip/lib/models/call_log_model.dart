import 'user_model.dart';

enum CallType { audio, video }

enum CallOutcome { completed, missed, declined }

class CallLogEntry {
  final UserProfile peer;
  final CallType type;
  final CallOutcome outcome;
  final int durationSeconds;
  final double charge;
  final DateTime timestamp;
  final bool wasCaller;
  int? rating;

  CallLogEntry({
    required this.peer,
    required this.type,
    required this.outcome,
    required this.durationSeconds,
    required this.charge,
    required this.timestamp,
    this.wasCaller = true,
    this.rating,
  });
}
