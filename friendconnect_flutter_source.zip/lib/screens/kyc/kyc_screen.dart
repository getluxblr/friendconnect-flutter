import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/pill_button.dart';

/// KYC document upload — required from EVERY user (not just female) before
/// they can make or receive calls. Documents are uploaded to Firebase
/// Storage and a Firestore doc is created with status: 'pending' — the
/// telecalling team reviews and flips it to verified/rejected manually from
/// the CRM. If nobody reviews it within 12 hours, it auto-approves itself
/// (see AppState._maybeAutoApproveKyc).
class KycScreen extends StatefulWidget {
  const KycScreen({super.key});

  @override
  State<KycScreen> createState() => _KycScreenState();
}

class _KycScreenState extends State<KycScreen> {
  File? _aadharFront;
  File? _aadharBack;
  File? _panCard;
  File? _selfie;
  final _picker = ImagePicker();

  Future<void> _pick(void Function(File) onPicked) async {
    final xfile = await _picker.pickImage(source: ImageSource.camera, imageQuality: 80);
    if (xfile != null) {
      setState(() => onPicked(File(xfile.path)));
    }
  }

  Future<void> _submit() async {
    if (_aadharFront == null || _aadharBack == null || _panCard == null || _selfie == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please add all four photos: Aadhaar front, Aadhaar back, PAN card, and a selfie')),
      );
      return;
    }
    final state = context.read<AppState>();
    final ok = await state.submitKyc(
      aadharFront: _aadharFront!,
      aadharBack: _aadharBack!,
      panCard: _panCard!,
      selfie: _selfie!,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          ok
              ? 'Submitted! Verification pending — our team will review within ${AppState.kycAutoApproveAfter.inHours} hours, or it will be auto-approved.'
              : (state.kycError ?? 'Upload failed. Please try again.'),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('KYC Documents', style: TextStyle(color: AppColors.textMain, fontWeight: FontWeight.w800)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textMain),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _statusBanner(state.kycStatus),
              const SizedBox(height: 18),
              const Text(
                'KYC is required for every user before you can make or receive calls. Upload your Aadhaar card (front & back), PAN card, and a selfie for manual verification.',
                style: TextStyle(fontSize: 13, color: AppColors.textDim),
              ),
              const SizedBox(height: 22),
              _photoTile('Aadhaar Card — Front', _aadharFront, () => _pick((f) => _aadharFront = f)),
              const SizedBox(height: 14),
              _photoTile('Aadhaar Card — Back', _aadharBack, () => _pick((f) => _aadharBack = f)),
              const SizedBox(height: 14),
              _photoTile('PAN Card', _panCard, () => _pick((f) => _panCard = f)),
              const SizedBox(height: 14),
              _photoTile('Selfie', _selfie, () => _pick((f) => _selfie = f)),
              const SizedBox(height: 26),
              PillButton(
                label: state.kycUploading ? 'Uploading…' : 'Submit for Verification',
                onTap: state.kycUploading ? null : _submit,
              ),
              const SizedBox(height: 10),
              Text(
                'Verified manually by our team · Working hours ${AppState.workingHours}',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 10.5, color: AppColors.textDim2),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statusBanner(String status) {
    late Color color;
    late String label;
    late IconData icon;
    switch (status) {
      case 'pending':
        color = const Color(0xFFF59E0B);
        label = 'Verification pending — our team will review within 12 hours';
        icon = Icons.hourglass_top_rounded;
        break;
      case 'verified':
        color = AppColors.green;
        label = 'Verified ✓ — you can make and receive calls';
        icon = Icons.verified_rounded;
        break;
      case 'rejected':
        color = const Color(0xFFF87171);
        label = 'Rejected — please re-upload clear photos';
        icon = Icons.error_rounded;
        break;
      default:
        color = AppColors.textDim2;
        label = 'Not submitted yet — required before you can call or be called';
        icon = Icons.badge_rounded;
    }
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(14)),
      child: Row(
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: color))),
        ],
      ),
    );
  }

  Widget _photoTile(String label, File? file, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 110,
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.divider, width: 1.5),
          image: file != null ? DecorationImage(image: FileImage(file), fit: BoxFit.cover) : null,
        ),
        alignment: Alignment.center,
        child: file == null
            ? Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.camera_alt_rounded, color: AppColors.textDim2, size: 22),
                  const SizedBox(height: 6),
                  Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textDim)),
                ],
              )
            : Align(
                alignment: Alignment.topRight,
                child: Container(
                  margin: const EdgeInsets.all(6),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.55), borderRadius: BorderRadius.circular(20)),
                  child: const Text('Retake', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
                ),
              ),
      ),
    );
  }
}
