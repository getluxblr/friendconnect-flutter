import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/pill_button.dart';

enum _Method { bank, upi }

/// Collects payout details (bank account or UPI) before raising a
/// withdrawal request. On submit this creates a ticket the ops team
/// processes manually — mirroring how wallet recharge requests work.
class WithdrawScreen extends StatefulWidget {
  const WithdrawScreen({super.key});

  @override
  State<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends State<WithdrawScreen> {
  _Method _method = _Method.bank;
  bool _submitting = false;

  final _amountController = TextEditingController();
  final _accountHolderController = TextEditingController();
  final _accountNumberController = TextEditingController();
  final _accountNumberConfirmController = TextEditingController();
  final _ifscController = TextEditingController();
  final _branchController = TextEditingController();
  final _upiIdController = TextEditingController();
  final _upiNameController = TextEditingController();

  @override
  void initState() {
    super.initState();
    final state = context.read<AppState>();
    _amountController.text = state.lifetimeEarnings.clamp(0, double.infinity) >= 500 ? state.lifetimeEarnings.toStringAsFixed(0) : '500';
  }

  @override
  void dispose() {
    _amountController.dispose();
    _accountHolderController.dispose();
    _accountNumberController.dispose();
    _accountNumberConfirmController.dispose();
    _ifscController.dispose();
    _branchController.dispose();
    _upiIdController.dispose();
    _upiNameController.dispose();
    super.dispose();
  }

  Future<void> _showResultDialog({required bool success, required String title, required String message}) {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // close dialog
              if (success) Navigator.of(context).pop(); // close withdraw screen
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> _submit() async {
    final amount = double.tryParse(_amountController.text.trim());
    if (amount == null || amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid amount')));
      return;
    }

    Map<String, String> details;
    String destinationLabel;
    if (_method == _Method.bank) {
      if (_accountHolderController.text.trim().isEmpty ||
          _accountNumberController.text.trim().isEmpty ||
          _ifscController.text.trim().isEmpty ||
          _branchController.text.trim().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill in all bank details')));
        return;
      }
      if (_accountNumberController.text.trim() != _accountNumberConfirmController.text.trim()) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Account numbers do not match')));
        return;
      }
      details = {
        'accountHolderName': _accountHolderController.text.trim(),
        'accountNumber': _accountNumberController.text.trim(),
        'ifsc': _ifscController.text.trim().toUpperCase(),
        'branch': _branchController.text.trim(),
      };
      final acc = _accountNumberController.text.trim();
      final last4 = acc.length > 4 ? acc.substring(acc.length - 4) : acc;
      destinationLabel = 'your account ending in $last4';
    } else {
      if (_upiIdController.text.trim().isEmpty || _upiNameController.text.trim().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill in your UPI ID and name')));
        return;
      }
      details = {
        'upiId': _upiIdController.text.trim(),
        'name': _upiNameController.text.trim(),
      };
      destinationLabel = 'your UPI ID (${_upiIdController.text.trim()})';
    }

    setState(() => _submitting = true);
    final state = context.read<AppState>();
    final ok = await state.requestWithdrawal(
      amount: amount,
      method: _method == _Method.bank ? 'bank' : 'upi',
      details: details,
    );
    if (!mounted) return;
    setState(() => _submitting = false);

    if (ok) {
      await _showResultDialog(
        success: true,
        title: '🎉 Congratulations!',
        message: 'Your withdrawal request for ₹${amount.toStringAsFixed(0)} has been raised successfully. The amount will be credited within 04:00 hours to $destinationLabel.',
      );
    } else {
      final err = state.lastWithdrawalError ?? 'Your request could not be processed.';
      final rejected = err.toLowerCase().contains('insufficient');
      await _showResultDialog(
        success: false,
        title: rejected ? 'Rejected' : 'Cannot withdraw',
        message: err,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Withdraw', style: TextStyle(color: AppColors.textMain, fontWeight: FontWeight.w800)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textMain),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.divider)),
                child: Row(
                  children: [
                    const Icon(Icons.account_balance_wallet_rounded, size: 18, color: AppColors.accent2),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Available balance: ₹${state.lifetimeEarnings.toStringAsFixed(0)} · Min. withdrawal ₹500 · Processed ${AppState.workingHours}',
                        style: const TextStyle(fontSize: 11.5, color: AppColors.textDim2),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const Text('AMOUNT', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              _field(_amountController, hint: 'Amount to withdraw', keyboardType: TextInputType.number),
              const SizedBox(height: 24),
              const Text('WITHDRAW TO', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _methodCard(_Method.bank, '🏦', 'Bank Account')),
                  const SizedBox(width: 12),
                  Expanded(child: _methodCard(_Method.upi, '📱', 'UPI')),
                ],
              ),
              const SizedBox(height: 22),
              if (_method == _Method.bank) ..._bankFields() else ..._upiFields(),
              const SizedBox(height: 26),
              PillButton(
                label: _submitting ? 'Submitting…' : 'Submit Withdrawal Request',
                onTap: _submitting ? null : _submit,
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _bankFields() {
    return [
      const Text('ACCOUNT HOLDER NAME', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
      const SizedBox(height: 8),
      _field(_accountHolderController, hint: 'As per bank records'),
      const SizedBox(height: 16),
      const Text('ACCOUNT NUMBER', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
      const SizedBox(height: 8),
      _field(_accountNumberController, hint: 'Account number', keyboardType: TextInputType.number),
      const SizedBox(height: 16),
      const Text('RE-ENTER ACCOUNT NUMBER', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
      const SizedBox(height: 8),
      _field(_accountNumberConfirmController, hint: 'Confirm account number', keyboardType: TextInputType.number),
      const SizedBox(height: 16),
      const Text('IFSC CODE', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
      const SizedBox(height: 8),
      _field(_ifscController, hint: 'e.g. HDFC0001234', keyboardType: TextInputType.text),
      const SizedBox(height: 16),
      const Text('BRANCH', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
      const SizedBox(height: 8),
      _field(_branchController, hint: 'Branch name'),
    ];
  }

  List<Widget> _upiFields() {
    return [
      const Text('UPI ID', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
      const SizedBox(height: 8),
      _field(_upiIdController, hint: 'yourname@upi'),
      const SizedBox(height: 16),
      const Text('NAME', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
      const SizedBox(height: 8),
      _field(_upiNameController, hint: 'As per bank records'),
    ];
  }

  Widget _methodCard(_Method method, String emoji, String title) {
    final selected = _method == method;
    return GestureDetector(
      onTap: () => setState(() => _method = method),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: selected ? AppColors.accent1.withOpacity(0.08) : AppColors.bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: selected ? AppColors.accent1 : AppColors.divider, width: 1.5),
        ),
        child: Column(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 6),
            Text(title, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: AppColors.textMain)),
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, {required String hint, TextInputType? keyboardType}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.divider, width: 1.5),
      ),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        style: const TextStyle(color: AppColors.textMain, fontSize: 14),
        decoration: InputDecoration(
          border: InputBorder.none,
          isDense: true,
          hintText: hint,
          hintStyle: const TextStyle(color: AppColors.textDim2, fontSize: 13),
          contentPadding: const EdgeInsets.symmetric(vertical: 16),
        ),
      ),
    );
  }
}
