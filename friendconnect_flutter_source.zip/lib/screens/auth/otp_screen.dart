import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/pill_button.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({super.key});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  UserRole _selectedRole = UserRole.male;
  final _codeController = TextEditingController();
  final _nameController = TextEditingController();
  DateTime? _dob;
  bool _verifying = false;

  @override
  void dispose() {
    _codeController.dispose();
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _pickDob() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime(now.year - 18, now.month, now.day),
      firstDate: DateTime(now.year - 100),
      lastDate: now,
      helpText: 'Date of birth (as per your documents)',
    );
    if (picked != null) setState(() => _dob = picked);
  }

  Future<void> _showBlockedDialog(String message) {
    return showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Cannot continue'),
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('OK')),
        ],
      ),
    );
  }

  Future<void> _verify() async {
    final code = _codeController.text.trim();
    if (code.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter the 6-digit code sent to your phone')),
      );
      return;
    }
    // Pre-check the DOB client-side so we can show a clear popup before ever
    // hitting the network — the server-side check in AppState.verifyOtp is
    // a second line of defense.
    final ageError = AppState.ageValidationError(_dob);
    if (ageError != null) {
      await _showBlockedDialog(ageError);
      return;
    }
    setState(() => _verifying = true);
    final state = context.read<AppState>();
    final ok = await state.verifyOtp(code, _selectedRole, _nameController.text, _dob);
    if (!mounted) return;
    setState(() => _verifying = false);
    if (ok) {
      Navigator.of(context).popUntil((route) => route.isFirst);
    } else if (state.authError != null && state.authError!.contains('18')) {
      await _showBlockedDialog(state.authError!);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(state.authError ?? 'Invalid code. Please try again.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40),
              const Text('Verify your number', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textMain)),
              const SizedBox(height: 6),
              Text('Real SMS code sent to +91 ${state.phoneNumber}', style: const TextStyle(fontSize: 13, color: AppColors.textDim)),
              const SizedBox(height: 24),
              const Text('ENTER 6-DIGIT CODE', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: AppColors.bgCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.divider, width: 1.5),
                ),
                child: TextField(
                  controller: _codeController,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  style: const TextStyle(color: AppColors.textMain, fontSize: 20, fontWeight: FontWeight.w700, letterSpacing: 6),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    counterText: '',
                    isDense: true,
                    hintText: '••••••',
                    contentPadding: EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text('YOUR NAME', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: AppColors.bgCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.divider, width: 1.5),
                ),
                child: TextField(
                  controller: _nameController,
                  style: const TextStyle(color: AppColors.textMain, fontSize: 15),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    isDense: true,
                    hintText: 'This is what others will see',
                    hintStyle: TextStyle(color: AppColors.textDim2, fontSize: 13),
                    contentPadding: EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text('DATE OF BIRTH (AS PER DOCUMENTS)', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              InkWell(
                onTap: _pickDob,
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  decoration: BoxDecoration(
                    color: AppColors.bgCard,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.divider, width: 1.5),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.calendar_today_rounded, size: 16, color: AppColors.textDim2),
                      const SizedBox(width: 10),
                      Text(
                        _dob == null ? 'Tap to select your date of birth' : '${_dob!.day.toString().padLeft(2, '0')}/${_dob!.month.toString().padLeft(2, '0')}/${_dob!.year}',
                        style: TextStyle(color: _dob == null ? AppColors.textDim2 : AppColors.textMain, fontSize: 14, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 4),
              const Text('You must be 18+ to use FriendConnect.', style: TextStyle(fontSize: 10.5, color: AppColors.textDim2)),
              const SizedBox(height: 30),
              const Text('I AM JOINING AS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _roleCard(UserRole.male, '🙋‍♂️', 'Male', 'Recharge & Call')),
                  const SizedBox(width: 12),
                  Expanded(child: _roleCard(UserRole.female, '🙋‍♀️', 'Female', 'Verify & Earn')),
                ],
              ),
              const SizedBox(height: 30),
              PillButton(
                label: _verifying ? 'Verifying…' : 'Verify & Continue',
                onTap: _verifying ? null : _verify,
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _roleCard(UserRole role, String emoji, String title, String subtitle) {
    final selected = _selectedRole == role;
    return GestureDetector(
      onTap: () => setState(() => _selectedRole = role),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: selected ? AppColors.accent1.withOpacity(0.08) : AppColors.bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: selected ? AppColors.accent1 : AppColors.divider, width: 1.5),
        ),
        child: Column(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 26)),
            const SizedBox(height: 6),
            Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textMain)),
            Text(subtitle, style: const TextStyle(fontSize: 10, color: AppColors.textDim2)),
          ],
        ),
      ),
    );
  }
}
