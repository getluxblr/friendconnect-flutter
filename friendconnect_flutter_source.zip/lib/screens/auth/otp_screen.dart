import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/pill_button.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({super.key});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  UserRole _selectedRole = UserRole.male;
  final _codeController = TextEditingController();
  final _nameController = TextEditingController();
  bool _verifying = false;

  @override
  void dispose() {
    _codeController.dispose();
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    final code = _codeController.text.trim();
    if (code.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter the 6-digit code sent to your phone')),
      );
      return;
    }
    setState(() => _verifying = true);
    final state = context.read<AppState>();
    final ok = await state.verifyOtp(code, _selectedRole, _nameController.text);
    if (!mounted) return;
    setState(() => _verifying = false);
    if (ok) {
      Navigator.of(context).popUntil((route) => route.isFirst);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(state.authError ?? 'Invalid code. Please try again.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40),
              const Text('Verify your number', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textMain)),
              const SizedBox(height: 6),
              Text('Real SMS code sent to +91 ${state.phoneNumber}', style: const TextStyle(fontSize: 13, color: AppColors.textDim)),
              const SizedBox(height: 24),
              const Text('ENTER 6-DIGIT CODE', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: AppColors.bgCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.divider, width: 1.5),
                ),
                child: TextField(
                  controller: _codeController,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  style: const TextStyle(color: AppColors.textMain, fontSize: 20, fontWeight: FontWeight.w700, letterSpacing: 6),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    counterText: '',
                    isDense: true,
                    hintText: '••••••',
                    contentPadding: EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text('YOUR NAME', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: AppColors.bgCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.divider, width: 1.5),
                ),
                child: TextField(
                  controller: _nameController,
                  style: const TextStyle(color: AppColors.textMain, fontSize: 15),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    isDense: true,
                    hintText: 'This is what others will see',
                    hintStyle: TextStyle(color: AppColors.textDim2, fontSize: 13),
                    contentPadding: EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              const SizedBox(height: 30),
              const Text('I AM JOINING AS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _roleCard(UserRole.male, '🙋‍♂️', 'Male', 'Recharge & Call')),
                  const SizedBox(width: 12),
                  Expanded(child: _roleCard(UserRole.female, '🙋‍♀️', 'Female', 'Verify & Earn')),
                ],
              ),
              const SizedBox(height: 30),
              PillButton(
                label: _verifying ? 'Verifying…' : 'Verify & Continue',
                onTap: _verifying ? null : _verify,
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _roleCard(UserRole role, String emoji, String title, String subtitle) {
    final selected = _selectedRole == role;
    return GestureDetector(
      onTap: () => setState(() => _selectedRole = role),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: selected ? AppColors.accent1.withOpacity(0.08) : AppColors.bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: selected ? AppColors.accent1 : AppColors.divider, width: 1.5),
        ),
        child: Column(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 26)),
            const SizedBox(height: 6),
            Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textMain)),
            Text(subtitle, style: const TextStyle(fontSize: 10, color: AppColors.textDim2)),
          ],
        ),
      ),
    );
  }
}
