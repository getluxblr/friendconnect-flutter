import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/pill_button.dart';

/// Shown once, right after a brand-new Google or Email sign-up, to collect
/// the display name + role that the Phone OTP flow already asks for on its
/// own screen. Existing users never see this — they go straight in.
class CompleteProfileScreen extends StatefulWidget {
  const CompleteProfileScreen({super.key});

  @override
  State<CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends State<CompleteProfileScreen> {
  UserRole _selectedRole = UserRole.male;
  final _nameController = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    setState(() => _saving = true);
    final state = context.read<AppState>();
    await state.completeProfile(_nameController.text, _selectedRole);
    if (!mounted) return;
    Navigator.of(context).popUntil((route) => route.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40),
              const Text('Almost there', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textMain)),
              const SizedBox(height: 6),
              const Text('Just need your name and how you\'ll use FriendConnect.', style: TextStyle(fontSize: 13, color: AppColors.textDim)),
              const SizedBox(height: 24),
              const Text('YOUR NAME', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: AppColors.bgCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.divider, width: 1.5),
                ),
                child: TextField(
                  controller: _nameController,
                  style: const TextStyle(color: AppColors.textMain, fontSize: 15),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    isDense: true,
                    hintText: 'This is what others will see',
                    hintStyle: TextStyle(color: AppColors.textDim2, fontSize: 13),
                    contentPadding: EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              const SizedBox(height: 30),
              const Text('I AM JOINING AS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _roleCard(UserRole.male, '🙋‍♂️', 'Male', 'Recharge & Call')),
                  const SizedBox(width: 12),
                  Expanded(child: _roleCard(UserRole.female, '🙋‍♀️', 'Female', 'Verify & Earn')),
                ],
              ),
              const SizedBox(height: 30),
              PillButton(
                label: _saving ? 'Saving…' : 'Continue',
                onTap: _saving ? null : _finish,
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _roleCard(UserRole role, String emoji, String title, String subtitle) {
    final selected = _selectedRole == role;
    return GestureDetector(
      onTap: () => setState(() => _selectedRole = role),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: selected ? AppColors.accent1.withOpacity(0.08) : AppColors.bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: selected ? AppColors.accent1 : AppColors.divider, width: 1.5),
        ),
        child: Column(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 26)),
            const SizedBox(height: 6),
            Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textMain)),
            Text(subtitle, style: const TextStyle(fontSize: 10, color: AppColors.textDim2)),
          ],
        ),
      ),
    );
  }
}
