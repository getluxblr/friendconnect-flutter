import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/pill_button.dart';
import 'otp_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _controller = TextEditingController();
  bool _sending = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _sendOtp() async {
    final phone = _controller.text.trim();
    final digits = phone.replaceAll(RegExp(r'\D'), '');
    if (digits.length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a valid 10-digit mobile number')),
      );
      return;
    }
    setState(() => _sending = true);
    final state = context.read<AppState>();
    final verificationId = await state.sendOtp(phone);
    if (!mounted) return;
    setState(() => _sending = false);
    if (verificationId != null) {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => const OtpScreen()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(state.authError ?? 'Could not send OTP. Please try again.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 60),
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [AppColors.accent1, AppColors.accent2]),
                  borderRadius: BorderRadius.circular(22),
                ),
                alignment: Alignment.center,
                child: const Icon(Icons.call_rounded, color: Colors.white, size: 32),
              ),
              const SizedBox(height: 20),
              const Text(
                'Welcome to\nFriendConnect',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: AppColors.textMain, height: 1.25),
              ),
              const SizedBox(height: 8),
              const Text(
                'Talk. Connect. Earn. Real people,\nreal conversations.',
                style: TextStyle(fontSize: 13, color: AppColors.textDim),
              ),
              const SizedBox(height: 34),
              const Text('MOBILE NUMBER', style: TextStyle(fontSize: 12, color: AppColors.textDim, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: AppColors.bgCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppColors.divider, width: 1.5),
                ),
                child: Row(
                  children: [
                    const Text('🇮🇳 +91', style: TextStyle(color: AppColors.textMain, fontSize: 15)),
                    const SizedBox(width: 10),
                    Container(width: 1, height: 18, color: AppColors.divider),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        keyboardType: TextInputType.phone,
                        style: const TextStyle(color: AppColors.textMain, fontSize: 15),
                        decoration: const InputDecoration(border: InputBorder.none, isDense: true, contentPadding: EdgeInsets.symmetric(vertical: 16)),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 26),
              PillButton(
                label: _sending ? 'Sending OTP…' : 'Send OTP',
                onTap: _sending ? null : _sendOtp,
              ),
              const SizedBox(height: 16),
              const Text(
                'By continuing you agree to our\nTerms of Service & Privacy Policy',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 10.5, color: AppColors.textDim2, height: 1.5),
              ),
              const Spacer(),
              Row(
                children: const [
                  Expanded(child: Divider(color: AppColors.divider)),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text('secured by Firebase Auth', style: TextStyle(fontSize: 11, color: AppColors.textDim2)),
                  ),
                  Expanded(child: Divider(color: AppColors.divider)),
                ],
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
