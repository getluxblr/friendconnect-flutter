import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/pill_button.dart';
import 'complete_profile_screen.dart';

class EmailLoginScreen extends StatefulWidget {
  const EmailLoginScreen({super.key});

  @override
  State<EmailLoginScreen> createState() => _EmailLoginScreenState();
}

class _EmailLoginScreenState extends State<EmailLoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isSignUp = false;
  bool _busy = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text;
    if (email.isEmpty || !email.contains('@')) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid email address')));
      return;
    }
    if (password.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Password must be at least 6 characters')));
      return;
    }
    setState(() => _busy = true);
    final state = context.read<AppState>();
    // For sign-up, `ok` is a pure success/failure flag. For sign-in,
    // `signInWithEmail` returns whether an existing Firestore profile was
    // found — a valid login with NO profile yet returns false even though
    // authentication itself succeeded. So success must be judged from
    // firebaseUser/authError, not from `ok` directly.
    final ok = _isSignUp ? await state.signUpWithEmail(email, password) : await state.signInWithEmail(email, password);
    if (!mounted) return;
    setState(() => _busy = false);
    final authSucceeded = state.firebaseUser != null && state.authError == null;
    if (!authSucceeded) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(state.authError ?? 'Something went wrong. Please try again.')));
      return;
    }
    // Sign-up always needs the profile-completion step. For sign-in, `ok`
    // tells us whether an existing profile was found — if not, this account
    // authenticated but never finished onboarding, so send it there too.
    if (_isSignUp || !ok) {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CompleteProfileScreen()));
    } else {
      Navigator.of(context).popUntil((route) => route.isFirst);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40),
              IconButton(
                padding: EdgeInsets.zero,
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.arrow_back_rounded, color: AppColors.textMain),
              ),
              const SizedBox(height: 8),
              Text(
                _isSignUp ? 'Create your account' : 'Log in with email',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textMain),
              ),
              const SizedBox(height: 24),
              const Text('EMAIL', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              _field(_emailController, hint: 'you@example.com', keyboardType: TextInputType.emailAddress),
              const SizedBox(height: 20),
              const Text('PASSWORD', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textDim, letterSpacing: 0.5)),
              const SizedBox(height: 10),
              _field(_passwordController, hint: 'At least 6 characters', obscure: true),
              const SizedBox(height: 26),
              PillButton(
                label: _busy ? 'Please wait…' : (_isSignUp ? 'Create Account' : 'Log In'),
                onTap: _busy ? null : _submit,
              ),
              const SizedBox(height: 16),
              Center(
                child: TextButton(
                  onPressed: _busy ? null : () => setState(() => _isSignUp = !_isSignUp),
                  child: Text(
                    _isSignUp ? 'Already have an account? Log in' : 'New here? Create an account',
                    style: const TextStyle(color: AppColors.accent2, fontSize: 13, fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, {required String hint, bool obscure = false, TextInputType? keyboardType}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.divider, width: 1.5),
      ),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        keyboardType: keyboardType,
        style: const TextStyle(color: AppColors.textMain, fontSize: 15),
        decoration: InputDecoration(
          border: InputBorder.none,
          isDense: true,
          hintText: hint,
          hintStyle: const TextStyle(color: AppColors.textDim2, fontSize: 13),
          contentPadding: const EdgeInsets.symmetric(vertical: 16),
        ),
      ),
    );
  }
}
