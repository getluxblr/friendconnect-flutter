import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/section_title.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  int _selected = 1;
  bool _requesting = false;
  final _amounts = [100.0, 500.0, 1000.0];
  final _bonuses = [0.0, 50.0, 150.0];

  Future<void> _requestRecharge() async {
    final state = context.read<AppState>();
    setState(() => _requesting = true);
    final amount = _amounts[_selected];
    final ok = await state.requestRecharge(amount);
    if (!mounted) return;
    setState(() => _requesting = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          ok
              ? 'Request raised for ₹${amount.toStringAsFixed(0)}. Our team will call you to complete payment within ${AppState.paymentTat} (${AppState.workingHours}).'
              : 'Could not raise the request. Please try again.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          const Text('Wallet', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textMain)),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [AppColors.accent2, AppColors.accent1]), borderRadius: BorderRadius.circular(22)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('CURRENT BALANCE', style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Text('₹ ${state.walletBalance.toStringAsFixed(2)}', style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(
                  '≈ ${(state.walletBalance / AppState.callRatePerMinute).floor()} minutes of calling · ₹${AppState.callRatePerMinute.toStringAsFixed(0)}/min',
                  style: const TextStyle(color: Colors.white70, fontSize: 11),
                ),
              ],
            ),
          ),
          const SectionTitle('Recharge Wallet'),
          Row(
            children: List.generate(3, (i) {
              final selected = _selected == i;
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _selected = i),
                  child: Container(
                    margin: EdgeInsets.only(right: i < 2 ? 8 : 0),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color: selected ? AppColors.accent1.withOpacity(0.1) : AppColors.bgCard,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: selected ? AppColors.accent1 : AppColors.divider, width: 1.5),
                    ),
                    child: Column(
                      children: [
                        Text('₹${_amounts[i].toStringAsFixed(0)}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.textMain)),
                        if (_bonuses[i] > 0) ...[
                          const SizedBox(height: 2),
                          Text('+ ₹${_bonuses[i].toStringAsFixed(0)} bonus', style: const TextStyle(fontSize: 9, color: AppColors.green, fontWeight: FontWeight.w700)),
                        ],
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 14),
          Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: _requesting ? null : _requestRecharge,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 15),
                decoration: BoxDecoration(gradient: const LinearGradient(colors: [AppColors.accent1, AppColors.accent2]), borderRadius: BorderRadius.circular(16)),
                alignment: Alignment.center,
                child: Text(
                  _requesting ? 'Raising request…' : 'Raise Recharge Request · ₹${_amounts[_selected].toStringAsFixed(0)}',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.divider)),
            child: Row(
              children: [
                const Icon(Icons.support_agent_rounded, size: 18, color: AppColors.accent2),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'You can raise a recharge request any time, 24/7. Our team calls you to complete payment during working hours (${AppState.workingHours}) · Payment TAT: ${AppState.paymentTat}.',
                    style: const TextStyle(fontSize: 11, color: AppColors.textDim2),
                  ),
                ),
              ],
            ),
          ),
          if (state.rechargeTicketRaised) ...[
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(color: AppColors.green.withOpacity(0.12), borderRadius: BorderRadius.circular(14)),
              child: Text(
                'Request pending for ₹${state.lastRechargeRequestAmount.toStringAsFixed(0)} — we\'ll call you shortly.',
                style: const TextStyle(fontSize: 11.5, color: AppColors.green, fontWeight: FontWeight.w700),
              ),
            ),
          ],
          const SectionTitle('Recent Transactions'),
          ...state.transactions.map(
            (tx) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 9),
              child: Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(color: (tx.amount >= 0 ? AppColors.green : AppColors.red).withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
                    alignment: Alignment.center,
                    child: Icon(tx.amount >= 0 ? Icons.arrow_downward_rounded : Icons.call_rounded, size: 16, color: tx.amount >= 0 ? AppColors.green : AppColors.red),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tx.title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textMain)),
                        Text(tx.subtitle, style: const TextStyle(fontSize: 10.5, color: AppColors.textDim2)),
                      ],
                    ),
                  ),
                  Text(
                    '${tx.amount >= 0 ? '+' : '−'}₹${tx.amount.abs().toStringAsFixed(0)}',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: tx.amount >= 0 ? AppColors.green : const Color(0xFFF87171)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
