import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/avatar_circle.dart';

class OnlineListScreen extends StatelessWidget {
  const OnlineListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final users = state.onlineUsers.where((u) => u.isOnline).toList();
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Online Now', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textMain)),
            const SizedBox(height: 4),
            Text('${users.length} people online', style: const TextStyle(fontSize: 12, color: AppColors.textDim2)),
            const SizedBox(height: 14),
            Expanded(
              child: ListView.separated(
                itemCount: users.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, i) {
                  final u = users[i];
                  return Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.divider)),
                    child: Row(
                      children: [
                        AvatarCircle(initial: u.name.substring(0, 1), colorIndex: u.avatarColorIndex, gender: u.gender, size: 52, fontSize: 20),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${u.name}, ${u.age}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textMain)),
                              Text('🌐 ${u.language} · ${u.city}', style: const TextStyle(fontSize: 11, color: AppColors.textDim2)),
                            ],
                          ),
                        ),
                        Container(width: 10, height: 10, decoration: const BoxDecoration(color: AppColors.green, shape: BoxShape.circle)),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
