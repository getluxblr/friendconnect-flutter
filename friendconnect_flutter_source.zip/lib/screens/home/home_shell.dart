import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import 'browse_screen.dart';
import 'online_list_screen.dart';
import '../wallet/wallet_screen.dart';
import '../earnings/earnings_screen.dart';
import '../history/call_history_screen.dart';
import '../profile/profile_screen.dart';
import '../call/incoming_call_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  bool _showingWithdrawalNotice = false;
  String? _shownIncomingCallSessionId;

  Future<void> _showWithdrawalNotice(BuildContext context, AppState state, Map<String, dynamic> notice) async {
    if (_showingWithdrawalNotice) return;
    _showingWithdrawalNotice = true;
    final status = notice['status'] as String? ?? '';
    final amount = (notice['amount'] as num?)?.toDouble() ?? 0;
    final approved = status == 'paid';
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Text(approved ? '🎉 Congratulations!' : 'Withdrawal Rejected'),
        content: Text(
          approved
              ? 'Your withdrawal request for ₹${amount.toStringAsFixed(0)} has been approved and credited.'
              : 'Your withdrawal request for ₹${amount.toStringAsFixed(0)} was rejected due to insufficient funds.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('OK')),
        ],
      ),
    );
    state.clearWithdrawalNotice();
    _showingWithdrawalNotice = false;
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    if (appState.withdrawalNotice != null) {
      final notice = appState.withdrawalNotice!;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _showWithdrawalNotice(context, appState, notice);
      });
    }

    // A real incoming call from another user (see AppState._listenIncomingCalls)
    // can arrive while the person is on ANY tab — this pushes the incoming-call
    // screen the moment it does, regardless of what they're currently looking
    // at. Keyed by session id so the same call is never pushed twice.
    if (appState.callStage == CallStage.incomingRinging &&
        appState.currentCallSessionId != null &&
        appState.currentCallSessionId != _shownIncomingCallSessionId) {
      _shownIncomingCallSessionId = appState.currentCallSessionId;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) Navigator.of(context).push(MaterialPageRoute(builder: (_) => const IncomingCallScreen()));
      });
    }

    // Admin broadcasts from the CRM's Announcements tab (see
    // AppState._listenAnnouncements) now show as a real OS notification —
    // reaching every signed-in user on both the app and the web build even
    // if they're not looking at this screen — instead of a popup drawn
    // inside the app itself.

    // Anyone can now call anyone (male-male, female-female, and both
    // directions of male/female) — whoever calls pays from their wallet,
    // whoever answers earns. So every user needs BOTH a wallet (to add
    // money and call) and earnings/withdraw (for money they've earned).
    final screens = [
      const BrowseScreen(),
      const OnlineListScreen(),
      const WalletScreen(),
      const EarningsScreen(),
      const CallHistoryScreen(),
      const ProfileScreen(),
    ];

    final labels = ['Home', 'Online', 'Wallet', 'Earnings', 'History', 'Profile'];
    const icons = [
      Icons.home_rounded,
      Icons.people_alt_rounded,
      Icons.account_balance_wallet_rounded,
      Icons.savings_rounded,
      Icons.history_rounded,
      Icons.person_rounded,
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: screens),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: AppColors.bgCard,
          border: Border(top: BorderSide(color: AppColors.divider)),
        ),
        child: SafeArea(
          child: SizedBox(
            height: 62,
            child: Row(
              children: List.generate(labels.length, (i) {
                final selected = _index == i;
                return Expanded(
                  child: InkWell(
                    onTap: () => setState(() => _index = i),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(icons[i], size: 20, color: selected ? AppColors.accent1 : AppColors.textDim2),
                        const SizedBox(height: 3),
                        Text(
                          labels[i],
                          style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: selected ? AppColors.accent1 : AppColors.textDim2),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}
