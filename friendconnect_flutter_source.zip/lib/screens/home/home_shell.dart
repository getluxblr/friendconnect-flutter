import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import 'browse_screen.dart';
import 'online_list_screen.dart';
import '../wallet/wallet_screen.dart';
import '../earnings/earnings_screen.dart';
import '../history/call_history_screen.dart';
import '../profile/profile_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final role = context.watch<AppState>().role;
    final isMale = role == UserRole.male;

    final screens = [
      const BrowseScreen(),
      const OnlineListScreen(),
      isMale ? const WalletScreen() : const EarningsScreen(),
      const CallHistoryScreen(),
      const ProfileScreen(),
    ];

    final labels = ['Home', 'Online', isMale ? 'Wallet' : 'Earnings', 'History', 'Profile'];
    const icons = [Icons.home_rounded, Icons.people_alt_rounded, Icons.account_balance_wallet_rounded, Icons.history_rounded, Icons.person_rounded];

    return Scaffold(
      body: IndexedStack(index: _index, children: screens),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: AppColors.bgCard,
          border: Border(top: BorderSide(color: AppColors.divider)),
        ),
        child: SafeArea(
          child: SizedBox(
            height: 62,
            child: Row(
              children: List.generate(5, (i) {
                final selected = _index == i;
                return Expanded(
                  child: InkWell(
                    onTap: () => setState(() => _index = i),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(icons[i], size: 20, color: selected ? AppColors.accent1 : AppColors.textDim2),
                        const SizedBox(height: 3),
                        Text(
                          labels[i],
                          style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: selected ? AppColors.accent1 : AppColors.textDim2),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}
