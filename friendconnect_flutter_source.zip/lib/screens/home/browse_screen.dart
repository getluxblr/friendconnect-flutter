import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/call_log_model.dart';
import '../../models/user_model.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/avatar_circle.dart';
import '../call/calling_screen.dart';
import '../call/incoming_call_screen.dart';

/// Anyone can call anyone here — male-male, female-female, and both
/// directions of male/female. Whoever taps "call" pays from their wallet;
/// whoever answers earns. Use the filter chips to narrow who shows up.
class BrowseScreen extends StatelessWidget {
  const BrowseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Good evening 👋', style: TextStyle(fontSize: 11, color: AppColors.textDim2)),
                    Text(state.myName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textMain)),
                  ],
                ),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.divider)),
                      child: Row(
                        children: [
                          const Text('💰', style: TextStyle(fontSize: 13)),
                          const SizedBox(width: 5),
                          Text('₹${state.walletBalance.toStringAsFixed(0)}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textMain)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Icon(Icons.notifications_rounded, color: AppColors.amber, size: 22),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            _OnlineStatusCard(state: state),
            if (state.amIOnline && state.onlineUsers.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    onPressed: () {
                      final demoCaller = state.onlineUsers.first;
                      state.simulateIncomingCall(demoCaller, CallType.video);
                      Navigator.of(context).push(MaterialPageRoute(builder: (_) => const IncomingCallScreen()));
                    },
                    icon: const Icon(Icons.call_received_rounded, size: 15, color: AppColors.accent1),
                    label: const Text('Simulate Incoming Call (demo)', style: TextStyle(color: AppColors.accent1, fontSize: 11.5)),
                    style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 0), tapTargetSize: MaterialTapTargetSize.shrinkWrap),
                  ),
                ),
              ),
            const SizedBox(height: 14),
            Expanded(child: _BrowseGrid(state: state)),
          ],
        ),
      ),
    );
  }
}

class _OnlineStatusCard extends StatelessWidget {
  final AppState state;
  const _OnlineStatusCard({required this.state});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [AppColors.accent2, AppColors.accent1]),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  state.amIOnline ? 'Online — ready to receive calls' : 'Offline',
                  style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 2),
                Text('Earn ₹${AppState.earnRatePerMinute.toStringAsFixed(0)}/min · today ₹${state.todayEarnings.toStringAsFixed(0)}', style: const TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
          Switch(value: state.amIOnline, activeColor: Colors.white, onChanged: (v) => state.toggleOnline(v)),
        ],
      ),
    );
  }
}

class _BrowseGrid extends StatelessWidget {
  final AppState state;
  const _BrowseGrid({required this.state});

  @override
  Widget build(BuildContext context) {
    final users = state.filteredOnlineUsers;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 34,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              _FilterChip(label: 'All', active: state.genderFilter == 'all', onTap: () => state.setGenderFilter('all')),
              const SizedBox(width: 8),
              _FilterChip(label: 'Male', active: state.genderFilter == 'male', onTap: () => state.setGenderFilter('male')),
              const SizedBox(width: 8),
              _FilterChip(label: 'Female', active: state.genderFilter == 'female', onTap: () => state.setGenderFilter('female')),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: users.isEmpty
              ? const Center(
                  child: Text('No one online right now for this filter.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textDim2, fontSize: 12)),
                )
              : GridView.builder(
                  itemCount: users.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.72),
                  itemBuilder: (context, i) => _UserCard(user: users[i]),
                ),
        ),
      ],
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.onTap, this.active = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: active ? AppColors.accent2 : AppColors.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? AppColors.accent2 : AppColors.divider),
        ),
        child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: active ? Colors.white : AppColors.textDim)),
      ),
    );
  }
}

class _UserCard extends StatelessWidget {
  final UserProfile user;
  const _UserCard({required this.user});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.divider)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(
                  child: AvatarCircle(initial: user.name.substring(0, 1), colorIndex: user.avatarColorIndex, borderRadius: BorderRadius.circular(14), fontSize: 32),
                ),
                Positioned(
                  bottom: 6,
                  right: 6,
                  child: Container(
                    width: 13,
                    height: 13,
                    decoration: BoxDecoration(color: AppColors.green, shape: BoxShape.circle, border: Border.all(color: AppColors.bgCard, width: 2.5)),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text('${user.name}, ${user.age}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textMain)),
          const SizedBox(height: 2),
          Text('🌐 ${user.language} · ${user.city}', style: const TextStyle(fontSize: 10.5, color: AppColors.textDim2), overflow: TextOverflow.ellipsis),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _CallBtn(
                  icon: Icons.call_rounded,
                  color: AppColors.accent3.withOpacity(0.18),
                  iconColor: AppColors.accent3,
                  onTap: () => _startCall(context, state, CallType.audio),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _CallBtn(icon: Icons.videocam_rounded, gradient: true, onTap: () => _startCall(context, state, CallType.video)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _startCall(BuildContext context, AppState state, CallType type) {
    final hasFreeMinutes = state.role == UserRole.male && state.freeSecondsRemaining > 0;
    if (!hasFreeMinutes && state.walletBalance < AppState.callRatePerMinute) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Insufficient wallet balance. Please add money to continue.')));
      return;
    }
    state.startOutgoingCall(user, type);
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CallingScreen()));
  }
}

class _CallBtn extends StatelessWidget {
  final IconData icon;
  final Color? color;
  final Color iconColor;
  final bool gradient;
  final VoidCallback onTap;
  const _CallBtn({required this.icon, this.color, this.iconColor = Colors.white, this.gradient = false, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
          color: gradient ? null : color,
          gradient: gradient ? const LinearGradient(colors: [AppColors.accent1, AppColors.accent2]) : null,
          borderRadius: BorderRadius.circular(12),
        ),
        alignment: Alignment.center,
        child: Icon(icon, size: 16, color: gradient ? Colors.white : iconColor),
      ),
    );
  }
}
