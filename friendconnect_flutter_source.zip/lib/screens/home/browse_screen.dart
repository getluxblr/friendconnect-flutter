import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/call_log_model.dart';
import '../../models/user_model.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/avatar_circle.dart';
import '../call/calling_screen.dart';
import '../call/incoming_call_screen.dart';

class BrowseScreen extends StatelessWidget {
  const BrowseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final isMale = state.role == UserRole.male;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Good evening 👋', style: TextStyle(fontSize: 11, color: AppColors.textDim2)),
                    Text(state.myName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textMain)),
                  ],
                ),
                Row(
                  children: [
                    if (isMale)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                        decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.divider)),
                        child: Row(
                          children: [
                            const Text('💰', style: TextStyle(fontSize: 13)),
                            const SizedBox(width: 5),
                            Text('₹${state.walletBalance.toStringAsFixed(0)}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.textMain)),
                          ],
                        ),
                      ),
                    const SizedBox(width: 10),
                    const Icon(Icons.notifications_rounded, color: AppColors.amber, size: 22),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (!isMale) Expanded(child: _FemaleDashboardCard(state: state)) else Expanded(child: _MaleBrowseGrid(state: state)),
          ],
        ),
      ),
    );
  }
}

class _FemaleDashboardCard extends StatelessWidget {
  final AppState state;
  const _FemaleDashboardCard({required this.state});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [AppColors.accent2, AppColors.accent1]),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('YOUR STATUS', style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w700)),
                  Switch(value: state.amIOnline, activeColor: Colors.white, onChanged: (v) => state.toggleOnline(v)),
                ],
              ),
              Text(
                state.amIOnline ? 'Online — ready to receive calls' : 'Offline',
                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 4),
              Text('₹1 earned per minute · today ₹${state.todayEarnings.toStringAsFixed(0)}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Text(
          'When you\'re online, real male users on FriendConnect can\nsee you and call you. Use "Test Real Video Call" in your\nprofile for a direct room-code call between two devices.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12, color: AppColors.textDim2, height: 1.5),
        ),
        const SizedBox(height: 20),
        if (state.amIOnline && state.onlineUsers.isNotEmpty)
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                final demoCaller = state.onlineUsers.first;
                state.simulateIncomingCall(demoCaller, CallType.video);
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const IncomingCallScreen()));
              },
              icon: const Icon(Icons.call_received_rounded, color: AppColors.accent1),
              label: const Text('Simulate Incoming Call', style: TextStyle(color: AppColors.accent1)),
              style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.divider), padding: const EdgeInsets.symmetric(vertical: 14)),
            ),
          )
        else if (state.amIOnline)
          const Text(
            'No male users online right now — you\'ll appear here for them.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: AppColors.textDim2),
          ),
      ],
    );
  }
}

class _MaleBrowseGrid extends StatelessWidget {
  final AppState state;
  const _MaleBrowseGrid({required this.state});

  @override
  Widget build(BuildContext context) {
    final users = state.onlineUsers.where((u) => u.isOnline).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 34,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: const [
              _FilterChip(label: 'Online Only', active: true),
              SizedBox(width: 8),
              _FilterChip(label: 'Language'),
              SizedBox(width: 8),
              _FilterChip(label: 'Age'),
              SizedBox(width: 8),
              _FilterChip(label: 'Country'),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: GridView.builder(
            itemCount: users.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.72),
            itemBuilder: (context, i) => _UserCard(user: users[i]),
          ),
        ),
      ],
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool active;
  const _FilterChip({required this.label, this.active = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: active ? AppColors.accent2 : AppColors.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: active ? AppColors.accent2 : AppColors.divider),
      ),
      child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: active ? Colors.white : AppColors.textDim)),
    );
  }
}

class _UserCard extends StatelessWidget {
  final UserProfile user;
  const _UserCard({required this.user});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.divider)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(
                  child: AvatarCircle(initial: user.name.substring(0, 1), colorIndex: user.avatarColorIndex, borderRadius: BorderRadius.circular(14), fontSize: 32),
                ),
                Positioned(
                  bottom: 6,
                  right: 6,
                  child: Container(
                    width: 13,
                    height: 13,
                    decoration: BoxDecoration(color: AppColors.green, shape: BoxShape.circle, border: Border.all(color: AppColors.bgCard, width: 2.5)),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text('${user.name}, ${user.age}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textMain)),
          const SizedBox(height: 2),
          Text('🌐 ${user.language} · ${user.city}', style: const TextStyle(fontSize: 10.5, color: AppColors.textDim2), overflow: TextOverflow.ellipsis),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _CallBtn(
                  icon: Icons.call_rounded,
                  color: AppColors.accent3.withOpacity(0.18),
                  iconColor: AppColors.accent3,
                  onTap: () => _startCall(context, state, CallType.audio),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _CallBtn(icon: Icons.videocam_rounded, gradient: true, onTap: () => _startCall(context, state, CallType.video)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _startCall(BuildContext context, AppState state, CallType type) {
    if (state.walletBalance < 5) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Insufficient wallet balance. Please recharge.')));
      return;
    }
    state.startOutgoingCall(user, type);
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CallingScreen()));
  }
}

class _CallBtn extends StatelessWidget {
  final IconData icon;
  final Color? color;
  final Color iconColor;
  final bool gradient;
  final VoidCallback onTap;
  const _CallBtn({required this.icon, this.color, this.iconColor = Colors.white, this.gradient = false, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
          color: gradient ? null : color,
          gradient: gradient ? const LinearGradient(colors: [AppColors.accent1, AppColors.accent2]) : null,
          borderRadius: BorderRadius.circular(12),
        ),
        alignment: Alignment.center,
        child: Icon(icon, size: 16, color: gradient ? Colors.white : iconColor),
      ),
    );
  }
}
