import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';

/// Fixes the previously dead "Blocked Users" tap. Shows a real empty state
/// today (no block action exists elsewhere in the app yet); the list itself
/// is already wired up in AppState so a "block" action can be added later.
class BlockedUsersScreen extends StatelessWidget {
  const BlockedUsersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Blocked Users', style: TextStyle(color: AppColors.textMain, fontWeight: FontWeight.w800)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textMain),
      ),
      body: SafeArea(
        child: state.blockedUserNames.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.block_rounded, size: 40, color: AppColors.textDim2),
                      SizedBox(height: 12),
                      Text('You haven\'t blocked anyone yet', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textMain)),
                      SizedBox(height: 6),
                      Text(
                        'Blocked users won\'t be able to call you or show up in your Online list.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 11.5, color: AppColors.textDim2),
                      ),
                    ],
                  ),
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                itemCount: state.blockedUserNames.length,
                itemBuilder: (context, i) {
                  final name = state.blockedUserNames[i];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.divider)),
                    child: Row(
                      children: [
                        Expanded(child: Text(name, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.textMain))),
                        TextButton(
                          onPressed: () => state.unblockUser(name),
                          child: const Text('Unblock', style: TextStyle(color: AppColors.accent2, fontWeight: FontWeight.w700, fontSize: 12)),
                        ),
                      ],
                    ),
                  );
                },
              ),
      ),
    );
  }
}
