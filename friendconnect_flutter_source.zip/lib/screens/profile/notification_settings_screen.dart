import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';

/// Simple local notification preferences — fixes the previously dead
/// "Notification Settings" tap on the profile screen.
class NotificationSettingsScreen extends StatelessWidget {
  const NotificationSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notification Settings', style: TextStyle(color: AppColors.textMain, fontWeight: FontWeight.w800)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textMain),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
          children: [
            _switchTile(
              icon: Icons.call_rounded,
              title: 'Call Alerts',
              subtitle: 'Incoming call and call-status notifications',
              value: state.notifyCallAlerts,
              onChanged: state.setNotifyCallAlerts,
            ),
            _switchTile(
              icon: Icons.account_balance_wallet_rounded,
              title: 'Withdrawal Updates',
              subtitle: 'When your withdrawal request is approved or rejected',
              value: state.notifyWithdrawalUpdates,
              onChanged: state.setNotifyWithdrawalUpdates,
            ),
            _switchTile(
              icon: Icons.campaign_rounded,
              title: 'Offers & Promotions',
              subtitle: 'Occasional recharge bonuses and app updates',
              value: state.notifyPromotions,
              onChanged: state.setNotifyPromotions,
            ),
          ],
        ),
      ),
    );
  }

  Widget _switchTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.divider)),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.accent2),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: AppColors.textMain)),
                const SizedBox(height: 2),
                Text(subtitle, style: const TextStyle(fontSize: 10.5, color: AppColors.textDim2)),
              ],
            ),
          ),
          Switch(value: value, activeColor: AppColors.accent1, onChanged: onChanged),
        ],
      ),
    );
  }
}
