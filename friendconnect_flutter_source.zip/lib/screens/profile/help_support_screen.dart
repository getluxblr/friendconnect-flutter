import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../theme/app_theme.dart';

/// Fixes the previously dead "Help & Support" tap. Shows the support
/// contact details with tap-to-copy (no url_launcher dependency needed).
class HelpSupportScreen extends StatelessWidget {
  const HelpSupportScreen({super.key});

  static const String supportName = 'Sabari J';
  static const String supportPhone = '+91 6363958868';
  static const String supportEmail = 'support@friendconnect.in';
  static const String supportHours = '09:00 AM to 06:00 PM';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Help & Support', style: TextStyle(color: AppColors.textMain, fontWeight: FontWeight.w800)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textMain),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppColors.accent2, AppColors.accent1]),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Row(
                children: [
                  Icon(Icons.support_agent_rounded, color: Colors.white, size: 26),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Need help? Reach out to our support team below.',
                      style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            _contactTile(context, icon: Icons.person_rounded, label: 'Name', value: supportName),
            _contactTile(context, icon: Icons.call_rounded, label: 'Mobile Number', value: supportPhone, copyable: true),
            _contactTile(context, icon: Icons.email_rounded, label: 'Email', value: supportEmail, copyable: true),
            _contactTile(context, icon: Icons.schedule_rounded, label: 'Working Time', value: supportHours),
            const SizedBox(height: 8),
            const Text(
              'Tap the phone number or email to copy it.',
              style: TextStyle(fontSize: 10.5, color: AppColors.textDim2),
            ),
          ],
        ),
      ),
    );
  }

  Widget _contactTile(BuildContext context, {required IconData icon, required String label, required String value, bool copyable = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.divider)),
      child: InkWell(
        onTap: copyable
            ? () async {
                await Clipboard.setData(ClipboardData(text: value));
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$label copied')));
                }
              }
            : null,
        child: Row(
          children: [
            Icon(icon, size: 20, color: AppColors.accent2),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label.toUpperCase(), style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.textDim2, letterSpacing: 0.5)),
                  const SizedBox(height: 3),
                  Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textMain)),
                ],
              ),
            ),
            if (copyable) const Icon(Icons.copy_rounded, size: 16, color: AppColors.textDim2),
          ],
        ),
      ),
    );
  }
}
