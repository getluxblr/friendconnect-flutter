import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/avatar_circle.dart';
import '../auth/login_screen.dart';
import '../kyc/kyc_screen.dart';
import '../realcall/real_call_screen.dart';
import 'blocked_users_screen.dart';
import 'edit_profile_screen.dart';
import 'help_support_screen.dart';
import 'notification_settings_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final isMale = state.role == UserRole.male;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          Center(
            child: Column(
              children: [
                AvatarCircle(initial: state.myName.substring(0, 1), colorIndex: 2, gender: isMale ? 'male' : 'female', size: 92, fontSize: 32),
                const SizedBox(height: 10),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(state.myName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textMain)),
                    // KYC is now required for every user (not just female).
                    ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: (state.kycStatus == 'verified' ? AppColors.accent2 : AppColors.textDim2).withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          state.kycStatus == 'verified'
                              ? '✓ Verified'
                              : state.kycStatus == 'pending'
                                  ? 'Verification pending'
                                  : state.kycStatus == 'rejected'
                                      ? 'KYC rejected'
                                      : 'Not verified',
                          style: TextStyle(
                            color: state.kycStatus == 'verified' ? const Color(0xFFC4B5FD) : AppColors.textDim2,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  isMale ? '📱 +91 ${state.phoneNumber}' : '🌐 Tamil, English · Chennai, TN',
                  style: const TextStyle(fontSize: 12, color: AppColors.textDim2),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: const BoxDecoration(border: Border(top: BorderSide(color: AppColors.divider), bottom: BorderSide(color: AppColors.divider))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _pstat('${state.callHistory.length}', 'Total Calls'),
                      _pstat('${(state.walletBalance / AppState.callRatePerMinuteFor(state.role)).floor()}', 'Min. Left'),
                      _pstat('4.9★', 'Rating'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          _menuRow(
            Icons.edit_rounded,
            'Edit Profile',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const EditProfileScreen())),
          ),
          _menuRow(
            Icons.videocam_rounded,
            'Test Real Video Call',
            color: AppColors.accent2,
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RealCallScreen())),
          ),
          // KYC is required for EVERY user now (not just female) before they
          // can make or receive calls.
          _menuRow(
            Icons.badge_rounded,
            'KYC Documents',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const KycScreen())),
          ),
          _menuRow(
            Icons.notifications_rounded,
            'Notification Settings',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationSettingsScreen())),
          ),
          _menuRow(
            Icons.block_rounded,
            'Blocked Users',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BlockedUsersScreen())),
          ),
          _menuRow(
            Icons.support_agent_rounded,
            'Help & Support',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const HelpSupportScreen())),
          ),
          _menuRow(
            Icons.logout_rounded,
            'Logout',
            color: const Color(0xFFF87171),
            onTap: () {
              state.logout();
              Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
            },
          ),
        ],
      ),
    );
  }

  Widget _pstat(String n, String l) => Column(
        children: [
          Text(n, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textMain)),
          Text(l, style: const TextStyle(fontSize: 10, color: AppColors.textDim2)),
        ],
      );

  Widget _menuRow(IconData icon, String label, {Color? color, VoidCallback? onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: AppColors.divider))),
        child: Row(
          children: [
            Icon(icon, size: 18, color: color ?? AppColors.textMain),
            const SizedBox(width: 12),
            Text(label, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: color ?? AppColors.textMain)),
          ],
        ),
      ),
    );
  }
}
