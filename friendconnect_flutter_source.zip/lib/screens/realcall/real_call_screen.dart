import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../theme/app_theme.dart';

/// A real, working audio/video call screen using WebRTC for the media and
/// Cloud Firestore purely as the signaling channel (exchanging the SDP
/// offer/answer and ICE candidates). This is separate from the rest of the
/// app's simulated call flow — it exists so the two test phones can place
/// an actual call to each other using a shared "room code" instead of a
/// real user directory/auth backend (which the PRD's backend hasn't been
/// built yet).
///
/// How to test between two phones:
/// 1. Install this build on both phones, open "Test Real Video Call".
/// 2. On phone A, tap "Create call" — a room code appears.
/// 3. Type the same room code on phone B and tap "Join call".
/// 4. Both phones should show each other's live camera within a few
///    seconds (needs internet on both phones; works across Wi-Fi/mobile
///    data, not just the same network, thanks to Google's public STUN
///    servers — though very restrictive/corporate networks can still
///    block the connection since there's no TURN relay configured).
class RealCallScreen extends StatefulWidget {
  const RealCallScreen({super.key});

  @override
  State<RealCallScreen> createState() => _RealCallScreenState();
}

class _RealCallScreenState extends State<RealCallScreen> {
  final RTCVideoRenderer _localRenderer = RTCVideoRenderer();
  final RTCVideoRenderer _remoteRenderer = RTCVideoRenderer();
  final TextEditingController _roomCodeController = TextEditingController();

  RTCPeerConnection? _peerConnection;
  MediaStream? _localStream;
  String? _roomId;
  StreamSubscription? _roomSub;
  StreamSubscription? _calleeCandidatesSub;
  StreamSubscription? _callerCandidatesSub;

  bool _inCall = false;
  bool _isMicOn = true;
  bool _isCameraOn = true;
  String _status = 'Idle';

  static const Map<String, dynamic> _iceServers = {
    'iceServers': [
      {'urls': 'stun:stun.l.google.com:19302'},
      {'urls': 'stun:stun1.l.google.com:19302'},
      {'urls': 'stun:stun2.l.google.com:19302'},
    ],
  };

  @override
  void initState() {
    super.initState();
    _localRenderer.initialize();
    _remoteRenderer.initialize();
  }

  @override
  void dispose() {
    _hangUp();
    _localRenderer.dispose();
    _remoteRenderer.dispose();
    _roomCodeController.dispose();
    super.dispose();
  }

  Future<bool> _ensurePermissions() async {
    final statuses = await [Permission.camera, Permission.microphone].request();
    return statuses.values.every((s) => s.isGranted);
  }

  Future<void> _openUserMedia() async {
    final stream = await navigator.mediaDevices.getUserMedia({
      'audio': true,
      'video': {'facingMode': 'user'},
    });
    _localStream = stream;
    _localRenderer.srcObject = stream;
    setState(() {});
  }

  Future<void> _createPeerConnection() async {
    final pc = await createPeerConnection(_iceServers);

    for (final track in _localStream!.getTracks()) {
      await pc.addTrack(track, _localStream!);
    }

    pc.onTrack = (RTCTrackEvent event) {
      if (event.streams.isNotEmpty) {
        _remoteRenderer.srcObject = event.streams[0];
        setState(() => _status = 'Connected');
      }
    };

    pc.onConnectionState = (state) {
      debugPrint('Peer connection state: $state');
      if (state == RTCPeerConnectionState.RTCPeerConnectionStateFailed ||
          state == RTCPeerConnectionState.RTCPeerConnectionStateDisconnected) {
        setState(() => _status = 'Connection lost');
      }
    };

    _peerConnection = pc;
  }

  /// Phone A: creates a new room document containing the SDP offer, then
  /// listens for phone B's answer and ICE candidates.
  Future<void> _createRoom() async {
    if (!await _ensurePermissions()) {
      setState(() => _status = 'Camera/mic permission denied');
      return;
    }
    setState(() => _status = 'Starting camera...');
    await _openUserMedia();
    await _createPeerConnection();

    final roomRef = FirebaseFirestore.instance.collection('calls').doc();
    _roomId = roomRef.id;

    final callerCandidates = roomRef.collection('callerCandidates');
    _peerConnection!.onIceCandidate = (RTCIceCandidate candidate) {
      callerCandidates.add(candidate.toMap());
    };

    setState(() => _status = 'Creating offer...');
    final offer = await _peerConnection!.createOffer();
    await _peerConnection!.setLocalDescription(offer);

    await roomRef.set({
      'offer': {'type': offer.type, 'sdp': offer.sdp},
    });

    setState(() {
      _inCall = true;
      _status = 'Waiting for the other phone to join room $_roomId ...';
    });

    _roomSub = roomRef.snapshots().listen((snapshot) async {
      final data = snapshot.data();
      if (data == null) return;
      if (data['answer'] != null && _peerConnection!.getRemoteDescription() == null) {
        final answer = RTCSessionDescription(data['answer']['sdp'], data['answer']['type']);
        await _peerConnection!.setRemoteDescription(answer);
        setState(() => _status = 'Answer received, connecting...');
      }
    });

    _calleeCandidatesSub = roomRef.collection('calleeCandidates').snapshots().listen((snapshot) {
      for (final change in snapshot.docChanges) {
        if (change.type == DocumentChangeType.added) {
          final d = change.doc.data()!;
          _peerConnection!.addCandidate(
            RTCIceCandidate(d['candidate'], d['sdpMid'], d['sdpMLineIndex']),
          );
        }
      }
    });
  }

  /// Phone B: joins an existing room by code, answers the offer, and
  /// listens for phone A's ICE candidates.
  Future<void> _joinRoom(String roomId) async {
    final roomRef = FirebaseFirestore.instance.collection('calls').doc(roomId.trim());
    final roomSnap = await roomRef.get();
    if (!roomSnap.exists) {
      setState(() => _status = 'No call found with that room code');
      return;
    }

    if (!await _ensurePermissions()) {
      setState(() => _status = 'Camera/mic permission denied');
      return;
    }
    setState(() => _status = 'Starting camera...');
    await _openUserMedia();
    await _createPeerConnection();
    _roomId = roomId.trim();

    final calleeCandidates = roomRef.collection('calleeCandidates');
    _peerConnection!.onIceCandidate = (RTCIceCandidate candidate) {
      calleeCandidates.add(candidate.toMap());
    };

    final data = roomSnap.data()!;
    final offer = data['offer'];
    await _peerConnection!.setRemoteDescription(
      RTCSessionDescription(offer['sdp'], offer['type']),
    );

    setState(() => _status = 'Creating answer...');
    final answer = await _peerConnection!.createAnswer();
    await _peerConnection!.setLocalDescription(answer);

    await roomRef.update({
      'answer': {'type': answer.type, 'sdp': answer.sdp},
    });

    setState(() {
      _inCall = true;
      _status = 'Connecting...';
    });

    _callerCandidatesSub = roomRef.collection('callerCandidates').snapshots().listen((snapshot) {
      for (final change in snapshot.docChanges) {
        if (change.type == DocumentChangeType.added) {
          final d = change.doc.data()!;
          _peerConnection!.addCandidate(
            RTCIceCandidate(d['candidate'], d['sdpMid'], d['sdpMLineIndex']),
          );
        }
      }
    });
  }

  Future<void> _hangUp() async {
    await _roomSub?.cancel();
    await _calleeCandidatesSub?.cancel();
    await _callerCandidatesSub?.cancel();

    if (_roomId != null) {
      final roomRef = FirebaseFirestore.instance.collection('calls').doc(_roomId);
      try {
        for (final doc in (await roomRef.collection('callerCandidates').get()).docs) {
          await doc.reference.delete();
        }
        for (final doc in (await roomRef.collection('calleeCandidates').get()).docs) {
          await doc.reference.delete();
        }
        await roomRef.delete();
      } catch (_) {
        // Best-effort cleanup; ignore if already gone.
      }
    }

    for (final track in _localStream?.getTracks() ?? <MediaStreamTrack>[]) {
      await track.stop();
    }
    await _localStream?.dispose();
    await _peerConnection?.close();

    _localStream = null;
    _peerConnection = null;
    _roomId = null;

    if (mounted) {
      setState(() {
        _inCall = false;
        _status = 'Call ended';
        _localRenderer.srcObject = null;
        _remoteRenderer.srcObject = null;
      });
    }
  }

  void _toggleMic() {
    final audioTracks = _localStream?.getAudioTracks() ?? [];
    for (final t in audioTracks) {
      t.enabled = !_isMicOn;
    }
    setState(() => _isMicOn = !_isMicOn);
  }

  void _toggleCamera() {
    final videoTracks = _localStream?.getVideoTracks() ?? [];
    for (final t in videoTracks) {
      t.enabled = !_isCameraOn;
    }
    setState(() => _isCameraOn = !_isCameraOn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgApp,
      appBar: AppBar(
        backgroundColor: AppColors.bgApp,
        title: const Text('Test Real Video Call'),
      ),
      body: SafeArea(
        child: _inCall ? _buildCallView() : _buildSetupView(),
      ),
    );
  }

  Widget _buildSetupView() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'This places a real WebRTC call using live camera/mic — not the '
            'simulated demo flow. Use it to test between your two phones.',
            style: TextStyle(color: AppColors.textDim, fontSize: 13),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: _createRoom,
            style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
            child: const Text('Create call (Phone A)'),
          ),
          const SizedBox(height: 28),
          const Text('— or —', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textDim2)),
          const SizedBox(height: 20),
          TextField(
            controller: _roomCodeController,
            style: const TextStyle(color: AppColors.textMain),
            decoration: const InputDecoration(
              labelText: 'Room code from Phone A',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: () {
              final code = _roomCodeController.text.trim();
              if (code.isNotEmpty) _joinRoom(code);
            },
            style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
            child: const Text('Join call (Phone B)'),
          ),
          const SizedBox(height: 24),
          Text(_status, style: const TextStyle(color: AppColors.textDim2, fontSize: 12)),
          if (_roomId != null) ...[
            const SizedBox(height: 8),
            SelectableText(
              'Room code: $_roomId',
              style: const TextStyle(color: AppColors.accent2, fontWeight: FontWeight.bold, fontSize: 16),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildCallView() {
    return Stack(
      children: [
        Positioned.fill(
          child: RTCVideoView(_remoteRenderer, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover),
        ),
        Positioned(
          top: 16,
          right: 16,
          width: 110,
          height: 150,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: RTCVideoView(_localRenderer, mirror: true, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover),
          ),
        ),
        Positioned(
          top: 16,
          left: 16,
          right: 140,
          child: Text(
            _status,
            style: const TextStyle(color: Colors.white, fontSize: 12, shadows: [Shadow(blurRadius: 4)]),
          ),
        ),
        if (_roomId != null)
          Positioned(
            top: 40,
            left: 16,
            right: 140,
            child: Text(
              'Room: $_roomId',
              style: const TextStyle(color: Colors.white70, fontSize: 11),
            ),
          ),
        Positioned(
          bottom: 32,
          left: 0,
          right: 0,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _circleButton(_isMicOn ? Icons.mic : Icons.mic_off, _toggleMic),
              const SizedBox(width: 20),
              _circleButton(Icons.call_end, _hangUp, color: Colors.red),
              const SizedBox(width: 20),
              _circleButton(_isCameraOn ? Icons.videocam : Icons.videocam_off, _toggleCamera),
            ],
          ),
        ),
      ],
    );
  }

  Widget _circleButton(IconData icon, VoidCallback onTap, {Color color = Colors.white24}) {
    return InkWell(
      onTap: onTap,
      customBorder: const CircleBorder(),
      child: CircleAvatar(radius: 28, backgroundColor: color, child: Icon(icon, color: Colors.white)),
    );
  }
}
