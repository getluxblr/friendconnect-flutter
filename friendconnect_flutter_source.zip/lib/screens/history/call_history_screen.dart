import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/call_log_model.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/avatar_circle.dart';

class CallHistoryScreen extends StatelessWidget {
  const CallHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Call History', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textMain)),
            const SizedBox(height: 14),
            Expanded(
              child: state.callHistory.isEmpty
                  ? const Center(
                      child: Text('No calls yet — start one from the Home tab.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textDim2)),
                    )
                  : ListView.separated(
                      itemCount: state.callHistory.length,
                      separatorBuilder: (_, __) => const Divider(color: AppColors.divider, height: 1),
                      itemBuilder: (context, i) {
                        final log = state.callHistory[i];
                        final mins = log.durationSeconds ~/ 60;
                        final secs = log.durationSeconds % 60;
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 11),
                          child: Row(
                            children: [
                              AvatarCircle(initial: log.peer.name.substring(0, 1), colorIndex: log.peer.avatarColorIndex, size: 40, fontSize: 16),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(log.peer.name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textMain)),
                                    Text(
                                      '${log.type == CallType.video ? "🎥 Video" : "📞 Audio"} · ${log.timestamp.hour.toString().padLeft(2, '0')}:${log.timestamp.minute.toString().padLeft(2, '0')}',
                                      style: const TextStyle(fontSize: 11, color: AppColors.textDim2),
                                    ),
                                  ],
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    '${state.role == UserRole.male ? "−" : "+"}₹${log.charge.toStringAsFixed(0)}',
                                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: state.role == UserRole.male ? const Color(0xFFF87171) : AppColors.green),
                                  ),
                                  Text('${mins}m ${secs}s', style: const TextStyle(fontSize: 10.5, color: AppColors.textDim2)),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
