import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/pill_button.dart';

class RatingDialog extends StatefulWidget {
  const RatingDialog({super.key});

  @override
  State<RatingDialog> createState() => _RatingDialogState();
}

class _RatingDialogState extends State<RatingDialog> {
  int _stars = 4;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppColors.bgCard,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Rate your call', style: TextStyle(color: AppColors.textMain, fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            const Text('Optional feedback helps keep the community safe', style: TextStyle(color: AppColors.textDim2, fontSize: 11), textAlign: TextAlign.center),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                5,
                (i) => IconButton(
                  onPressed: () => setState(() => _stars = i + 1),
                  icon: Icon(i < _stars ? Icons.star_rounded : Icons.star_border_rounded, color: AppColors.amber, size: 30),
                ),
              ),
            ),
            const SizedBox(height: 10),
            PillButton(label: 'Submit', onTap: () => Navigator.of(context).pop()),
          ],
        ),
      ),
    );
  }
}
