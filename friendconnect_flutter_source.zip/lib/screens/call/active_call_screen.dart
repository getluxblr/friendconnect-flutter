import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:provider/provider.dart';

import '../../models/call_log_model.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/avatar_circle.dart';
import '../history/rating_dialog.dart';

/// The live call screen — shows the other person's real camera feed for
/// video calls (with a small self-preview), and plays their real voice for
/// audio calls, over the actual WebRTC connection AppState sets up (see
/// AppState._startCallerMedia / _startCalleeMedia). Mute, camera-off, and
/// speaker all act on the real local media tracks, not just a UI toggle.
class ActiveCallScreen extends StatefulWidget {
  const ActiveCallScreen({super.key});

  @override
  State<ActiveCallScreen> createState() => _ActiveCallScreenState();
}

class _ActiveCallScreenState extends State<ActiveCallScreen> {
  bool _endedHandled = false;
  bool _renderersReady = false;

  final RTCVideoRenderer _localRenderer = RTCVideoRenderer();
  final RTCVideoRenderer _remoteRenderer = RTCVideoRenderer();

  @override
  void initState() {
    super.initState();
    _initRenderers();
  }

  Future<void> _initRenderers() async {
    await _localRenderer.initialize();
    await _remoteRenderer.initialize();
    if (!mounted) return;
    setState(() => _renderersReady = true);
    _syncRenderers(context.read<AppState>());
  }

  void _syncRenderers(AppState state) {
    if (!_renderersReady) return;
    if (_localRenderer.srcObject != state.localStream) {
      _localRenderer.srcObject = state.localStream;
    }
    if (_remoteRenderer.srcObject != state.remoteStream) {
      _remoteRenderer.srcObject = state.remoteStream;
    }
  }

  @override
  void dispose() {
    _localRenderer.dispose();
    _remoteRenderer.dispose();
    super.dispose();
  }

  String _fmt(int totalSeconds) {
    final m = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (totalSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    _syncRenderers(state);

    if (state.callStage == CallStage.ended && !_endedHandled) {
      _endedHandled = true;
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        await showDialog(context: context, barrierDismissible: false, builder: (_) => const RatingDialog());
        if (!mounted) return;
        context.read<AppState>().resetCall();
        Navigator.of(context).pop();
      });
    }

    final peer = state.currentPeer;
    final lowBalance = state.isCallInitiator && state.walletBalance <= 25;
    final isVideo = state.currentCallType == CallType.video;
    final hasRemoteVideo = isVideo && state.remoteStream != null && state.remoteStream!.getVideoTracks().isNotEmpty;

    return Scaffold(
      backgroundColor: AppColors.bgApp,
      body: Stack(
        children: [
          // Background: real remote video for video calls, or the usual
          // gradient behind the avatar for audio calls.
          if (hasRemoteVideo && _renderersReady)
            Positioned.fill(
              child: RTCVideoView(_remoteRenderer, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover),
            )
          else
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF3B1F66), Color(0xFF1C1030), Color(0xFF10071F)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          // The remote MediaStream still needs to be attached to a renderer
          // for its AUDIO to actually play back (this matters most on Flutter
          // Web) even when we're not showing the video full-screen above —
          // so keep a 0x0 renderer mounted for audio-only calls.
          if (!hasRemoteVideo && _renderersReady)
            Offstage(
              offstage: true,
              child: SizedBox(width: 1, height: 1, child: RTCVideoView(_remoteRenderer)),
            ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(20)),
                        child: Row(
                          children: [
                            const Icon(Icons.fiber_manual_record, color: AppColors.red, size: 10),
                            const SizedBox(width: 6),
                            Text(_fmt(state.callSeconds), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(color: AppColors.accent1.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                        child: Text(
                          state.isCallInitiator
                              ? '−₹${AppState.callRatePerMinuteFor(state.role).toStringAsFixed(0)}/min'
                              : (AppState.earnRatePerMinuteFor(state.role) > 0
                                  ? '+₹${AppState.earnRatePerMinuteFor(state.role).toStringAsFixed(0)}/min'
                                  : 'No earning'),
                          style: const TextStyle(color: Color(0xFFFF8FB3), fontWeight: FontWeight.w700, fontSize: 11),
                        ),
                      ),
                    ],
                  ),
                ),
                if (!hasRemoteVideo) ...[
                  const SizedBox(height: 50),
                  AvatarCircle(initial: peer?.name.substring(0, 1) ?? '?', colorIndex: peer?.avatarColorIndex ?? 0, size: 130, fontSize: 44),
                  const SizedBox(height: 14),
                  Text(peer?.name ?? '', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
                  Text(
                    isVideo ? 'Connecting video…' : 'Connected · Live Audio',
                    style: const TextStyle(color: AppColors.textDim, fontSize: 11),
                  ),
                ] else
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        peer?.name ?? '',
                        style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800, shadows: [Shadow(blurRadius: 6)]),
                      ),
                    ),
                  ),
                const Spacer(),
                if (lowBalance)
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(color: AppColors.amber.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
                    child: Row(
                      children: [
                        const Icon(Icons.warning_amber_rounded, color: AppColors.amber, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Wallet balance low — ₹${state.walletBalance.toStringAsFixed(0)} left',
                            style: const TextStyle(color: AppColors.amber, fontSize: 11.5, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.only(bottom: 30),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _ctrl(state.isMicOn ? Icons.mic_rounded : Icons.mic_off_rounded, !state.isMicOn, () => state.toggleMic()),
                      if (isVideo)
                        _ctrl(state.isCameraOn ? Icons.videocam_rounded : Icons.videocam_off_rounded, !state.isCameraOn, () => state.toggleCamera()),
                      GestureDetector(
                        onTap: () => context.read<AppState>().endCall(),
                        child: Container(
                          width: 56,
                          height: 56,
                          decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle),
                          child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 24),
                        ),
                      ),
                      _ctrl(Icons.volume_up_rounded, state.isSpeakerOn, () => state.toggleSpeaker()),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Self-preview, video calls only.
          if (isVideo && _renderersReady && state.localStream != null)
            Positioned(
              top: 60,
              right: 16,
              width: 100,
              height: 140,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  color: Colors.black,
                  child: state.isCameraOn
                      ? RTCVideoView(_localRenderer, mirror: true, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)
                      : const Icon(Icons.videocam_off_rounded, color: Colors.white54),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _ctrl(IconData icon, bool active, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(color: active ? AppColors.accent1 : Colors.white.withOpacity(0.12), shape: BoxShape.circle),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
    );
  }
}
