import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/call_log_model.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/avatar_circle.dart';
import '../history/rating_dialog.dart';

class ActiveCallScreen extends StatefulWidget {
  const ActiveCallScreen({super.key});

  @override
  State<ActiveCallScreen> createState() => _ActiveCallScreenState();
}

class _ActiveCallScreenState extends State<ActiveCallScreen> {
  bool _muted = false;
  bool _speaker = false;
  bool _endedHandled = false;

  String _fmt(int totalSeconds) {
    final m = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (totalSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    if (state.callStage == CallStage.ended && !_endedHandled) {
      _endedHandled = true;
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        await showDialog(context: context, barrierDismissible: false, builder: (_) => const RatingDialog());
        if (!mounted) return;
        context.read<AppState>().resetCall();
        Navigator.of(context).pop();
      });
    }

    final peer = state.currentPeer;
    final isMale = state.role == UserRole.male;
    final lowBalance = isMale && state.walletBalance <= 25;

    return Scaffold(
      backgroundColor: AppColors.bgApp,
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF3B1F66), Color(0xFF1C1030), Color(0xFF10071F)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(color: Colors.black.withOpacity(0.4), borderRadius: BorderRadius.circular(20)),
                        child: Row(
                          children: [
                            const Icon(Icons.fiber_manual_record, color: AppColors.red, size: 10),
                            const SizedBox(width: 6),
                            Text(_fmt(state.callSeconds), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(color: AppColors.accent1.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                        child: Text(
                          isMale ? '−₹5/min' : '+₹1/min',
                          style: const TextStyle(color: Color(0xFFFF8FB3), fontWeight: FontWeight.w700, fontSize: 11),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 50),
                AvatarCircle(initial: peer?.name.substring(0, 1) ?? '?', colorIndex: peer?.avatarColorIndex ?? 0, size: 130, fontSize: 44),
                const SizedBox(height: 14),
                Text(peer?.name ?? '', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
                const Text('Connected · HD Audio', style: TextStyle(color: AppColors.textDim, fontSize: 11)),
                const Spacer(),
                if (lowBalance)
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(color: AppColors.amber.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
                    child: Row(
                      children: [
                        const Icon(Icons.warning_amber_rounded, color: AppColors.amber, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Wallet balance low — ₹${state.walletBalance.toStringAsFixed(0)} left',
                            style: const TextStyle(color: AppColors.amber, fontSize: 11.5, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.only(bottom: 30),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _ctrl(Icons.mic_off_rounded, _muted, () => setState(() => _muted = !_muted)),
                      _ctrl(Icons.videocam_off_rounded, false, () {}),
                      GestureDetector(
                        onTap: () => context.read<AppState>().endCall(),
                        child: Container(
                          width: 56,
                          height: 56,
                          decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle),
                          child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 24),
                        ),
                      ),
                      _ctrl(Icons.volume_up_rounded, _speaker, () => setState(() => _speaker = !_speaker)),
                      _ctrl(Icons.more_horiz_rounded, false, () {}),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _ctrl(IconData icon, bool active, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(color: active ? AppColors.accent1 : Colors.white.withOpacity(0.12), shape: BoxShape.circle),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
    );
  }
}
