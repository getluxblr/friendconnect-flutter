import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/call_log_model.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/avatar_circle.dart';
import 'active_call_screen.dart';

/// Outgoing call screen (male perspective). Auto-"connects" after a short
/// delay to simulate the peer accepting, since there is no live signaling
/// server wired up yet.
class CallingScreen extends StatefulWidget {
  const CallingScreen({super.key});

  @override
  State<CallingScreen> createState() => _CallingScreenState();
}

class _CallingScreenState extends State<CallingScreen> {
  Timer? _autoConnect;

  @override
  void initState() {
    super.initState();
    _autoConnect = Timer(const Duration(seconds: 3), () {
      if (!mounted) return;
      final state = context.read<AppState>();
      state.connectCall();
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const ActiveCallScreen()));
    });
  }

  @override
  void dispose() {
    _autoConnect?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final peer = state.currentPeer;
    return Scaffold(
      backgroundColor: AppColors.bgApp,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              state.currentCallType == CallType.video ? 'VIDEO CALLING…' : 'AUDIO CALLING…',
              style: const TextStyle(color: AppColors.textDim, fontWeight: FontWeight.w700, letterSpacing: 1, fontSize: 13),
            ),
            const SizedBox(height: 24),
            AvatarCircle(initial: peer?.name.substring(0, 1) ?? '?', colorIndex: peer?.avatarColorIndex ?? 0, size: 150, fontSize: 48),
            const SizedBox(height: 24),
            Text(peer?.name ?? '', style: const TextStyle(color: AppColors.textMain, fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('Ringing…', style: TextStyle(color: AppColors.textDim2, fontSize: 13)),
            const SizedBox(height: 50),
            GestureDetector(
              onTap: () {
                context.read<AppState>().resetCall();
                Navigator.of(context).pop();
              },
              child: Container(
                width: 64,
                height: 64,
                decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle),
                child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 26),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
