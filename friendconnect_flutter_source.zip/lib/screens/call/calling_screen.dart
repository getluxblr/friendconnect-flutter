import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/call_log_model.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/avatar_circle.dart';
import 'active_call_screen.dart';

/// Outgoing call screen. Watches the real Firestore call session (see
/// AppState.startOutgoingCall / _listenActiveSession) for the callee's
/// response instead of auto-connecting on a timer — advances to
/// ActiveCallScreen once they accept, or shows why the call didn't connect
/// (declined / busy / no answer) if it ends before that.
class CallingScreen extends StatefulWidget {
  const CallingScreen({super.key});

  @override
  State<CallingScreen> createState() => _CallingScreenState();
}

class _CallingScreenState extends State<CallingScreen> {
  bool _handled = false;
  Timer? _noAnswerTimer;

  @override
  void initState() {
    super.initState();
    // Nobody picks up within 45s — give up and let the callee's screen
    // clear too (see AppState.noAnswerTimeout).
    _noAnswerTimer = Timer(const Duration(seconds: 45), () {
      final state = context.read<AppState>();
      if (state.callStage == CallStage.outgoingRinging) {
        state.noAnswerTimeout();
      }
    });
  }

  @override
  void dispose() {
    _noAnswerTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final peer = state.currentPeer;

    if (!_handled && state.callStage == CallStage.active) {
      _handled = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const ActiveCallScreen()));
      });
    } else if (!_handled && state.callStage != CallStage.outgoingRinging) {
      // Declined, busy, no answer, or a connection error — show why for a
      // moment, then close this screen.
      _handled = true;
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        await Future.delayed(const Duration(milliseconds: 1400));
        if (!mounted) return;
        Navigator.of(context).pop();
        context.read<AppState>().resetCall();
      });
    }

    final statusText = state.callFailureMessage ?? 'Ringing…';

    return Scaffold(
      backgroundColor: AppColors.bgApp,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              state.currentCallType == CallType.video ? 'VIDEO CALLING…' : 'AUDIO CALLING…',
              style: const TextStyle(color: AppColors.textDim, fontWeight: FontWeight.w700, letterSpacing: 1, fontSize: 13),
            ),
            const SizedBox(height: 24),
            AvatarCircle(initial: peer?.name.substring(0, 1) ?? '?', colorIndex: peer?.avatarColorIndex ?? 0, size: 150, fontSize: 48),
            const SizedBox(height: 24),
            Text(peer?.name ?? '', style: const TextStyle(color: AppColors.textMain, fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(statusText, style: const TextStyle(color: AppColors.textDim2, fontSize: 13)),
            const SizedBox(height: 50),
            GestureDetector(
              onTap: () {
                _handled = true;
                context.read<AppState>().cancelOutgoingCall();
                Navigator.of(context).pop();
              },
              child: Container(
                width: 64,
                height: 64,
                decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle),
                child: const Icon(Icons.call_end_rounded, color: Colors.white, size: 26),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
