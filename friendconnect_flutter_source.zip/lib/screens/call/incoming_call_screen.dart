import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/call_log_model.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/avatar_circle.dart';
import 'active_call_screen.dart';

/// Incoming call screen (female perspective demo).
class IncomingCallScreen extends StatelessWidget {
  const IncomingCallScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final peer = state.currentPeer;
    return Scaffold(
      backgroundColor: AppColors.bgApp,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              state.currentCallType == CallType.video ? 'INCOMING VIDEO CALL' : 'INCOMING AUDIO CALL',
              style: const TextStyle(color: AppColors.textDim, fontWeight: FontWeight.w700, letterSpacing: 1, fontSize: 13),
            ),
            const SizedBox(height: 24),
            AvatarCircle(initial: peer?.name.substring(0, 1) ?? '?', colorIndex: peer?.avatarColorIndex ?? 0, size: 150, fontSize: 48),
            const SizedBox(height: 24),
            Text(peer?.name ?? '', style: const TextStyle(color: AppColors.textMain, fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            if (AppState.earnRatePerMinuteFor(state.role) > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(color: AppColors.amber.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                child: Text('Earn ₹${AppState.earnRatePerMinuteFor(state.role).toStringAsFixed(0)} / min on this call', style: const TextStyle(color: AppColors.amber, fontWeight: FontWeight.w700, fontSize: 11)),
              ),
            const SizedBox(height: 60),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    GestureDetector(
                      onTap: () {
                        context.read<AppState>().resetCall();
                        Navigator.of(context).pop();
                      },
                      child: Container(
                        width: 64,
                        height: 64,
                        decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle),
                        child: const Icon(Icons.close_rounded, color: Colors.white, size: 26),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text('Decline', style: TextStyle(color: AppColors.textDim2, fontSize: 11)),
                  ],
                ),
                const SizedBox(width: 70),
                Column(
                  children: [
                    GestureDetector(
                      onTap: () {
                        final s = context.read<AppState>();
                        if (!s.canMakeOrReceiveCalls) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Please complete KYC verification before you can receive calls.')),
                          );
                          s.resetCall();
                          Navigator.of(context).pop();
                          return;
                        }
                        s.connectCall();
                        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const ActiveCallScreen()));
                      },
                      child: Container(
                        width: 64,
                        height: 64,
                        decoration: const BoxDecoration(color: AppColors.green, shape: BoxShape.circle),
                        child: const Icon(Icons.check_rounded, color: Colors.white, size: 26),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text('Accept', style: TextStyle(color: AppColors.textDim2, fontSize: 11)),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
