import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/call_log_model.dart';
import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/avatar_circle.dart';
import 'active_call_screen.dart';

/// Incoming call screen. Shown by the global watcher in HomeShell whenever
/// AppState.callStage flips to incomingRinging (a real call session from
/// another user — see AppState._listenIncomingCalls). Auto-closes itself if
/// the caller cancels or the ring times out before this user responds.
class IncomingCallScreen extends StatefulWidget {
  const IncomingCallScreen({super.key});

  @override
  State<IncomingCallScreen> createState() => _IncomingCallScreenState();
}

class _IncomingCallScreenState extends State<IncomingCallScreen> {
  bool _handled = false;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final peer = state.currentPeer;

    if (!_handled && state.callStage != CallStage.incomingRinging) {
      // The caller cancelled, or this ring timed out, before we answered.
      _handled = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) Navigator.of(context).pop();
      });
    }

    return Scaffold(
      backgroundColor: AppColors.bgApp,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              state.currentCallType == CallType.video ? 'INCOMING VIDEO CALL' : 'INCOMING AUDIO CALL',
              style: const TextStyle(color: AppColors.textDim, fontWeight: FontWeight.w700, letterSpacing: 1, fontSize: 13),
            ),
            const SizedBox(height: 24),
            AvatarCircle(initial: peer?.name.substring(0, 1) ?? '?', colorIndex: peer?.avatarColorIndex ?? 0, size: 150, fontSize: 48),
            const SizedBox(height: 24),
            Text(peer?.name ?? '', style: const TextStyle(color: AppColors.textMain, fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            if (AppState.earnRatePerMinuteFor(state.role) > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(color: AppColors.amber.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                child: Text('Earn ₹${AppState.earnRatePerMinuteFor(state.role).toStringAsFixed(0)} / min on this call', style: const TextStyle(color: AppColors.amber, fontWeight: FontWeight.w700, fontSize: 11)),
              ),
            const SizedBox(height: 60),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    GestureDetector(
                      onTap: () {
                        _handled = true;
                        context.read<AppState>().declineIncomingCall();
                        Navigator.of(context).pop();
                      },
                      child: Container(
                        width: 64,
                        height: 64,
                        decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle),
                        child: const Icon(Icons.close_rounded, color: Colors.white, size: 26),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text('Decline', style: TextStyle(color: AppColors.textDim2, fontSize: 11)),
                  ],
                ),
                const SizedBox(width: 70),
                Column(
                  children: [
                    GestureDetector(
                      onTap: () {
                        _handled = true;
                        context.read<AppState>().acceptIncomingCall();
                        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const ActiveCallScreen()));
                      },
                      child: Container(
                        width: 64,
                        height: 64,
                        decoration: const BoxDecoration(color: AppColors.green, shape: BoxShape.circle),
                        child: const Icon(Icons.check_rounded, color: Colors.white, size: 26),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text('Accept', style: TextStyle(color: AppColors.textDim2, fontSize: 11)),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
