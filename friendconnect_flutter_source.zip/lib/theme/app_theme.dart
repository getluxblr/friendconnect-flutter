import 'package:flutter/material.dart';

/// Color palette matching the FriendConnect UI mockups (dark purple / pink).
class AppColors {
  static const bgApp = Color(0xFF12081F);
  static const bgCard = Color(0xFF1C1030);
  static const bgCard2 = Color(0xFF241640);
  static const accent1 = Color(0xFFFF4D8D);
  static const accent2 = Color(0xFF8B5CF6);
  static const accent3 = Color(0xFF22D3EE);
  static const green = Color(0xFF22C55E);
  static const amber = Color(0xFFFBBF24);
  static const red = Color(0xFFEF4444);
  static const textMain = Color(0xFFF5F3FF);
  static const textDim = Color(0xFFB3A9D6);
  static const textDim2 = Color(0xFF8579AB);
  static const divider = Color(0xFF322155);

  /// Abstract gradient placeholders used for avatars (initials, not photos).
  static const avatarGradients = <List<Color>>[
    [Color(0xFFFF8A65), Color(0xFFFF4D8D)],
    [Color(0xFFA78BFA), Color(0xFF7C3AED)],
    [Color(0xFF22D3EE), Color(0xFF0EA5E9)],
    [Color(0xFFFACC15), Color(0xFFFB923C)],
    [Color(0xFF34D399), Color(0xFF059669)],
    [Color(0xFFF472B6), Color(0xFFC026D3)],
  ];
}

class AppTheme {
  static ThemeData get dark {
    return ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.bgApp,
      primaryColor: AppColors.accent2,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.accent2,
        secondary: AppColors.accent1,
        surface: AppColors.bgCard,
      ),
      textTheme: const TextTheme(
        bodyMedium: TextStyle(color: AppColors.textMain),
      ),
      dividerColor: AppColors.divider,
    );
  }
}
