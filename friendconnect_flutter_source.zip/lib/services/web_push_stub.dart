/// No-op stand-in used on every NON-web platform (Android/iOS), since
/// `dart:html` — used by the real implementation in `web_push_web.dart` —
/// only exists for web builds. AppState picks whichever of these two files
/// actually compiles via a conditional import:
///
///   import 'web_push_stub.dart' if (dart.library.html) 'web_push_web.dart';
///
/// On Android/iOS, real OS notifications are shown instead through
/// flutter_local_notifications, so this class simply does nothing there.
class WebPush {
  static Future<void> requestPermissionIfNeeded() async {}

  static void show({required String title, required String body}) {}
}
