import 'dart:html' as html;

/// Thin wrapper around the browser's native Notification API. This is what
/// lets an incoming call or an admin announcement show up as a real
/// OS-level notification (in the Windows/macOS/Chrome-OS notification
/// tray, exactly like a desktop chat app) instead of a popup drawn inside
/// the page itself. Only compiled into the web build — see the conditional
/// import in app_state.dart.
class WebPush {
  static bool _permissionRequested = false;

  static Future<void> requestPermissionIfNeeded() async {
    if (_permissionRequested) return;
    _permissionRequested = true;
    try {
      if (html.Notification.supported && html.Notification.permission == 'default') {
        await html.Notification.requestPermission();
      }
    } catch (_) {}
  }

  static void show({required String title, required String body}) {
    try {
      if (html.Notification.supported && html.Notification.permission == 'granted') {
        html.Notification(title, body: body);
      }
    } catch (_) {}
  }
}
