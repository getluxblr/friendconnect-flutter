import 'dart:convert';
import 'package:http/http.dart' as http;

/// Fills in the gap left by not having a paid Firebase Cloud Functions
/// plan: this calls a small free Cloudflare Worker (see
/// cloudflare-worker/index.js in the repo) the instant a call comes in or
/// an announcement is sent, so the OTHER person's device gets a real push
/// even if they don't have the app open right now. If the Worker isn't
/// set up yet (still shows the placeholder URL below) or the request
/// fails for any reason, this silently does nothing — the in-app,
/// app-open notification path is unaffected either way.
class PushRelay {
  // TODO: replace with the real Worker URL once it's deployed, e.g.
  // https://friendconnect-push-relay.<your-subdomain>.workers.dev
  static const String _relayUrl = 'https://REPLACE_ME.workers.dev';

  // Must match the RELAY_SECRET set on the Worker (Cloudflare dashboard →
  // Settings → Variables). This isn't hidden from anyone who inspects the
  // compiled app — it just stops random strangers on the internet from
  // using the Worker to spam pushes; it's not meant to be bank-vault
  // secure, only good enough for a small prototype like this one.
  static const String _sharedSecret = 'REPLACE_ME_TOO';

  static bool get isConfigured => !_relayUrl.contains('REPLACE_ME') && !_sharedSecret.contains('REPLACE_ME');

  static Future<void> send({
    required String token,
    required String title,
    required String message,
    Map<String, String>? data,
    String? channelId,
  }) async {
    if (!isConfigured) return;
    try {
      await http
          .post(
            Uri.parse(_relayUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'secret': _sharedSecret,
              'token': token,
              'title': title,
              'message': message,
              'data': data ?? {},
              'channelId': channelId,
            }),
          )
          .timeout(const Duration(seconds: 8));
    } catch (_) {
      // Best-effort — the app-open notification path already covers this
      // moment regardless of whether the push relay succeeds.
    }
  }
}
