import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';
import 'state/app_state.dart';
import 'theme/app_theme.dart';
import 'screens/auth/login_screen.dart';
import 'screens/home/home_shell.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Firebase powers the real-call signaling (Cloud Firestore) added for
  // testing actual audio/video calls between two devices. If it fails to
  // initialize (e.g. no network), the rest of the app still works — only
  // the "Test Real Video Call" screen depends on it.
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  } catch (e) {
    debugPrint('Firebase init failed: $e');
  }
  runApp(const FriendConnectApp());
}

class FriendConnectApp extends StatelessWidget {
  const FriendConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState(),
      child: MaterialApp(
        title: 'FriendConnect',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark,
        home: const RootRouter(),
        // This is a phone-shaped app. On a real phone the screen is already
        // narrow, so this has no effect — but on a desktop browser (web) the
        // whole UI would otherwise stretch edge-to-edge across a huge
        // viewport (giant avatar cards, oversized everything). Cap the
        // content at a sensible phone width and letterbox the rest so it
        // always looks like a proper app, not a stretched webpage.
        builder: (context, child) {
          return ColoredBox(
            color: const Color(0xFF0D0716),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: child,
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Swaps between the auth flow and the main app shell based on login state.
///
/// On startup, AppState checks whether Firebase already has a signed-in
/// user from a previous run (it persists this on its own — that's just not
/// something the app used to check). While that check is in flight we show
/// a brief splash instead of the login screen, so a returning user never
/// sees a flash of "please log in" before landing back in the app.
class RootRouter extends StatelessWidget {
  const RootRouter({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    if (state.isRestoringSession) {
      return const Scaffold(
        backgroundColor: Color(0xFF0D0716),
        body: Center(
          child: CircularProgressIndicator(color: Colors.white70),
        ),
      );
    }
    return state.isLoggedIn ? const HomeShell() : const LoginScreen();
  }
}
