import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';
import 'state/app_state.dart';
import 'theme/app_theme.dart';
import 'screens/auth/login_screen.dart';
import 'screens/home/home_shell.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Firebase powers the real-call signaling (Cloud Firestore) added for
  // testing actual audio/video calls between two devices. If it fails to
  // initialize (e.g. no network), the rest of the app still works — only
  // the "Test Real Video Call" screen depends on it.
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  } catch (e) {
    debugPrint('Firebase init failed: $e');
  }
  runApp(const FriendConnectApp());
}

class FriendConnectApp extends StatelessWidget {
  const FriendConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState(),
      child: MaterialApp(
        title: 'FriendConnect',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark,
        home: const RootRouter(),
      ),
    );
  }
}

/// Swaps between the auth flow and the main app shell based on login state.
class RootRouter extends StatelessWidget {
  const RootRouter({super.key});

  @override
  Widget build(BuildContext context) {
    final isLoggedIn = context.watch<AppState>().isLoggedIn;
    return isLoggedIn ? const HomeShell() : const LoginScreen();
  }
}
