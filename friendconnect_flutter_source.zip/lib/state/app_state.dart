import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user_model.dart';
import '../models/transaction_model.dart';
import '../models/call_log_model.dart';

enum UserRole { male, female }

enum CallStage { none, outgoingRinging, incomingRinging, active, ended }

/// Central in-memory state for the app.
///
/// Auth now goes through real Firebase Phone Authentication (real SMS OTP),
/// and the "online users" directory is a live Firestore query instead of a
/// hardcoded list — see [sendOtp], [verifyOtp] and [_listenOnlineUsers].
class AppState extends ChangeNotifier {
  AppState() {
    _restoreSession();
  }

  /// True while we're checking whether Firebase already has a signed-in
  /// user from a previous app run. The app should NOT show the login
  /// screen while this is true — Firebase Auth persists the session across
  /// closes/reopens on its own, so a returning user should land straight
  /// back in the app instead of being logged out every time.
  bool isRestoringSession = true;

  /// Runs once at startup. If Firebase already has a signed-in user (from
  /// a previous session — this persists locally on device/browser storage
  /// by default), silently reloads their profile and logs them back in
  /// without showing the login screen at all.
  Future<void> _restoreSession() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        firebaseUser = user;
        if ((user.phoneNumber ?? '').isNotEmpty) phoneNumber = user.phoneNumber!;
        final found = await _tryLoadExistingProfile();
        if (!found) {
          // Firebase still thinks we're signed in, but there's no matching
          // Firestore profile (or it couldn't be reached) — fall back to
          // the normal login flow rather than showing a broken app.
          firebaseUser = null;
        }
      }
    } catch (_) {
      // Leave the user logged out — they'll just see the login screen.
    } finally {
      isRestoringSession = false;
      notifyListeners();
    }
  }

  // Business rules surfaced in the UI.
  static const String workingHours = '9:00 AM – 6:00 PM';
  static const String paymentTat = '4 hours';
  static const int freeMinutesForMale = 30;
  static const double signupBonusForFemale = 300;
  static const int minAgeYears = 18;
  static const int _workingHourStart = 9; // 9 AM, 24h clock
  static const int _workingHourEnd = 18; // 6 PM, 24h clock

  /// Withdrawals (payouts to female users) are only processed during working
  /// hours. Adding money (recharge) is NOT gated by this — that can happen
  /// any time; only the team's callback to collect payment happens during
  /// working hours.
  bool get isWithinWorkingHours {
    final h = DateTime.now().hour;
    return h >= _workingHourStart && h < _workingHourEnd;
  }

  /// Validates a date of birth against the 18+ requirement. Returns a
  /// user-facing error message if invalid, or null if the DOB is acceptable.
  static String? ageValidationError(DateTime? dob) {
    if (dob == null) return 'Please enter your date of birth as per your documents.';
    final now = DateTime.now();
    if (dob.isAfter(now)) return 'Please enter a valid date of birth.';
    int age = now.year - dob.year;
    if (now.month < dob.month || (now.month == dob.month && now.day < dob.day)) {
      age--;
    }
    if (age < minAgeYears) {
      return 'You must be at least 18 years old to use FriendConnect. Please enter your date of birth as per your official documents.';
    }
    return null;
  }

  // Internal QA / admin test account — always gets a healthy wallet balance
  // regardless of role, so your team can test calls without running out of
  // credits. Matched on the last 10 digits so it works with or without a
  // country code prefix.
  static const String adminTestPhoneDigits = '6363958868';
  static const double adminTestWalletBalance = 5000;

  bool get _isAdminTestAccount {
    final digits = phoneNumber.replaceAll(RegExp(r'\D'), '');
    if (digits.isEmpty) return false;
    final last10 = digits.length >= 10 ? digits.substring(digits.length - 10) : digits;
    return last10 == adminTestPhoneDigits;
  }

  // ---------------- Auth ----------------
  bool isLoggedIn = false;
  String phoneNumber = '';
  UserRole role = UserRole.male;
  String myName = 'You';
  DateTime? dateOfBirth;

  bool otpSending = false;
  String? authError;
  User? firebaseUser;
  String? _verificationId;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  /// Kicks off real Firebase Phone Auth for [phone] (10-digit Indian
  /// number, spaces allowed). Returns the verificationId once the SMS has
  /// been sent, or null if sending failed (see [authError]).
  Future<String?> sendOtp(String phone) async {
    phoneNumber = phone;
    otpSending = true;
    authError = null;
    notifyListeners();

    final digits = phone.replaceAll(RegExp(r'\D'), '');
    final e164 = digits.startsWith('91') && digits.length > 10 ? '+$digits' : '+91$digits';

    final completer = Completer<String?>();
    try {
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: e164,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (PhoneAuthCredential credential) async {
          // Android instant/auto verification — sign in right away.
          try {
            await FirebaseAuth.instance.signInWithCredential(credential);
          } catch (_) {}
        },
        verificationFailed: (FirebaseAuthException e) {
          otpSending = false;
          authError = e.message ?? 'Could not send OTP. Please try again.';
          notifyListeners();
          if (!completer.isCompleted) completer.complete(null);
        },
        codeSent: (String verificationId, int? resendToken) {
          _verificationId = verificationId;
          otpSending = false;
          notifyListeners();
          if (!completer.isCompleted) completer.complete(verificationId);
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          _verificationId = verificationId;
        },
      );
    } catch (e) {
      otpSending = false;
      authError = 'Could not send OTP. Please try again.';
      notifyListeners();
      if (!completer.isCompleted) completer.complete(null);
    }
    return completer.future;
  }

  /// Verifies the real SMS code the user typed in, and on success signs
  /// them in with Firebase Auth. Returning users get their existing profile
  /// loaded back; brand-new users get the role/name picked on this screen
  /// plus their one-time signup bonus.
  Future<bool> verifyOtp(String smsCode, UserRole selectedRole, String displayName, DateTime? dob) async {
    if (_verificationId == null) {
      authError = 'Please request the OTP again.';
      notifyListeners();
      return false;
    }
    try {
      final credential = PhoneAuthProvider.credential(verificationId: _verificationId!, smsCode: smsCode.trim());
      final userCred = await FirebaseAuth.instance.signInWithCredential(credential);
      firebaseUser = userCred.user;
      authError = null;
      final existing = await _tryLoadExistingProfile();
      if (!existing) {
        // New signup — DOB is required and must clear the 18+ check before
        // we create the profile or grant any signup economics.
        final ageError = ageValidationError(dob);
        if (ageError != null) {
          authError = ageError;
          try {
            await FirebaseAuth.instance.signOut();
          } catch (_) {}
          firebaseUser = null;
          notifyListeners();
          return false;
        }
        role = selectedRole;
        myName = displayName.trim().isEmpty ? 'User' : displayName.trim();
        dateOfBirth = dob;
        _applySignupEconomics();
        isLoggedIn = true;
        await _publishMyProfile(isNewUser: true);
        await _syncWalletToFirestore();
        _listenOnlineUsers();
        _listenKycStatus();
        _listenWallet();
        _listenMyWithdrawals();
        _listenIncomingCalls();
        _listenAnnouncements();
      }
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      authError = e.message ?? 'Invalid code. Please try again.';
      notifyListeners();
      return false;
    } catch (e) {
      authError = 'Verification failed. Please try again.';
      notifyListeners();
      return false;
    }
  }

  /// Google Sign-In. Returns true if this is a returning user who is now
  /// fully logged in; false if this is a new account that still needs the
  /// name/role completion step (see [completeProfile]).
  Future<bool> signInWithGoogle() async {
    try {
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        authError = 'Sign-in cancelled.';
        notifyListeners();
        return false;
      }
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final userCred = await FirebaseAuth.instance.signInWithCredential(credential);
      firebaseUser = userCred.user;
      myName = userCred.user?.displayName ?? myName;
      authError = null;
      final existing = await _tryLoadExistingProfile();
      notifyListeners();
      return existing;
    } catch (e) {
      authError = 'Google sign-in failed. Please try again.';
      notifyListeners();
      return false;
    }
  }

  /// Creates a brand-new email/password account. Always needs the
  /// name/role completion step afterwards.
  Future<bool> signUpWithEmail(String email, String password) async {
    try {
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.trim(), password: password);
      firebaseUser = cred.user;
      authError = null;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      authError = e.message ?? 'Could not create account. Please try again.';
      notifyListeners();
      return false;
    }
  }

  /// Signs an existing email/password user back in. Returns true if their
  /// profile was found and they're now fully logged in.
  Future<bool> signInWithEmail(String email, String password) async {
    try {
      final cred = await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.trim(), password: password);
      firebaseUser = cred.user;
      authError = null;
      final existing = await _tryLoadExistingProfile();
      notifyListeners();
      return existing;
    } on FirebaseAuthException catch (e) {
      authError = e.message ?? 'Invalid email or password.';
      notifyListeners();
      return false;
    }
  }

  /// Completes sign-up for Google/Email accounts that don't yet have a
  /// Firestore profile — collects the name + role the phone flow gets from
  /// the OTP screen directly.
  Future<bool> completeProfile(String name, UserRole selectedRole, DateTime? dob) async {
    final ageError = ageValidationError(dob);
    if (ageError != null) {
      authError = ageError;
      notifyListeners();
      return false;
    }
    role = selectedRole;
    myName = name.trim().isEmpty ? 'User' : name.trim();
    dateOfBirth = dob;
    _applySignupEconomics();
    isLoggedIn = true;
    await _publishMyProfile(isNewUser: true);
    await _syncWalletToFirestore();
    _listenOnlineUsers();
    _listenKycStatus();
    _listenWallet();
    _listenMyWithdrawals();
    _listenIncomingCalls();
    _listenAnnouncements();
    notifyListeners();
    return true;
  }

  /// Looks up whether this Firebase user already has a Firestore profile
  /// (a returning user). If found, loads it and finishes login without
  /// touching wallet/earnings or re-granting the signup bonus.
  Future<bool> _tryLoadExistingProfile() async {
    final uid = firebaseUser?.uid;
    if (uid == null) return false;
    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (doc.exists) {
        final data = doc.data() ?? {};
        final name = (data['name'] as String?)?.trim();
        if (name != null && name.isNotEmpty) myName = name;
        final phone = data['phone'] as String?;
        if (phone != null && phone.isNotEmpty) phoneNumber = phone;
        role = (data['role'] == 'female') ? UserRole.female : UserRole.male;
        final dobTs = data['dob'];
        if (dobTs is Timestamp) dateOfBirth = dobTs.toDate();

        // Load the REAL wallet balance from Firestore — this is where any
        // recharge an admin approved in the CRM actually lives. Falls back
        // to the local default only if the wallet doc doesn't exist yet
        // (e.g. accounts created before this field was introduced).
        try {
          final walletDoc = await FirebaseFirestore.instance.collection('wallets').doc(uid).get();
          final bal = walletDoc.data()?['balance'];
          if (bal is num) walletBalance = bal.toDouble();
        } catch (_) {}

        if (_isAdminTestAccount && walletBalance < adminTestWalletBalance) {
          walletBalance = adminTestWalletBalance;
        }
        isLoggedIn = true;
        await _publishMyProfile();
        await _syncWalletToFirestore();
        _listenOnlineUsers();
        _listenKycStatus();
        _listenWallet();
        _listenMyWithdrawals();
        _listenIncomingCalls();
        _listenAnnouncements();
        return true;
      }
    } catch (_) {
      // Firestore unreachable — fall through and treat as a new signup.
    }
    return false;
  }

  /// One-time economics applied only when a Firestore profile is created
  /// for the very first time: 30 free calling minutes for male users, a
  /// ₹300 wallet welcome bonus for female users.
  void _applySignupEconomics() {
    if (_isAdminTestAccount) {
      walletBalance = adminTestWalletBalance;
      freeSecondsRemaining = freeMinutesForMale * 60;
      return;
    }
    if (role == UserRole.male) {
      walletBalance = 0;
      freeSecondsRemaining = freeMinutesForMale * 60;
    } else {
      walletBalance = signupBonusForFemale;
      transactions.insert(
        0,
        WalletTransaction(
          title: 'Signup Bonus',
          subtitle: 'Welcome to FriendConnect',
          amount: signupBonusForFemale,
          date: DateTime.now(),
          type: TransactionType.recharge,
        ),
      );
      todayEarnings = 0;
      weekEarnings = 0;
      monthEarnings = 0;
      lifetimeEarnings = 0;
    }
  }

  Future<void> _publishMyProfile({bool isNewUser = false}) async {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    try {
      final data = <String, dynamic>{
        'name': myName,
        'phone': phoneNumber,
        'role': role == UserRole.male ? 'male' : 'female',
        'online': amIOnline,
        'lastSeen': FieldValue.serverTimestamp(),
        if (dateOfBirth != null) 'dob': Timestamp.fromDate(dateOfBirth!),
      };
      // Only stamp createdAt the very first time this profile is published,
      // so repeat merges (login, toggling online) never overwrite it — the
      // CRM uses this for "new signups" reporting.
      if (isNewUser) data['createdAt'] = FieldValue.serverTimestamp();
      await FirebaseFirestore.instance.collection('users').doc(uid).set(data, SetOptions(merge: true));
    } catch (_) {
      // Non-fatal — the app still works locally if Firestore write fails.
    }
  }

  // ---------------- Wallet sync (Firestore) ----------------
  // Wallet balance is intentionally stored in its OWN collection
  // ('wallets/{uid}'), separate from the public 'users' profile doc that
  // opposite-role peers can list to find who's online. That query only ever
  // returns name/role/online — never financial data. The CRM (and this app)
  // read/write 'wallets/{uid}.balance' directly, so recharge credits an
  // admin approves in the CRM show up here live.
  StreamSubscription? _walletSub;

  Future<void> _syncWalletToFirestore() async {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    try {
      await FirebaseFirestore.instance.collection('wallets').doc(uid).set({
        'balance': walletBalance,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (_) {
      // Non-fatal — local balance still works if Firestore write fails.
    }
  }

  void _listenWallet() {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    _walletSub?.cancel();
    _walletSub = FirebaseFirestore.instance.collection('wallets').doc(uid).snapshots().listen((doc) {
      if (doc.exists) {
        final bal = doc.data()?['balance'];
        if (bal is num) {
          walletBalance = bal.toDouble();
          notifyListeners();
        }
      }
    }, onError: (_) {});
  }

  Future<void> _logWalletTransaction({required String type, required double amount, String? note}) async {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    try {
      await FirebaseFirestore.instance.collection('walletTransactions').add({
        'uid': uid,
        'name': myName,
        'phone': phoneNumber,
        'type': type,
        'amount': amount,
        if (note != null) 'note': note,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {
      // Non-fatal — this is a reporting ledger for the CRM, not core to the call/wallet flow.
    }
  }

  // ---------------- KYC (required for EVERY user before they can make or ----
  // ---------------- receive calls — reviewed manually by the ops team) -----
  // Status lives entirely in Firestore ('kyc/{uid}') so the telecalling team
  // can review and flip pending -> verified/rejected from the CRM. If nobody
  // reviews it within 12 hours, the app itself auto-approves it (see
  // [_maybeAutoApproveKyc]) — the security rule only allows that specific
  // pending->verified transition once 12 REAL hours have passed, checked by
  // Firestore's own server clock, so it can't be gamed by the device clock.
  static const Duration kycAutoApproveAfter = Duration(hours: 12);
  String kycStatus = 'not_submitted'; // not_submitted | pending | verified | rejected
  bool kycUploading = false;
  String? kycError;
  StreamSubscription? _kycSub;

  /// KYC is still collected and shown as a status badge, and still gets
  /// manually reviewed in the CRM (or auto-approved after 12h) — but per
  /// product decision it no longer blocks calling. Every user can make and
  /// receive calls regardless of KYC status.
  bool get canMakeOrReceiveCalls => true;

  void _listenKycStatus() {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    _kycSub?.cancel();
    _kycSub = FirebaseFirestore.instance.collection('kyc').doc(uid).snapshots().listen((doc) {
      if (doc.exists) {
        final data = doc.data() ?? {};
        kycStatus = (data['status'] as String?) ?? 'pending';
        _maybeAutoApproveKyc(uid, data);
      }
      notifyListeners();
    }, onError: (_) {});
  }

  /// If this KYC submission is still pending 12 hours after it was
  /// submitted, the app tries to flip it to verified itself. Firestore's
  /// security rules only permit this exact transition once
  /// `request.time` (the server's clock) is 12 hours past the server-set
  /// `submittedAt` — a user changing their phone's clock can't fake this.
  Future<void> _maybeAutoApproveKyc(String uid, Map<String, dynamic> data) async {
    if (data['status'] != 'pending') return;
    final submittedAt = data['submittedAt'];
    if (submittedAt is! Timestamp) return;
    if (DateTime.now().difference(submittedAt.toDate()) < kycAutoApproveAfter) return;
    try {
      await FirebaseFirestore.instance.collection('kyc').doc(uid).update({
        'status': 'verified',
        'reviewedAt': FieldValue.serverTimestamp(),
        'reviewedBy': 'auto-approved (12h SLA)',
      });
    } catch (_) {
      // Rules will reject this if the 12h window genuinely hasn't passed
      // yet (e.g. clock skew) — harmless, it'll retry next snapshot.
    }
  }

  /// KYC documents required from every user: Aadhaar front + back, PAN
  /// card, and a selfie. Takes raw bytes rather than dart:io's File so this
  /// works on both Android and Web — File/dart:io isn't available on
  /// Flutter Web at all. The caller (KycScreen) reads bytes from the
  /// image_picker XFile via readAsBytes(), which works on every platform.
  Future<bool> submitKyc({required Uint8List aadharFront, required Uint8List aadharBack, required Uint8List panCard, required Uint8List selfie}) async {
    final uid = firebaseUser?.uid;
    if (uid == null) return false;
    kycUploading = true;
    kycError = null;
    notifyListeners();
    try {
      Future<String> upload(Uint8List bytes, String name) async {
        final ref = FirebaseStorage.instance.ref('kyc/$uid/$name.jpg');
        await ref.putData(bytes, SettableMetadata(contentType: 'image/jpeg'));
        return ref.getDownloadURL();
      }

      final aadharFrontUrl = await upload(aadharFront, 'aadhar_front');
      final aadharBackUrl = await upload(aadharBack, 'aadhar_back');
      final panCardUrl = await upload(panCard, 'pan_card');
      final selfieUrl = await upload(selfie, 'selfie');
      await FirebaseFirestore.instance.collection('kyc').doc(uid).set({
        'name': myName,
        'phone': phoneNumber,
        'aadharFrontUrl': aadharFrontUrl,
        'aadharBackUrl': aadharBackUrl,
        'panCardUrl': panCardUrl,
        'selfieUrl': selfieUrl,
        'status': 'pending',
        'submittedAt': FieldValue.serverTimestamp(),
      });
      kycStatus = 'pending';
      kycUploading = false;
      notifyListeners();
      return true;
    } catch (e) {
      kycUploading = false;
      kycError = 'Upload failed. Check your connection and try again.';
      notifyListeners();
      return false;
    }
  }

  // ---------------- Wallet recharge (manual — ops team calls to collect payment) ----------------
  bool rechargeTicketRaised = false;
  double lastRechargeRequestAmount = 0;

  Future<bool> requestRecharge(double amount) async {
    final uid = firebaseUser?.uid;
    try {
      await FirebaseFirestore.instance.collection('rechargeTickets').add({
        'uid': uid,
        'name': myName,
        'phone': phoneNumber,
        'amount': amount,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });
      rechargeTicketRaised = true;
      lastRechargeRequestAmount = amount;
      notifyListeners();
      return true;
    } catch (e) {
      return false;
    }
  }

  StreamSubscription? _onlineUsersSub;

  /// Who to show in the browse grid: anyone can now call anyone (male-male,
  /// female-female, and both directions of male/female), so this is a
  /// client-side display filter rather than a query restriction.
  String genderFilter = 'all'; // all | male | female

  void setGenderFilter(String filter) {
    genderFilter = filter;
    notifyListeners();
  }

  List<UserProfile> get filteredOnlineUsers {
    final list = onlineUsers.where((u) => u.isOnline).toList();
    if (genderFilter == 'all') return list;
    return list.where((u) => u.gender == genderFilter).toList();
  }

  /// Live query of real Firestore-backed users who are currently marked
  /// online — this replaces the old hardcoded fake list. Lists BOTH roles
  /// (not just the opposite one) so any user can call any other user;
  /// [genderFilter] narrows what's shown in the UI.
  void _listenOnlineUsers() {
    _onlineUsersSub?.cancel();
    _onlineUsersSub = FirebaseFirestore.instance
        .collection('users')
        .where('online', isEqualTo: true)
        .snapshots()
        .listen((snapshot) {
      onlineUsers
        ..clear()
        ..addAll(snapshot.docs.where((d) => d.id != firebaseUser?.uid).map((d) {
          final data = d.data();
          final name = (data['name'] as String?)?.trim();
          final gender = (data['role'] == 'female') ? 'female' : 'male';
          return UserProfile(
            id: d.id,
            name: (name == null || name.isEmpty) ? 'User' : name,
            age: 24,
            language: 'English',
            country: 'India',
            city: 'India',
            gender: gender,
            avatarColorIndex: d.id.hashCode.abs() % 6,
          );
        }));
      notifyListeners();
    }, onError: (_) {});
  }

  Future<void> logout() async {
    final uid = firebaseUser?.uid;
    if (uid != null) {
      try {
        await FirebaseFirestore.instance.collection('users').doc(uid).update({'online': false});
      } catch (_) {}
    }
    await _onlineUsersSub?.cancel();
    _onlineUsersSub = null;
    await _kycSub?.cancel();
    _kycSub = null;
    await _walletSub?.cancel();
    _walletSub = null;
    await _withdrawalsSub?.cancel();
    _withdrawalsSub = null;
    _knownWithdrawalStatus.clear();
    withdrawalNotice = null;
    await _incomingCallsQuerySub?.cancel();
    _incomingCallsQuerySub = null;
    await _activeSessionSub?.cancel();
    _activeSessionSub = null;
    _mySessionId = null;
    callFailureMessage = null;
    callStage = CallStage.none;
    currentPeer = null;
    await _teardownWebRTC();
    _stopRingback();
    _stopRingtone();
    await _announcementsSub?.cancel();
    _announcementsSub = null;
    pendingAnnouncements.clear();
    try {
      await FirebaseAuth.instance.signOut();
    } catch (_) {}
    try {
      await _googleSignIn.signOut();
    } catch (_) {}
    isLoggedIn = false;
    firebaseUser = null;
    _verificationId = null;
    kycStatus = 'not_submitted';
    rechargeTicketRaised = false;
    onlineUsers.clear();
    notifyListeners();
  }

  // ---------------- Wallet ----------------
  double walletBalance = 240.0;
  // Whoever INITIATES a call pays this rate — men pay more than women.
  // Any user can call any other user (male-male, female-female, and both
  // directions of male/female); the rate depends on the CALLER's gender.
  static const double callRatePerMinuteMale = 5.0;
  static const double callRatePerMinuteFemale = 3.0;
  static double callRatePerMinuteFor(UserRole r) => r == UserRole.male ? callRatePerMinuteMale : callRatePerMinuteFemale;

  /// Bank of free calling seconds granted at signup (30 min for male
  /// users). Consumed before the wallet is ever charged.
  int freeSecondsRemaining = 0;
  int _chargedSecondsThisSession = 0;

  final List<WalletTransaction> transactions = [
    WalletTransaction(
      title: 'Call — Priya',
      subtitle: 'Today, 6:42 PM',
      amount: -65,
      date: DateTime.now(),
      type: TransactionType.callCharge,
    ),
    WalletTransaction(
      title: 'Recharge — UPI',
      subtitle: 'Today, 2:10 PM',
      amount: 500,
      date: DateTime.now(),
      type: TransactionType.recharge,
    ),
    WalletTransaction(
      title: 'Call — Sneha',
      subtitle: 'Yesterday, 9:05 PM',
      amount: -120,
      date: DateTime.now().subtract(const Duration(days: 1)),
      type: TransactionType.callCharge,
    ),
  ];

  void recharge(double amount, {double bonus = 0}) {
    walletBalance += amount + bonus;
    transactions.insert(
      0,
      WalletTransaction(
        title: 'Recharge — UPI',
        subtitle: 'Just now',
        amount: amount + bonus,
        date: DateTime.now(),
        type: TransactionType.recharge,
      ),
    );
    _syncWalletToFirestore();
    _logWalletTransaction(type: 'recharge', amount: amount + bonus, note: 'In-app recharge');
    notifyListeners();
  }

  // ---------------- Earnings ----------------
  // Only FEMALE users earn from receiving calls. Men get no free/earned
  // money from incoming calls (from either men or women) — they must
  // recharge their wallet to make outgoing calls.
  double todayEarnings = 180;
  double weekEarnings = 1240;
  double monthEarnings = 4860;
  double lifetimeEarnings = 28400;
  static const double earnRatePerMinute = 1.0;
  static double earnRatePerMinuteFor(UserRole r) => r == UserRole.female ? earnRatePerMinute : 0.0;
  final List<double> weeklyBars = [34, 52, 28, 68, 46, 80, 38];

  /// Set whenever a withdrawal request fails or is rejected, so the UI can
  /// show the exact reason (outside working hours, below minimum, or
  /// rejected for insufficient funds) instead of one generic message.
  String? lastWithdrawalError;
  bool withdrawalSubmitting = false;

  /// Raises a withdrawal request with the payout details the ops team needs
  /// to actually send the money (bank account or UPI) — this creates a
  /// ticket in Firestore ('withdrawalTickets') the CRM surfaces, mirroring
  /// how recharge requests work. [method] is 'bank' or 'upi'; [details]
  /// holds the form fields for that method.
  Future<bool> requestWithdrawal({
    required double amount,
    required String method,
    required Map<String, String> details,
  }) async {
    // Users can RAISE a withdrawal request any time, 24/7 — same as
    // recharge. Working hours only gate when the money actually gets
    // credited (the ops team processes/pays out requests during
    // $workingHours); it no longer blocks submitting the request itself.
    if (amount < 500) {
      lastWithdrawalError = 'Minimum withdrawal amount is ₹500.';
      notifyListeners();
      return false;
    }
    if (amount > lifetimeEarnings) {
      lastWithdrawalError = 'Rejected due to Insufficient Funds.';
      notifyListeners();
      return false;
    }
    withdrawalSubmitting = true;
    notifyListeners();
    final uid = firebaseUser?.uid;
    try {
      await FirebaseFirestore.instance.collection('withdrawalTickets').add({
        'uid': uid,
        'name': myName,
        'phone': phoneNumber,
        'amount': amount,
        'method': method,
        'details': details,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      withdrawalSubmitting = false;
      lastWithdrawalError = 'Could not raise the request. Please check your connection and try again.';
      notifyListeners();
      return false;
    }
    lifetimeEarnings -= amount;
    lastWithdrawalError = null;
    withdrawalSubmitting = false;
    notifyListeners();
    return true;
  }

  // ---------------- Withdrawal completion notice ----------------
  // The submit screen only shows a lightweight "request raised" acknowledgment
  // (see WithdrawScreen). The real "Congratulations / Rejected" popup fires
  // once the CRM actually marks the ticket paid/rejected — this listener
  // watches this user's own withdrawal tickets and surfaces that transition.
  StreamSubscription? _withdrawalsSub;
  final Map<String, String> _knownWithdrawalStatus = {};

  /// Non-null once a previously-pending withdrawal ticket has been marked
  /// paid or rejected by the CRM. UI shows a one-time popup then calls
  /// [clearWithdrawalNotice].
  Map<String, dynamic>? withdrawalNotice;

  void _listenMyWithdrawals() {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    _withdrawalsSub?.cancel();
    _withdrawalsSub = FirebaseFirestore.instance
        .collection('withdrawalTickets')
        .where('uid', isEqualTo: uid)
        .snapshots()
        .listen((snapshot) {
      for (final change in snapshot.docChanges) {
        final data = change.doc.data();
        if (data == null) continue;
        final status = data['status'] as String? ?? '';
        final id = change.doc.id;
        final prev = _knownWithdrawalStatus[id];
        _knownWithdrawalStatus[id] = status;
        if (change.type == DocumentChangeType.modified &&
            prev == 'pending' &&
            (status == 'paid' || status == 'rejected')) {
          final amount = (data['amount'] as num?)?.toDouble() ?? 0;
          withdrawalNotice = {'status': status, 'amount': amount};
          notifyListeners();
        }
      }
    }, onError: (_) {});
  }

  void clearWithdrawalNotice() {
    withdrawalNotice = null;
    notifyListeners();
  }

  // ---------------- Admin announcements (daily broadcast popup) ----------------
  // The CRM's "Announcements" tab lets an admin type a message and send it to
  // every user at once, on both the app and the web build. We watch the
  // 'announcements' collection for anything newer than the last one this
  // device has already shown (persisted locally via SharedPreferences, so a
  // relaunch doesn't replay the same popup, but a message sent while the app
  // was closed still shows the next time it's opened). Each unseen one is
  // queued in [pendingAnnouncements] and the UI (see HomeShell) pops them up
  // one at a time, on top of whatever screen the user is currently on.
  StreamSubscription? _announcementsSub;
  int _lastSeenAnnouncementMillis = 0;
  bool _announcementPrefsLoaded = false;
  final List<Map<String, dynamic>> pendingAnnouncements = [];

  void _listenAnnouncements() {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    _announcementsSub?.cancel();
    _announcementsSub = FirebaseFirestore.instance
        .collection('announcements')
        .orderBy('createdAt', descending: true)
        .limit(20)
        .snapshots()
        .listen((snapshot) async {
      if (!_announcementPrefsLoaded) {
        try {
          final prefs = await SharedPreferences.getInstance();
          _lastSeenAnnouncementMillis = prefs.getInt('lastSeenAnnouncementMillis') ?? 0;
        } catch (_) {}
        _announcementPrefsLoaded = true;
      }
      final fresh = <Map<String, dynamic>>[];
      for (final doc in snapshot.docs) {
        final data = doc.data();
        final ts = data['createdAt'];
        if (ts is! Timestamp) continue;
        if (ts.millisecondsSinceEpoch <= _lastSeenAnnouncementMillis) continue;
        if (pendingAnnouncements.any((a) => a['id'] == doc.id)) continue;
        fresh.add({'id': doc.id, 'message': (data['message'] as String? ?? '').trim(), 'createdAt': ts});
      }
      if (fresh.isEmpty) return;
      // Oldest first, so if several were sent while the user was away they
      // pop up in the order they were sent.
      fresh.sort((a, b) => (a['createdAt'] as Timestamp).compareTo(b['createdAt'] as Timestamp));
      pendingAnnouncements.addAll(fresh.where((a) => (a['message'] as String).isNotEmpty));
      notifyListeners();
    }, onError: (_) {});
  }

  /// Called by the UI once it has shown (and the user dismissed) an
  /// announcement popup. Advances the "last seen" watermark so it's never
  /// shown again on this device.
  Future<void> dismissAnnouncement(String id) async {
    final index = pendingAnnouncements.indexWhere((a) => a['id'] == id);
    if (index == -1) return;
    final ts = pendingAnnouncements[index]['createdAt'] as Timestamp;
    pendingAnnouncements.removeAt(index);
    if (ts.millisecondsSinceEpoch > _lastSeenAnnouncementMillis) {
      _lastSeenAnnouncementMillis = ts.millisecondsSinceEpoch;
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setInt('lastSeenAnnouncementMillis', _lastSeenAnnouncementMillis);
      } catch (_) {}
    }
    notifyListeners();
  }

  // ---------------- Online users (real Firestore directory) ----------------
  bool amIOnline = true;

  void toggleOnline(bool value) {
    amIOnline = value;
    notifyListeners();
    final uid = firebaseUser?.uid;
    if (uid != null) {
      FirebaseFirestore.instance.collection('users').doc(uid).update({
        'online': value,
        'lastSeen': FieldValue.serverTimestamp(),
      }).catchError((_) {});
    }
  }

  /// Populated live from Firestore once logged in (see [_listenOnlineUsers]).
  /// Starts empty — no more hardcoded fake profiles.
  final List<UserProfile> onlineUsers = [];

  // ---------------- Call state (real Firestore signaling) ----------------
  // Every call is backed by a doc in callSessions/{sessionId}: the caller
  // creates it with status 'ringing', the callee's device is watching a
  // live query for docs where calleeUid == them, and both sides then watch
  // that one doc for status changes (accepted / declined / busy / timeout /
  // cancelled / ended) to drive their local UI. This is what makes an
  // incoming call actually show up on the OTHER person's phone/browser —
  // previously this whole flow was 100% local with a hardcoded timer and
  // never touched Firestore at all.
  //
  // Caveat that still applies: this only delivers a "notification" while
  // the app is open (a live Firestore listener, foreground/backgrounded-but-
  // running). A true OS-level push notification for a fully closed app
  // needs Firebase Cloud Messaging + a server trigger, which needs the
  // Blaze billing plan — not part of this.
  CallStage callStage = CallStage.none;
  UserProfile? currentPeer;
  CallType currentCallType = CallType.audio;
  int callSeconds = 0;
  double sessionCharge = 0;
  double sessionEarning = 0;

  /// Non-null while a call session (ringing/active) exists in Firestore for
  /// this user's current call.
  String? _mySessionId;
  String? get currentCallSessionId => _mySessionId;

  /// Set when an outgoing call ends before being answered (declined, busy,
  /// no answer, or a connection error) so CallingScreen can show why.
  String? callFailureMessage;

  void clearCallFailureMessage() {
    callFailureMessage = null;
    notifyListeners();
  }

  Timer? _callTimer;
  StreamSubscription? _incomingCallsQuerySub;
  StreamSubscription? _activeSessionSub;

  // ---------------- Ringtone / ringback sound ----------------
  // Plays a looping tone while a call is ringing — a ringback ("purring")
  // tone for the person who's calling out, and a ringtone for the person
  // being called — so both sides actually hear something instead of a
  // silent screen. Stops the instant the call connects, is declined,
  // cancelled, times out, or ends.
  final AudioPlayer _ringbackPlayer = AudioPlayer();
  final AudioPlayer _ringtonePlayer = AudioPlayer();
  bool _ringbackPlaying = false;
  bool _ringtonePlaying = false;

  Future<void> _playRingback() async {
    if (_ringbackPlaying) return;
    _ringbackPlaying = true;
    try {
      await _ringbackPlayer.setReleaseMode(ReleaseMode.loop);
      await _ringbackPlayer.play(AssetSource('sounds/ringback.wav'), volume: 0.7);
    } catch (_) {}
  }

  Future<void> _stopRingback() async {
    if (!_ringbackPlaying) return;
    _ringbackPlaying = false;
    try {
      await _ringbackPlayer.stop();
    } catch (_) {}
  }

  Future<void> _playRingtone() async {
    if (_ringtonePlaying) return;
    _ringtonePlaying = true;
    try {
      await _ringtonePlayer.setReleaseMode(ReleaseMode.loop);
      await _ringtonePlayer.play(AssetSource('sounds/ringtone.wav'), volume: 0.9);
    } catch (_) {}
  }

  Future<void> _stopRingtone() async {
    if (!_ringtonePlaying) return;
    _ringtonePlaying = false;
    try {
      await _ringtonePlayer.stop();
    } catch (_) {}
  }

  // ---------------- Live audio/video media (WebRTC) ----------------
  // The callSessions doc above only carries signaling (who's calling whom,
  // ringing/accepted/etc). The actual voice/video is a direct WebRTC
  // peer-to-peer connection between the two devices — Firestore is used
  // only to exchange the one-time SDP offer/answer and ICE candidates
  // needed to establish that connection (same pattern already proven out
  // in the standalone "Test Real Video Call" screen), via subcollections
  // callSessions/{id}/callerCandidates and /calleeCandidates.
  static const Map<String, dynamic> _iceServers = {
    'iceServers': [
      {'urls': 'stun:stun.l.google.com:19302'},
      {'urls': 'stun:stun1.l.google.com:19302'},
      {'urls': 'stun:stun2.l.google.com:19302'},
    ],
  };

  RTCPeerConnection? _peerConnection;
  StreamSubscription? _remoteCandidatesSub;
  bool _remoteSdpApplied = false;

  /// This device's own camera/mic feed, once media has been opened. UI
  /// screens render this in a small self-preview for video calls.
  MediaStream? localStream;

  /// The other party's live audio/video feed, once the peer connection is
  /// up. UI screens render this full-screen for video calls; for audio
  /// calls it still needs to be attached to a (visually hidden) renderer
  /// on some platforms for the audio to actually play.
  MediaStream? remoteStream;

  bool isMicOn = true;
  bool isCameraOn = true;
  bool isSpeakerOn = false;

  Future<bool> _ensureMediaPermissions() async {
    // On web, getUserMedia() itself triggers the browser's own camera/mic
    // permission prompt — permission_handler doesn't (and can't) intercept
    // that, so skip it there and let getUserMedia do its thing.
    if (kIsWeb) return true;
    try {
      final statuses = await [Permission.camera, Permission.microphone].request();
      return statuses.values.every((s) => s.isGranted);
    } catch (_) {
      return true;
    }
  }

  Future<void> _openLocalMedia(CallType type) async {
    final stream = await navigator.mediaDevices.getUserMedia({
      'audio': true,
      'video': type == CallType.video ? {'facingMode': 'user'} : false,
    });
    localStream = stream;
    isMicOn = true;
    isCameraOn = type == CallType.video;
    notifyListeners();
  }

  Future<RTCPeerConnection> _createLocalPeerConnection() async {
    final pc = await createPeerConnection(_iceServers);
    for (final track in localStream?.getTracks() ?? const <MediaStreamTrack>[]) {
      await pc.addTrack(track, localStream!);
    }
    pc.onTrack = (RTCTrackEvent event) {
      if (event.streams.isNotEmpty) {
        remoteStream = event.streams[0];
        notifyListeners();
      }
    };
    pc.onConnectionState = (state) {
      if ((state == RTCPeerConnectionState.RTCPeerConnectionStateFailed ||
              state == RTCPeerConnectionState.RTCPeerConnectionStateDisconnected) &&
          callStage == CallStage.active) {
        endCall();
      }
    };
    return pc;
  }

  /// Caller side: opens the mic/camera, creates the peer connection, and
  /// publishes the SDP offer onto the session doc the callee is watching.
  /// Runs in the background right after the session doc is created — by
  /// the time the callee taps Accept, the offer is usually already there.
  Future<void> _startCallerMedia(String sessionId, CallType type) async {
    try {
      if (!await _ensureMediaPermissions()) {
        callFailureMessage = 'Camera/microphone permission denied.';
        notifyListeners();
        return;
      }
      if (_mySessionId != sessionId) return; // cancelled/changed while awaiting permission
      await _openLocalMedia(type);
      if (_mySessionId != sessionId) return; // cancelled/changed while opening media
      final pc = await _createLocalPeerConnection();
      if (_mySessionId != sessionId) {
        await pc.close();
        return;
      }
      _peerConnection = pc;
      _remoteSdpApplied = false;

      final sessionRef = FirebaseFirestore.instance.collection('callSessions').doc(sessionId);
      final callerCandidates = sessionRef.collection('callerCandidates');
      pc.onIceCandidate = (RTCIceCandidate candidate) {
        if (candidate.candidate == null || candidate.candidate!.isEmpty) return;
        callerCandidates.add(candidate.toMap()).catchError((_) {});
      };

      final offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await sessionRef.update({
        'offer': {'type': offer.type, 'sdp': offer.sdp},
      });

      _remoteCandidatesSub?.cancel();
      _remoteCandidatesSub = sessionRef.collection('calleeCandidates').snapshots().listen((snap) {
        for (final change in snap.docChanges) {
          if (change.type != DocumentChangeType.added) continue;
          final d = change.doc.data();
          if (d == null) continue;
          pc.addCandidate(RTCIceCandidate(d['candidate'], d['sdpMid'], d['sdpMLineIndex']));
        }
      });
    } catch (e) {
      debugPrint('Caller media setup failed: $e');
    }
  }

  /// Callee side: opens the mic/camera, creates the peer connection, waits
  /// for the caller's offer to show up on the session doc (it may not have
  /// landed yet if Accept was tapped very fast), and publishes the answer.
  Future<void> _startCalleeMedia(String sessionId, CallType type) async {
    try {
      if (!await _ensureMediaPermissions()) {
        callFailureMessage = 'Camera/microphone permission denied.';
        notifyListeners();
        return;
      }
      if (_mySessionId != sessionId) return;
      await _openLocalMedia(type);
      if (_mySessionId != sessionId) return;
      final pc = await _createLocalPeerConnection();
      if (_mySessionId != sessionId) {
        await pc.close();
        return;
      }
      _peerConnection = pc;
      _remoteSdpApplied = false;

      final sessionRef = FirebaseFirestore.instance.collection('callSessions').doc(sessionId);
      final calleeCandidates = sessionRef.collection('calleeCandidates');
      pc.onIceCandidate = (RTCIceCandidate candidate) {
        if (candidate.candidate == null || candidate.candidate!.isEmpty) return;
        calleeCandidates.add(candidate.toMap()).catchError((_) {});
      };

      bool answered = false;
      late final StreamSubscription offerSub;
      offerSub = sessionRef.snapshots().listen((doc) async {
        if (answered || _mySessionId != sessionId) return;
        final data = doc.data();
        final offer = data?['offer'];
        if (offer == null) return;
        answered = true;
        try {
          await pc.setRemoteDescription(RTCSessionDescription(offer['sdp'], offer['type']));
          _remoteSdpApplied = true;
          final answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          await sessionRef.update({
            'answer': {'type': answer.type, 'sdp': answer.sdp},
          });
        } catch (e) {
          debugPrint('Failed to answer call: $e');
        }
        offerSub.cancel();
      });

      _remoteCandidatesSub?.cancel();
      _remoteCandidatesSub = sessionRef.collection('callerCandidates').snapshots().listen((snap) {
        for (final change in snap.docChanges) {
          if (change.type != DocumentChangeType.added) continue;
          final d = change.doc.data();
          if (d == null) continue;
          pc.addCandidate(RTCIceCandidate(d['candidate'], d['sdpMid'], d['sdpMLineIndex']));
        }
      });
    } catch (e) {
      debugPrint('Callee media setup failed: $e');
    }
  }

  void toggleMic() {
    isMicOn = !isMicOn;
    for (final t in localStream?.getAudioTracks() ?? const <MediaStreamTrack>[]) {
      t.enabled = isMicOn;
    }
    notifyListeners();
  }

  void toggleCamera() {
    isCameraOn = !isCameraOn;
    for (final t in localStream?.getVideoTracks() ?? const <MediaStreamTrack>[]) {
      t.enabled = isCameraOn;
    }
    notifyListeners();
  }

  /// Earpiece/speakerphone switch — a mobile-only concept (native WebRTC
  /// audio routing). No-op on web, where the browser/OS handles output
  /// device selection.
  void toggleSpeaker() {
    isSpeakerOn = !isSpeakerOn;
    if (!kIsWeb) {
      try {
        Helper.setSpeakerphoneOn(isSpeakerOn);
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<void> _teardownWebRTC() async {
    await _remoteCandidatesSub?.cancel();
    _remoteCandidatesSub = null;
    try {
      for (final track in localStream?.getTracks() ?? const <MediaStreamTrack>[]) {
        await track.stop();
      }
    } catch (_) {}
    try {
      await localStream?.dispose();
    } catch (_) {}
    try {
      await _peerConnection?.close();
    } catch (_) {}
    localStream = null;
    remoteStream = null;
    _peerConnection = null;
    _remoteSdpApplied = false;
  }

  final List<CallLogEntry> callHistory = [];

  /// Whether the CURRENT user is the one who placed this call (pays) or
  /// received it (earns). Any user — regardless of gender — can be either,
  /// since calling is no longer restricted by role.
  bool isCallInitiator = true;

  /// This user places an outgoing call to [peer]. They pay for it. Flips
  /// local UI to "ringing" immediately, then creates the Firestore session
  /// doc in the background so the callee's device gets notified.
  void startOutgoingCall(UserProfile peer, CallType type) {
    currentPeer = peer;
    currentCallType = type;
    callStage = CallStage.outgoingRinging;
    callSeconds = 0;
    sessionCharge = 0;
    callFailureMessage = null;
    isCallInitiator = true;
    _activeSessionSub?.cancel();
    _activeSessionSub = null;
    _mySessionId = null;
    notifyListeners();
    _playRingback();
    _createCallSessionDoc(peer, type);
  }

  Future<void> _createCallSessionDoc(UserProfile peer, CallType type) async {
    final uid = firebaseUser?.uid;
    if (uid == null) {
      callFailureMessage = 'You need to be signed in to make calls.';
      callStage = CallStage.none;
      notifyListeners();
      return;
    }
    try {
      final doc = await FirebaseFirestore.instance.collection('callSessions').add({
        'callerUid': uid,
        'callerName': myName,
        'callerGender': role == UserRole.male ? 'male' : 'female',
        'calleeUid': peer.id,
        'calleeName': peer.name,
        'type': type == CallType.video ? 'video' : 'audio',
        'status': 'ringing',
        'createdAt': FieldValue.serverTimestamp(),
      });
      // If the user already cancelled (or started a different call) while
      // this write was in flight, don't wire it up — just mark it
      // cancelled server-side so it doesn't ring the callee forever.
      if (callStage == CallStage.outgoingRinging && currentPeer?.id == peer.id && _mySessionId == null) {
        _mySessionId = doc.id;
        _listenActiveSession(doc.id);
        _startCallerMedia(doc.id, type);
      } else {
        doc.update({'status': 'cancelled'}).catchError((_) {});
      }
    } catch (_) {
      if (callStage == CallStage.outgoingRinging) {
        callFailureMessage = 'Could not reach the server. Check your connection and try again.';
        callStage = CallStage.none;
        notifyListeners();
      }
    }
  }

  /// Always-on listener (started at login) for real incoming calls: any
  /// callSessions doc addressed to this user with status 'ringing'. This is
  /// what makes the OTHER person's device actually show an incoming-call
  /// screen when someone calls them.
  void _listenIncomingCalls() {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    _incomingCallsQuerySub?.cancel();
    _incomingCallsQuerySub = FirebaseFirestore.instance
        .collection('callSessions')
        .where('calleeUid', isEqualTo: uid)
        .where('status', isEqualTo: 'ringing')
        .snapshots()
        .listen((snapshot) {
      for (final change in snapshot.docChanges) {
        if (change.type != DocumentChangeType.added) continue;
        final data = change.doc.data();
        if (data == null) continue;
        final sessionId = change.doc.id;

        // Already on a call (or already ringing with someone else) — auto
        // decline as busy instead of interrupting the current call.
        if (callStage != CallStage.none) {
          FirebaseFirestore.instance
              .collection('callSessions')
              .doc(sessionId)
              .update({'status': 'busy', 'updatedAt': FieldValue.serverTimestamp()}).catchError((_) {});
          continue;
        }

        final callerName = (data['callerName'] as String?)?.trim();
        final callerGender = data['callerGender'] as String? ?? 'male';
        final typeStr = data['type'] as String? ?? 'audio';
        currentPeer = UserProfile(
          id: data['callerUid'] as String? ?? '',
          name: (callerName == null || callerName.isEmpty) ? 'User' : callerName,
          age: 24,
          language: 'English',
          country: 'India',
          city: 'India',
          gender: callerGender,
          avatarColorIndex: sessionId.hashCode.abs() % 6,
        );
        currentCallType = typeStr == 'video' ? CallType.video : CallType.audio;
        callStage = CallStage.incomingRinging;
        callSeconds = 0;
        sessionEarning = 0;
        callFailureMessage = null;
        isCallInitiator = false;
        _mySessionId = sessionId;
        _listenActiveSession(sessionId);
        _playRingtone();
        notifyListeners();
      }
    }, onError: (_) {});
  }

  /// Watches ONE call session doc for status changes made by the other
  /// party — used by both the caller (to learn accepted/declined/busy) and
  /// the callee (to learn the caller cancelled, or the ring timed out).
  void _listenActiveSession(String sessionId) {
    _activeSessionSub?.cancel();
    _activeSessionSub = FirebaseFirestore.instance.collection('callSessions').doc(sessionId).snapshots().listen((doc) {
      if (_mySessionId != sessionId) return;
      final data = doc.data();
      if (data == null) return;
      final status = data['status'] as String? ?? '';

      // The callee's answer can land on this same doc at any point once
      // they've accepted — apply it to our peer connection the moment it
      // shows up (guarded so it's only ever applied once).
      final answer = data['answer'];
      if (answer != null && isCallInitiator && !_remoteSdpApplied && _peerConnection != null) {
        _remoteSdpApplied = true;
        _peerConnection!.setRemoteDescription(RTCSessionDescription(answer['sdp'], answer['type'])).catchError((e) {
          debugPrint('Failed to apply answer: $e');
        });
      }

      if (status == 'accepted' && isCallInitiator && callStage == CallStage.outgoingRinging) {
        connectCall();
      } else if (status == 'declined' && callStage == CallStage.outgoingRinging) {
        _finishOutgoingWithMessage('Call declined');
      } else if (status == 'busy' && callStage == CallStage.outgoingRinging) {
        _finishOutgoingWithMessage('User is busy on another call');
      } else if (status == 'timeout') {
        if (callStage == CallStage.outgoingRinging) {
          _finishOutgoingWithMessage('No answer');
        } else if (callStage == CallStage.incomingRinging) {
          _endIncomingLocally();
        }
      } else if (status == 'cancelled' && callStage == CallStage.incomingRinging) {
        _endIncomingLocally();
      } else if (status == 'ended' && callStage == CallStage.active) {
        endCall();
      }
    }, onError: (_) {});
  }

  void _finishOutgoingWithMessage(String message) {
    _stopRingback();
    _activeSessionSub?.cancel();
    _activeSessionSub = null;
    callStage = CallStage.none;
    callFailureMessage = message;
    notifyListeners();
  }

  void _endIncomingLocally() {
    _stopRingtone();
    _activeSessionSub?.cancel();
    _activeSessionSub = null;
    _mySessionId = null;
    callStage = CallStage.none;
    currentPeer = null;
    notifyListeners();
  }

  /// Callee accepts the ringing call. Connects locally right away for a
  /// snappy UI, and tells Firestore in the background so the caller's
  /// screen advances too.
  Future<void> acceptIncomingCall() async {
    final sessionId = _mySessionId;
    final type = currentCallType;
    connectCall();
    if (sessionId != null) {
      _startCalleeMedia(sessionId, type);
      try {
        await FirebaseFirestore.instance
            .collection('callSessions')
            .doc(sessionId)
            .update({'status': 'accepted', 'updatedAt': FieldValue.serverTimestamp()});
      } catch (_) {}
    }
  }

  /// Callee declines the ringing call.
  Future<void> declineIncomingCall() async {
    final sessionId = _mySessionId;
    if (sessionId != null) {
      try {
        await FirebaseFirestore.instance
            .collection('callSessions')
            .doc(sessionId)
            .update({'status': 'declined', 'updatedAt': FieldValue.serverTimestamp()});
      } catch (_) {}
    }
    resetCall();
  }

  /// Caller cancels before the callee answered.
  Future<void> cancelOutgoingCall() async {
    final sessionId = _mySessionId;
    if (sessionId != null) {
      try {
        await FirebaseFirestore.instance
            .collection('callSessions')
            .doc(sessionId)
            .update({'status': 'cancelled', 'updatedAt': FieldValue.serverTimestamp()});
      } catch (_) {}
    }
    resetCall();
  }

  /// Caller gives up after ringing too long with no answer.
  Future<void> noAnswerTimeout() async {
    final sessionId = _mySessionId;
    if (sessionId != null) {
      try {
        await FirebaseFirestore.instance
            .collection('callSessions')
            .doc(sessionId)
            .update({'status': 'timeout', 'updatedAt': FieldValue.serverTimestamp()});
      } catch (_) {}
    }
    if (callStage == CallStage.outgoingRinging) {
      _finishOutgoingWithMessage('No answer');
    }
  }

  /// Called once the call is actually connected (either the callee just
  /// accepted, or — on the caller's side — the accepted status arrived via
  /// [_listenActiveSession]). Starts the per-second timer that drives
  /// per-minute billing.
  void connectCall() {
    _stopRingback();
    _stopRingtone();
    callStage = CallStage.active;
    callSeconds = 0;
    _chargedSecondsThisSession = 0;
    _callTimer?.cancel();
    _callTimer = Timer.periodic(const Duration(seconds: 1), (_) => _onTick());
    notifyListeners();
  }

  void _onTick() {
    callSeconds++;

    if (isCallInitiator) {
      // The 30 free minutes are a male-signup perk only — everyone else
      // (including female callers spending their wallet/signup bonus) is
      // charged from the very first second.
      if (role == UserRole.male && freeSecondsRemaining > 0) {
        // Still inside the 30 free minutes — no charge, no ledger entry.
        freeSecondsRemaining--;
      } else {
        _chargedSecondsThisSession++;
        final rate = callRatePerMinuteFor(role);
        sessionCharge = (_chargedSecondsThisSession / 60.0) * rate;
        if (walletBalance - sessionCharge <= 0) {
          walletBalance = 0;
          endCall();
          return;
        }
        // Apply the actual per-minute ledger entry every 60 charged
        // seconds — ₹5/min for men, ₹3/min for women.
        if (_chargedSecondsThisSession % 60 == 0) {
          walletBalance -= rate;
          if (walletBalance < 0) walletBalance = 0;
          transactions.insert(
            0,
            WalletTransaction(
              title: 'Call — ${currentPeer?.name ?? ""}',
              subtitle: 'Just now',
              amount: -rate,
              date: DateTime.now(),
              type: TransactionType.callCharge,
            ),
          );
          _syncWalletToFirestore();
          _logWalletTransaction(type: 'callCharge', amount: -rate, note: currentPeer?.name);
        }
      }
    } else {
      // Receiving a call: only women earn (₹1/min). Men get nothing for
      // incoming calls — they need to recharge to make their own calls.
      final earnRate = earnRatePerMinuteFor(role);
      if (earnRate > 0) {
        sessionEarning = (callSeconds / 60.0) * earnRate;
        if (callSeconds % 60 == 0) {
          todayEarnings += earnRate;
          weekEarnings += earnRate;
          monthEarnings += earnRate;
          lifetimeEarnings += earnRate;
        }
      } else {
        sessionEarning = 0;
      }
    }

    notifyListeners();
  }

  void endCall() {
    _stopRingback();
    _stopRingtone();
    _callTimer?.cancel();
    // Tell Firestore the call is over so the OTHER party's device (which is
    // watching this same session doc) ends its side too, even if they
    // didn't press hang-up themselves.
    final sessionId = _mySessionId;
    if (sessionId != null) {
      FirebaseFirestore.instance
          .collection('callSessions')
          .doc(sessionId)
          .update({'status': 'ended', 'updatedAt': FieldValue.serverTimestamp()}).catchError((_) {});
    }
    // Turn the camera/mic off and close the peer connection right away —
    // no reason to keep media live once the call has ended.
    _teardownWebRTC();
    if (currentPeer != null && callSeconds > 0) {
      callHistory.insert(
        0,
        CallLogEntry(
          peer: currentPeer!,
          type: currentCallType,
          outcome: CallOutcome.completed,
          durationSeconds: callSeconds,
          charge: isCallInitiator ? sessionCharge : sessionEarning,
          wasCaller: isCallInitiator,
          timestamp: DateTime.now(),
        ),
      );
    }
    callStage = CallStage.ended;
    notifyListeners();
  }

  void resetCall() {
    _stopRingback();
    _stopRingtone();
    _callTimer?.cancel();
    _activeSessionSub?.cancel();
    _activeSessionSub = null;
    _mySessionId = null;
    callFailureMessage = null;
    callStage = CallStage.none;
    currentPeer = null;
    callSeconds = 0;
    sessionCharge = 0;
    sessionEarning = 0;
    _teardownWebRTC();
    notifyListeners();
  }

  @override
  void dispose() {
    _callTimer?.cancel();
    _onlineUsersSub?.cancel();
    _kycSub?.cancel();
    _walletSub?.cancel();
    _withdrawalsSub?.cancel();
    _incomingCallsQuerySub?.cancel();
    _activeSessionSub?.cancel();
    _remoteCandidatesSub?.cancel();
    _announcementsSub?.cancel();
    _teardownWebRTC();
    _ringbackPlayer.dispose();
    _ringtonePlayer.dispose();
    super.dispose();
  }

  // ---------------- Profile editing ----------------
  /// Updates the display name shown across the app and pushes it to the
  /// public 'users/{uid}' profile doc so it's reflected for other users too.
  Future<bool> updateName(String newName) async {
    final trimmed = newName.trim();
    if (trimmed.isEmpty) return false;
    myName = trimmed;
    notifyListeners();
    await _publishMyProfile();
    return true;
  }

  // ---------------- Notification settings ----------------
  // Simple local preferences (no backend needed — these just control
  // whether in-app popups/snackbars show for each category).
  bool notifyCallAlerts = true;
  bool notifyWithdrawalUpdates = true;
  bool notifyPromotions = false;

  void setNotifyCallAlerts(bool v) {
    notifyCallAlerts = v;
    notifyListeners();
  }

  void setNotifyWithdrawalUpdates(bool v) {
    notifyWithdrawalUpdates = v;
    notifyListeners();
  }

  void setNotifyPromotions(bool v) {
    notifyPromotions = v;
    notifyListeners();
  }

  // ---------------- Blocked users ----------------
  // Local list for now — no in-app "block" action exists elsewhere yet, but
  // the screen is fully functional (shows a real empty state, and this list
  // is ready to be populated once a "block" action is added to call/profile
  // screens).
  final List<String> blockedUserNames = [];

  void unblockUser(String name) {
    blockedUserNames.remove(name);
    notifyListeners();
  }
}
