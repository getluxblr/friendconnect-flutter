import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../models/user_model.dart';
import '../models/transaction_model.dart';
import '../models/call_log_model.dart';

enum UserRole { male, female }

enum CallStage { none, outgoingRinging, incomingRinging, active, ended }

/// Central in-memory state for the app.
///
/// Auth now goes through real Firebase Phone Authentication (real SMS OTP),
/// and the "online users" directory is a live Firestore query instead of a
/// hardcoded list — see [sendOtp], [verifyOtp] and [_listenOnlineUsers].
class AppState extends ChangeNotifier {
  // Business rules surfaced in the UI.
  static const String workingHours = '9:00 AM – 6:00 PM';
  static const String paymentTat = '4 hours';
  static const int freeMinutesForMale = 30;
  static const double signupBonusForFemale = 300;
  static const int minAgeYears = 18;
  static const int _workingHourStart = 9; // 9 AM, 24h clock
  static const int _workingHourEnd = 18; // 6 PM, 24h clock

  /// Withdrawals (payouts to female users) are only processed during working
  /// hours. Adding money (recharge) is NOT gated by this — that can happen
  /// any time; only the team's callback to collect payment happens during
  /// working hours.
  bool get isWithinWorkingHours {
    final h = DateTime.now().hour;
    return h >= _workingHourStart && h < _workingHourEnd;
  }

  /// Validates a date of birth against the 18+ requirement. Returns a
  /// user-facing error message if invalid, or null if the DOB is acceptable.
  static String? ageValidationError(DateTime? dob) {
    if (dob == null) return 'Please enter your date of birth as per your documents.';
    final now = DateTime.now();
    if (dob.isAfter(now)) return 'Please enter a valid date of birth.';
    int age = now.year - dob.year;
    if (now.month < dob.month || (now.month == dob.month && now.day < dob.day)) {
      age--;
    }
    if (age < minAgeYears) {
      return 'You must be at least 18 years old to use FriendConnect. Please enter your date of birth as per your official documents.';
    }
    return null;
  }

  // Internal QA / admin test account — always gets a healthy wallet balance
  // regardless of role, so your team can test calls without running out of
  // credits. Matched on the last 10 digits so it works with or without a
  // country code prefix.
  static const String adminTestPhoneDigits = '6363958868';
  static const double adminTestWalletBalance = 5000;

  bool get _isAdminTestAccount {
    final digits = phoneNumber.replaceAll(RegExp(r'\D'), '');
    if (digits.isEmpty) return false;
    final last10 = digits.length >= 10 ? digits.substring(digits.length - 10) : digits;
    return last10 == adminTestPhoneDigits;
  }

  // ---------------- Auth ----------------
  bool isLoggedIn = false;
  String phoneNumber = '';
  UserRole role = UserRole.male;
  String myName = 'You';
  DateTime? dateOfBirth;

  bool otpSending = false;
  String? authError;
  User? firebaseUser;
  String? _verificationId;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  /// Kicks off real Firebase Phone Auth for [phone] (10-digit Indian
  /// number, spaces allowed). Returns the verificationId once the SMS has
  /// been sent, or null if sending failed (see [authError]).
  Future<String?> sendOtp(String phone) async {
    phoneNumber = phone;
    otpSending = true;
    authError = null;
    notifyListeners();

    final digits = phone.replaceAll(RegExp(r'\D'), '');
    final e164 = digits.startsWith('91') && digits.length > 10 ? '+$digits' : '+91$digits';

    final completer = Completer<String?>();
    try {
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: e164,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (PhoneAuthCredential credential) async {
          // Android instant/auto verification — sign in right away.
          try {
            await FirebaseAuth.instance.signInWithCredential(credential);
          } catch (_) {}
        },
        verificationFailed: (FirebaseAuthException e) {
          otpSending = false;
          authError = e.message ?? 'Could not send OTP. Please try again.';
          notifyListeners();
          if (!completer.isCompleted) completer.complete(null);
        },
        codeSent: (String verificationId, int? resendToken) {
          _verificationId = verificationId;
          otpSending = false;
          notifyListeners();
          if (!completer.isCompleted) completer.complete(verificationId);
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          _verificationId = verificationId;
        },
      );
    } catch (e) {
      otpSending = false;
      authError = 'Could not send OTP. Please try again.';
      notifyListeners();
      if (!completer.isCompleted) completer.complete(null);
    }
    return completer.future;
  }

  /// Verifies the real SMS code the user typed in, and on success signs
  /// them in with Firebase Auth. Returning users get their existing profile
  /// loaded back; brand-new users get the role/name picked on this screen
  /// plus their one-time signup bonus.
  Future<bool> verifyOtp(String smsCode, UserRole selectedRole, String displayName, DateTime? dob) async {
    if (_verificationId == null) {
      authError = 'Please request the OTP again.';
      notifyListeners();
      return false;
    }
    try {
      final credential = PhoneAuthProvider.credential(verificationId: _verificationId!, smsCode: smsCode.trim());
      final userCred = await FirebaseAuth.instance.signInWithCredential(credential);
      firebaseUser = userCred.user;
      authError = null;
      final existing = await _tryLoadExistingProfile();
      if (!existing) {
        // New signup — DOB is required and must clear the 18+ check before
        // we create the profile or grant any signup economics.
        final ageError = ageValidationError(dob);
        if (ageError != null) {
          authError = ageError;
          try {
            await FirebaseAuth.instance.signOut();
          } catch (_) {}
          firebaseUser = null;
          notifyListeners();
          return false;
        }
        role = selectedRole;
        myName = displayName.trim().isEmpty ? 'User' : displayName.trim();
        dateOfBirth = dob;
        _applySignupEconomics();
        isLoggedIn = true;
        await _publishMyProfile(isNewUser: true);
        await _syncWalletToFirestore();
        _listenOnlineUsers();
        _listenKycStatus();
        _listenWallet();
        _listenMyWithdrawals();
      }
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      authError = e.message ?? 'Invalid code. Please try again.';
      notifyListeners();
      return false;
    } catch (e) {
      authError = 'Verification failed. Please try again.';
      notifyListeners();
      return false;
    }
  }

  /// Google Sign-In. Returns true if this is a returning user who is now
  /// fully logged in; false if this is a new account that still needs the
  /// name/role completion step (see [completeProfile]).
  Future<bool> signInWithGoogle() async {
    try {
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        authError = 'Sign-in cancelled.';
        notifyListeners();
        return false;
      }
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final userCred = await FirebaseAuth.instance.signInWithCredential(credential);
      firebaseUser = userCred.user;
      myName = userCred.user?.displayName ?? myName;
      authError = null;
      final existing = await _tryLoadExistingProfile();
      notifyListeners();
      return existing;
    } catch (e) {
      authError = 'Google sign-in failed. Please try again.';
      notifyListeners();
      return false;
    }
  }

  /// Creates a brand-new email/password account. Always needs the
  /// name/role completion step afterwards.
  Future<bool> signUpWithEmail(String email, String password) async {
    try {
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.trim(), password: password);
      firebaseUser = cred.user;
      authError = null;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      authError = e.message ?? 'Could not create account. Please try again.';
      notifyListeners();
      return false;
    }
  }

  /// Signs an existing email/password user back in. Returns true if their
  /// profile was found and they're now fully logged in.
  Future<bool> signInWithEmail(String email, String password) async {
    try {
      final cred = await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.trim(), password: password);
      firebaseUser = cred.user;
      authError = null;
      final existing = await _tryLoadExistingProfile();
      notifyListeners();
      return existing;
    } on FirebaseAuthException catch (e) {
      authError = e.message ?? 'Invalid email or password.';
      notifyListeners();
      return false;
    }
  }

  /// Completes sign-up for Google/Email accounts that don't yet have a
  /// Firestore profile — collects the name + role the phone flow gets from
  /// the OTP screen directly.
  Future<bool> completeProfile(String name, UserRole selectedRole, DateTime? dob) async {
    final ageError = ageValidationError(dob);
    if (ageError != null) {
      authError = ageError;
      notifyListeners();
      return false;
    }
    role = selectedRole;
    myName = name.trim().isEmpty ? 'User' : name.trim();
    dateOfBirth = dob;
    _applySignupEconomics();
    isLoggedIn = true;
    await _publishMyProfile(isNewUser: true);
    await _syncWalletToFirestore();
    _listenOnlineUsers();
    _listenKycStatus();
    _listenWallet();
    _listenMyWithdrawals();
    notifyListeners();
    return true;
  }

  /// Looks up whether this Firebase user already has a Firestore profile
  /// (a returning user). If found, loads it and finishes login without
  /// touching wallet/earnings or re-granting the signup bonus.
  Future<bool> _tryLoadExistingProfile() async {
    final uid = firebaseUser?.uid;
    if (uid == null) return false;
    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (doc.exists) {
        final data = doc.data() ?? {};
        final name = (data['name'] as String?)?.trim();
        if (name != null && name.isNotEmpty) myName = name;
        final phone = data['phone'] as String?;
        if (phone != null && phone.isNotEmpty) phoneNumber = phone;
        role = (data['role'] == 'female') ? UserRole.female : UserRole.male;
        final dobTs = data['dob'];
        if (dobTs is Timestamp) dateOfBirth = dobTs.toDate();

        // Load the REAL wallet balance from Firestore — this is where any
        // recharge an admin approved in the CRM actually lives. Falls back
        // to the local default only if the wallet doc doesn't exist yet
        // (e.g. accounts created before this field was introduced).
        try {
          final walletDoc = await FirebaseFirestore.instance.collection('wallets').doc(uid).get();
          final bal = walletDoc.data()?['balance'];
          if (bal is num) walletBalance = bal.toDouble();
        } catch (_) {}

        if (_isAdminTestAccount && walletBalance < adminTestWalletBalance) {
          walletBalance = adminTestWalletBalance;
        }
        isLoggedIn = true;
        await _publishMyProfile();
        await _syncWalletToFirestore();
        _listenOnlineUsers();
        _listenKycStatus();
        _listenWallet();
        _listenMyWithdrawals();
        return true;
      }
    } catch (_) {
      // Firestore unreachable — fall through and treat as a new signup.
    }
    return false;
  }

  /// One-time economics applied only when a Firestore profile is created
  /// for the very first time: 30 free calling minutes for male users, a
  /// ₹300 wallet welcome bonus for female users.
  void _applySignupEconomics() {
    if (_isAdminTestAccount) {
      walletBalance = adminTestWalletBalance;
      freeSecondsRemaining = freeMinutesForMale * 60;
      return;
    }
    if (role == UserRole.male) {
      walletBalance = 0;
      freeSecondsRemaining = freeMinutesForMale * 60;
    } else {
      walletBalance = signupBonusForFemale;
      transactions.insert(
        0,
        WalletTransaction(
          title: 'Signup Bonus',
          subtitle: 'Welcome to FriendConnect',
          amount: signupBonusForFemale,
          date: DateTime.now(),
          type: TransactionType.recharge,
        ),
      );
      todayEarnings = 0;
      weekEarnings = 0;
      monthEarnings = 0;
      lifetimeEarnings = 0;
    }
  }

  Future<void> _publishMyProfile({bool isNewUser = false}) async {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    try {
      final data = <String, dynamic>{
        'name': myName,
        'phone': phoneNumber,
        'role': role == UserRole.male ? 'male' : 'female',
        'online': amIOnline,
        'lastSeen': FieldValue.serverTimestamp(),
        if (dateOfBirth != null) 'dob': Timestamp.fromDate(dateOfBirth!),
      };
      // Only stamp createdAt the very first time this profile is published,
      // so repeat merges (login, toggling online) never overwrite it — the
      // CRM uses this for "new signups" reporting.
      if (isNewUser) data['createdAt'] = FieldValue.serverTimestamp();
      await FirebaseFirestore.instance.collection('users').doc(uid).set(data, SetOptions(merge: true));
    } catch (_) {
      // Non-fatal — the app still works locally if Firestore write fails.
    }
  }

  // ---------------- Wallet sync (Firestore) ----------------
  // Wallet balance is intentionally stored in its OWN collection
  // ('wallets/{uid}'), separate from the public 'users' profile doc that
  // opposite-role peers can list to find who's online. That query only ever
  // returns name/role/online — never financial data. The CRM (and this app)
  // read/write 'wallets/{uid}.balance' directly, so recharge credits an
  // admin approves in the CRM show up here live.
  StreamSubscription? _walletSub;

  Future<void> _syncWalletToFirestore() async {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    try {
      await FirebaseFirestore.instance.collection('wallets').doc(uid).set({
        'balance': walletBalance,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (_) {
      // Non-fatal — local balance still works if Firestore write fails.
    }
  }

  void _listenWallet() {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    _walletSub?.cancel();
    _walletSub = FirebaseFirestore.instance.collection('wallets').doc(uid).snapshots().listen((doc) {
      if (doc.exists) {
        final bal = doc.data()?['balance'];
        if (bal is num) {
          walletBalance = bal.toDouble();
          notifyListeners();
        }
      }
    }, onError: (_) {});
  }

  Future<void> _logWalletTransaction({required String type, required double amount, String? note}) async {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    try {
      await FirebaseFirestore.instance.collection('walletTransactions').add({
        'uid': uid,
        'name': myName,
        'phone': phoneNumber,
        'type': type,
        'amount': amount,
        if (note != null) 'note': note,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {
      // Non-fatal — this is a reporting ledger for the CRM, not core to the call/wallet flow.
    }
  }

  // ---------------- KYC (required for EVERY user before they can make or ----
  // ---------------- receive calls — reviewed manually by the ops team) -----
  // Status lives entirely in Firestore ('kyc/{uid}') so the telecalling team
  // can review and flip pending -> verified/rejected from the CRM. If nobody
  // reviews it within 12 hours, the app itself auto-approves it (see
  // [_maybeAutoApproveKyc]) — the security rule only allows that specific
  // pending->verified transition once 12 REAL hours have passed, checked by
  // Firestore's own server clock, so it can't be gamed by the device clock.
  static const Duration kycAutoApproveAfter = Duration(hours: 12);
  String kycStatus = 'not_submitted'; // not_submitted | pending | verified | rejected
  bool kycUploading = false;
  String? kycError;
  StreamSubscription? _kycSub;

  /// Only verified users (or the internal QA test account) can make or
  /// receive calls now that KYC applies to everyone, not just female users.
  bool get canMakeOrReceiveCalls => _isAdminTestAccount || kycStatus == 'verified';

  void _listenKycStatus() {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    _kycSub?.cancel();
    _kycSub = FirebaseFirestore.instance.collection('kyc').doc(uid).snapshots().listen((doc) {
      if (doc.exists) {
        final data = doc.data() ?? {};
        kycStatus = (data['status'] as String?) ?? 'pending';
        _maybeAutoApproveKyc(uid, data);
      }
      notifyListeners();
    }, onError: (_) {});
  }

  /// If this KYC submission is still pending 12 hours after it was
  /// submitted, the app tries to flip it to verified itself. Firestore's
  /// security rules only permit this exact transition once
  /// `request.time` (the server's clock) is 12 hours past the server-set
  /// `submittedAt` — a user changing their phone's clock can't fake this.
  Future<void> _maybeAutoApproveKyc(String uid, Map<String, dynamic> data) async {
    if (data['status'] != 'pending') return;
    final submittedAt = data['submittedAt'];
    if (submittedAt is! Timestamp) return;
    if (DateTime.now().difference(submittedAt.toDate()) < kycAutoApproveAfter) return;
    try {
      await FirebaseFirestore.instance.collection('kyc').doc(uid).update({
        'status': 'verified',
        'reviewedAt': FieldValue.serverTimestamp(),
        'reviewedBy': 'auto-approved (12h SLA)',
      });
    } catch (_) {
      // Rules will reject this if the 12h window genuinely hasn't passed
      // yet (e.g. clock skew) — harmless, it'll retry next snapshot.
    }
  }

  /// KYC documents required from every user: Aadhaar front + back, PAN
  /// card, and a selfie. Takes raw bytes rather than dart:io's File so this
  /// works on both Android and Web — File/dart:io isn't available on
  /// Flutter Web at all. The caller (KycScreen) reads bytes from the
  /// image_picker XFile via readAsBytes(), which works on every platform.
  Future<bool> submitKyc({required Uint8List aadharFront, required Uint8List aadharBack, required Uint8List panCard, required Uint8List selfie}) async {
    final uid = firebaseUser?.uid;
    if (uid == null) return false;
    kycUploading = true;
    kycError = null;
    notifyListeners();
    try {
      Future<String> upload(Uint8List bytes, String name) async {
        final ref = FirebaseStorage.instance.ref('kyc/$uid/$name.jpg');
        await ref.putData(bytes, SettableMetadata(contentType: 'image/jpeg'));
        return ref.getDownloadURL();
      }

      final aadharFrontUrl = await upload(aadharFront, 'aadhar_front');
      final aadharBackUrl = await upload(aadharBack, 'aadhar_back');
      final panCardUrl = await upload(panCard, 'pan_card');
      final selfieUrl = await upload(selfie, 'selfie');
      await FirebaseFirestore.instance.collection('kyc').doc(uid).set({
        'name': myName,
        'phone': phoneNumber,
        'aadharFrontUrl': aadharFrontUrl,
        'aadharBackUrl': aadharBackUrl,
        'panCardUrl': panCardUrl,
        'selfieUrl': selfieUrl,
        'status': 'pending',
        'submittedAt': FieldValue.serverTimestamp(),
      });
      kycStatus = 'pending';
      kycUploading = false;
      notifyListeners();
      return true;
    } catch (e) {
      kycUploading = false;
      kycError = 'Upload failed. Check your connection and try again.';
      notifyListeners();
      return false;
    }
  }

  // ---------------- Wallet recharge (manual — ops team calls to collect payment) ----------------
  bool rechargeTicketRaised = false;
  double lastRechargeRequestAmount = 0;

  Future<bool> requestRecharge(double amount) async {
    final uid = firebaseUser?.uid;
    try {
      await FirebaseFirestore.instance.collection('rechargeTickets').add({
        'uid': uid,
        'name': myName,
        'phone': phoneNumber,
        'amount': amount,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });
      rechargeTicketRaised = true;
      lastRechargeRequestAmount = amount;
      notifyListeners();
      return true;
    } catch (e) {
      return false;
    }
  }

  StreamSubscription? _onlineUsersSub;

  /// Who to show in the browse grid: anyone can now call anyone (male-male,
  /// female-female, and both directions of male/female), so this is a
  /// client-side display filter rather than a query restriction.
  String genderFilter = 'all'; // all | male | female

  void setGenderFilter(String filter) {
    genderFilter = filter;
    notifyListeners();
  }

  List<UserProfile> get filteredOnlineUsers {
    final list = onlineUsers.where((u) => u.isOnline).toList();
    if (genderFilter == 'all') return list;
    return list.where((u) => u.gender == genderFilter).toList();
  }

  /// Live query of real Firestore-backed users who are currently marked
  /// online — this replaces the old hardcoded fake list. Lists BOTH roles
  /// (not just the opposite one) so any user can call any other user;
  /// [genderFilter] narrows what's shown in the UI.
  void _listenOnlineUsers() {
    _onlineUsersSub?.cancel();
    _onlineUsersSub = FirebaseFirestore.instance
        .collection('users')
        .where('online', isEqualTo: true)
        .snapshots()
        .listen((snapshot) {
      onlineUsers
        ..clear()
        ..addAll(snapshot.docs.where((d) => d.id != firebaseUser?.uid).map((d) {
          final data = d.data();
          final name = (data['name'] as String?)?.trim();
          final gender = (data['role'] == 'female') ? 'female' : 'male';
          return UserProfile(
            id: d.id,
            name: (name == null || name.isEmpty) ? 'User' : name,
            age: 24,
            language: 'English',
            country: 'India',
            city: 'India',
            gender: gender,
            avatarColorIndex: d.id.hashCode.abs() % 6,
          );
        }));
      notifyListeners();
    }, onError: (_) {});
  }

  Future<void> logout() async {
    final uid = firebaseUser?.uid;
    if (uid != null) {
      try {
        await FirebaseFirestore.instance.collection('users').doc(uid).update({'online': false});
      } catch (_) {}
    }
    await _onlineUsersSub?.cancel();
    _onlineUsersSub = null;
    await _kycSub?.cancel();
    _kycSub = null;
    await _walletSub?.cancel();
    _walletSub = null;
    await _withdrawalsSub?.cancel();
    _withdrawalsSub = null;
    _knownWithdrawalStatus.clear();
    withdrawalNotice = null;
    try {
      await FirebaseAuth.instance.signOut();
    } catch (_) {}
    try {
      await _googleSignIn.signOut();
    } catch (_) {}
    isLoggedIn = false;
    firebaseUser = null;
    _verificationId = null;
    kycStatus = 'not_submitted';
    rechargeTicketRaised = false;
    onlineUsers.clear();
    notifyListeners();
  }

  // ---------------- Wallet ----------------
  double walletBalance = 240.0;
  // Whoever INITIATES a call pays this rate — men pay more than women.
  // Any user can call any other user (male-male, female-female, and both
  // directions of male/female); the rate depends on the CALLER's gender.
  static const double callRatePerMinuteMale = 5.0;
  static const double callRatePerMinuteFemale = 3.0;
  static double callRatePerMinuteFor(UserRole r) => r == UserRole.male ? callRatePerMinuteMale : callRatePerMinuteFemale;

  /// Bank of free calling seconds granted at signup (30 min for male
  /// users). Consumed before the wallet is ever charged.
  int freeSecondsRemaining = 0;
  int _chargedSecondsThisSession = 0;

  final List<WalletTransaction> transactions = [
    WalletTransaction(
      title: 'Call — Priya',
      subtitle: 'Today, 6:42 PM',
      amount: -65,
      date: DateTime.now(),
      type: TransactionType.callCharge,
    ),
    WalletTransaction(
      title: 'Recharge — UPI',
      subtitle: 'Today, 2:10 PM',
      amount: 500,
      date: DateTime.now(),
      type: TransactionType.recharge,
    ),
    WalletTransaction(
      title: 'Call — Sneha',
      subtitle: 'Yesterday, 9:05 PM',
      amount: -120,
      date: DateTime.now().subtract(const Duration(days: 1)),
      type: TransactionType.callCharge,
    ),
  ];

  void recharge(double amount, {double bonus = 0}) {
    walletBalance += amount + bonus;
    transactions.insert(
      0,
      WalletTransaction(
        title: 'Recharge — UPI',
        subtitle: 'Just now',
        amount: amount + bonus,
        date: DateTime.now(),
        type: TransactionType.recharge,
      ),
    );
    _syncWalletToFirestore();
    _logWalletTransaction(type: 'recharge', amount: amount + bonus, note: 'In-app recharge');
    notifyListeners();
  }

  // ---------------- Earnings ----------------
  // Only FEMALE users earn from receiving calls. Men get no free/earned
  // money from incoming calls (from either men or women) — they must
  // recharge their wallet to make outgoing calls.
  double todayEarnings = 180;
  double weekEarnings = 1240;
  double monthEarnings = 4860;
  double lifetimeEarnings = 28400;
  static const double earnRatePerMinute = 1.0;
  static double earnRatePerMinuteFor(UserRole r) => r == UserRole.female ? earnRatePerMinute : 0.0;
  final List<double> weeklyBars = [34, 52, 28, 68, 46, 80, 38];

  /// Set whenever a withdrawal request fails or is rejected, so the UI can
  /// show the exact reason (outside working hours, below minimum, or
  /// rejected for insufficient funds) instead of one generic message.
  String? lastWithdrawalError;
  bool withdrawalSubmitting = false;

  /// Raises a withdrawal request with the payout details the ops team needs
  /// to actually send the money (bank account or UPI) — this creates a
  /// ticket in Firestore ('withdrawalTickets') the CRM surfaces, mirroring
  /// how recharge requests work. [method] is 'bank' or 'upi'; [details]
  /// holds the form fields for that method.
  Future<bool> requestWithdrawal({
    required double amount,
    required String method,
    required Map<String, String> details,
  }) async {
    // Users can RAISE a withdrawal request any time, 24/7 — same as
    // recharge. Working hours only gate when the money actually gets
    // credited (the ops team processes/pays out requests during
    // $workingHours); it no longer blocks submitting the request itself.
    if (amount < 500) {
      lastWithdrawalError = 'Minimum withdrawal amount is ₹500.';
      notifyListeners();
      return false;
    }
    if (amount > lifetimeEarnings) {
      lastWithdrawalError = 'Rejected due to Insufficient Funds.';
      notifyListeners();
      return false;
    }
    withdrawalSubmitting = true;
    notifyListeners();
    final uid = firebaseUser?.uid;
    try {
      await FirebaseFirestore.instance.collection('withdrawalTickets').add({
        'uid': uid,
        'name': myName,
        'phone': phoneNumber,
        'amount': amount,
        'method': method,
        'details': details,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      withdrawalSubmitting = false;
      lastWithdrawalError = 'Could not raise the request. Please check your connection and try again.';
      notifyListeners();
      return false;
    }
    lifetimeEarnings -= amount;
    lastWithdrawalError = null;
    withdrawalSubmitting = false;
    notifyListeners();
    return true;
  }

  // ---------------- Withdrawal completion notice ----------------
  // The submit screen only shows a lightweight "request raised" acknowledgment
  // (see WithdrawScreen). The real "Congratulations / Rejected" popup fires
  // once the CRM actually marks the ticket paid/rejected — this listener
  // watches this user's own withdrawal tickets and surfaces that transition.
  StreamSubscription? _withdrawalsSub;
  final Map<String, String> _knownWithdrawalStatus = {};

  /// Non-null once a previously-pending withdrawal ticket has been marked
  /// paid or rejected by the CRM. UI shows a one-time popup then calls
  /// [clearWithdrawalNotice].
  Map<String, dynamic>? withdrawalNotice;

  void _listenMyWithdrawals() {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    _withdrawalsSub?.cancel();
    _withdrawalsSub = FirebaseFirestore.instance
        .collection('withdrawalTickets')
        .where('uid', isEqualTo: uid)
        .snapshots()
        .listen((snapshot) {
      for (final change in snapshot.docChanges) {
        final data = change.doc.data();
        if (data == null) continue;
        final status = data['status'] as String? ?? '';
        final id = change.doc.id;
        final prev = _knownWithdrawalStatus[id];
        _knownWithdrawalStatus[id] = status;
        if (change.type == DocumentChangeType.modified &&
            prev == 'pending' &&
            (status == 'paid' || status == 'rejected')) {
          final amount = (data['amount'] as num?)?.toDouble() ?? 0;
          withdrawalNotice = {'status': status, 'amount': amount};
          notifyListeners();
        }
      }
    }, onError: (_) {});
  }

  void clearWithdrawalNotice() {
    withdrawalNotice = null;
    notifyListeners();
  }

  // ---------------- Online users (real Firestore directory) ----------------
  bool amIOnline = true;

  void toggleOnline(bool value) {
    amIOnline = value;
    notifyListeners();
    final uid = firebaseUser?.uid;
    if (uid != null) {
      FirebaseFirestore.instance.collection('users').doc(uid).update({
        'online': value,
        'lastSeen': FieldValue.serverTimestamp(),
      }).catchError((_) {});
    }
  }

  /// Populated live from Firestore once logged in (see [_listenOnlineUsers]).
  /// Starts empty — no more hardcoded fake profiles.
  final List<UserProfile> onlineUsers = [];

  // ---------------- Call state ----------------
  CallStage callStage = CallStage.none;
  UserProfile? currentPeer;
  CallType currentCallType = CallType.audio;
  int callSeconds = 0;
  double sessionCharge = 0;
  double sessionEarning = 0;

  Timer? _callTimer;

  final List<CallLogEntry> callHistory = [];

  /// Whether the CURRENT user is the one who placed this call (pays) or
  /// received it (earns). Any user — regardless of gender — can be either,
  /// since calling is no longer restricted by role.
  bool isCallInitiator = true;

  /// This user places an outgoing call to [peer]. They pay for it.
  void startOutgoingCall(UserProfile peer, CallType type) {
    currentPeer = peer;
    currentCallType = type;
    callStage = CallStage.outgoingRinging;
    callSeconds = 0;
    sessionCharge = 0;
    isCallInitiator = true;
    notifyListeners();
  }

  /// Demo helper: previews what an incoming call looks like (this user
  /// receives and earns), since there is no live backend to originate a
  /// real one yet.
  void simulateIncomingCall(UserProfile caller, CallType type) {
    currentPeer = caller;
    currentCallType = type;
    callStage = CallStage.incomingRinging;
    callSeconds = 0;
    sessionEarning = 0;
    isCallInitiator = false;
    notifyListeners();
  }

  /// Called once the (simulated) other party accepts. Starts the
  /// per-second timer that drives per-minute billing.
  void connectCall() {
    callStage = CallStage.active;
    callSeconds = 0;
    _chargedSecondsThisSession = 0;
    _callTimer?.cancel();
    _callTimer = Timer.periodic(const Duration(seconds: 1), (_) => _onTick());
    notifyListeners();
  }

  void _onTick() {
    callSeconds++;

    if (isCallInitiator) {
      // The 30 free minutes are a male-signup perk only — everyone else
      // (including female callers spending their wallet/signup bonus) is
      // charged from the very first second.
      if (role == UserRole.male && freeSecondsRemaining > 0) {
        // Still inside the 30 free minutes — no charge, no ledger entry.
        freeSecondsRemaining--;
      } else {
        _chargedSecondsThisSession++;
        final rate = callRatePerMinuteFor(role);
        sessionCharge = (_chargedSecondsThisSession / 60.0) * rate;
        if (walletBalance - sessionCharge <= 0) {
          walletBalance = 0;
          endCall();
          return;
        }
        // Apply the actual per-minute ledger entry every 60 charged
        // seconds — ₹5/min for men, ₹3/min for women.
        if (_chargedSecondsThisSession % 60 == 0) {
          walletBalance -= rate;
          if (walletBalance < 0) walletBalance = 0;
          transactions.insert(
            0,
            WalletTransaction(
              title: 'Call — ${currentPeer?.name ?? ""}',
              subtitle: 'Just now',
              amount: -rate,
              date: DateTime.now(),
              type: TransactionType.callCharge,
            ),
          );
          _syncWalletToFirestore();
          _logWalletTransaction(type: 'callCharge', amount: -rate, note: currentPeer?.name);
        }
      }
    } else {
      // Receiving a call: only women earn (₹1/min). Men get nothing for
      // incoming calls — they need to recharge to make their own calls.
      final earnRate = earnRatePerMinuteFor(role);
      if (earnRate > 0) {
        sessionEarning = (callSeconds / 60.0) * earnRate;
        if (callSeconds % 60 == 0) {
          todayEarnings += earnRate;
          weekEarnings += earnRate;
          monthEarnings += earnRate;
          lifetimeEarnings += earnRate;
        }
      } else {
        sessionEarning = 0;
      }
    }

    notifyListeners();
  }

  void endCall() {
    _callTimer?.cancel();
    if (currentPeer != null && callSeconds > 0) {
      callHistory.insert(
        0,
        CallLogEntry(
          peer: currentPeer!,
          type: currentCallType,
          outcome: CallOutcome.completed,
          durationSeconds: callSeconds,
          charge: isCallInitiator ? sessionCharge : sessionEarning,
          wasCaller: isCallInitiator,
          timestamp: DateTime.now(),
        ),
      );
    }
    callStage = CallStage.ended;
    notifyListeners();
  }

  void resetCall() {
    _callTimer?.cancel();
    callStage = CallStage.none;
    currentPeer = null;
    callSeconds = 0;
    sessionCharge = 0;
    sessionEarning = 0;
    notifyListeners();
  }

  @override
  void dispose() {
    _callTimer?.cancel();
    _onlineUsersSub?.cancel();
    _kycSub?.cancel();
    _walletSub?.cancel();
    _withdrawalsSub?.cancel();
    super.dispose();
  }

  // ---------------- Profile editing ----------------
  /// Updates the display name shown across the app and pushes it to the
  /// public 'users/{uid}' profile doc so it's reflected for other users too.
  Future<bool> updateName(String newName) async {
    final trimmed = newName.trim();
    if (trimmed.isEmpty) return false;
    myName = trimmed;
    notifyListeners();
    await _publishMyProfile();
    return true;
  }

  // ---------------- Notification settings ----------------
  // Simple local preferences (no backend needed — these just control
  // whether in-app popups/snackbars show for each category).
  bool notifyCallAlerts = true;
  bool notifyWithdrawalUpdates = true;
  bool notifyPromotions = false;

  void setNotifyCallAlerts(bool v) {
    notifyCallAlerts = v;
    notifyListeners();
  }

  void setNotifyWithdrawalUpdates(bool v) {
    notifyWithdrawalUpdates = v;
    notifyListeners();
  }

  void setNotifyPromotions(bool v) {
    notifyPromotions = v;
    notifyListeners();
  }

  // ---------------- Blocked users ----------------
  // Local list for now — no in-app "block" action exists elsewhere yet, but
  // the screen is fully functional (shows a real empty state, and this list
  // is ready to be populated once a "block" action is added to call/profile
  // screens).
  final List<String> blockedUserNames = [];

  void unblockUser(String name) {
    blockedUserNames.remove(name);
    notifyListeners();
  }
}
