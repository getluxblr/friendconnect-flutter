import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/user_model.dart';
import '../models/transaction_model.dart';
import '../models/call_log_model.dart';

enum UserRole { male, female }

enum CallStage { none, outgoingRinging, incomingRinging, active, ended }

/// Central in-memory state for the app.
///
/// Auth now goes through real Firebase Phone Authentication (real SMS OTP),
/// and the "online users" directory is a live Firestore query instead of a
/// hardcoded list — see [sendOtp], [verifyOtp] and [_listenOnlineUsers].
class AppState extends ChangeNotifier {
  // ---------------- Auth ----------------
  bool isLoggedIn = false;
  String phoneNumber = '';
  UserRole role = UserRole.male;
  String myName = 'You';

  bool otpSending = false;
  String? authError;
  User? firebaseUser;
  String? _verificationId;

  /// Kicks off real Firebase Phone Auth for [phone] (10-digit Indian
  /// number, spaces allowed). Returns the verificationId once the SMS has
  /// been sent, or null if sending failed (see [authError]).
  Future<String?> sendOtp(String phone) async {
    phoneNumber = phone;
    otpSending = true;
    authError = null;
    notifyListeners();

    final digits = phone.replaceAll(RegExp(r'\D'), '');
    final e164 = digits.startsWith('91') && digits.length > 10 ? '+$digits' : '+91$digits';

    final completer = Completer<String?>();
    try {
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: e164,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (PhoneAuthCredential credential) async {
          // Android instant/auto verification — sign in right away.
          try {
            await FirebaseAuth.instance.signInWithCredential(credential);
          } catch (_) {}
        },
        verificationFailed: (FirebaseAuthException e) {
          otpSending = false;
          authError = e.message ?? 'Could not send OTP. Please try again.';
          notifyListeners();
          if (!completer.isCompleted) completer.complete(null);
        },
        codeSent: (String verificationId, int? resendToken) {
          _verificationId = verificationId;
          otpSending = false;
          notifyListeners();
          if (!completer.isCompleted) completer.complete(verificationId);
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          _verificationId = verificationId;
        },
      );
    } catch (e) {
      otpSending = false;
      authError = 'Could not send OTP. Please try again.';
      notifyListeners();
      if (!completer.isCompleted) completer.complete(null);
    }
    return completer.future;
  }

  /// Verifies the real SMS code the user typed in, and on success signs
  /// them in with Firebase Auth, publishes their profile to Firestore, and
  /// starts listening for other real online users.
  Future<bool> verifyOtp(String smsCode, UserRole selectedRole, String displayName) async {
    if (_verificationId == null) {
      authError = 'Please request the OTP again.';
      notifyListeners();
      return false;
    }
    try {
      final credential = PhoneAuthProvider.credential(verificationId: _verificationId!, smsCode: smsCode.trim());
      final userCred = await FirebaseAuth.instance.signInWithCredential(credential);
      firebaseUser = userCred.user;
      role = selectedRole;
      myName = displayName.trim().isEmpty ? 'User${phoneNumber.replaceAll(RegExp(r'\D'), '').padLeft(4, '0').substring(0, 4)}' : displayName.trim();
      isLoggedIn = true;
      authError = null;
      await _publishMyProfile();
      _listenOnlineUsers();
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      authError = e.message ?? 'Invalid code. Please try again.';
      notifyListeners();
      return false;
    } catch (e) {
      authError = 'Verification failed. Please try again.';
      notifyListeners();
      return false;
    }
  }

  Future<void> _publishMyProfile() async {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    try {
      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'name': myName,
        'phone': phoneNumber,
        'role': role == UserRole.male ? 'male' : 'female',
        'online': amIOnline,
        'lastSeen': FieldValue.serverTimestamp(),
      });
    } catch (_) {
      // Non-fatal — the app still works locally if Firestore write fails.
    }
  }

  StreamSubscription? _onlineUsersSub;

  /// Live query of real Firestore-backed users of the opposite role who are
  /// currently marked online — this replaces the old hardcoded fake list.
  void _listenOnlineUsers() {
    _onlineUsersSub?.cancel();
    final oppositeRole = role == UserRole.male ? 'female' : 'male';
    _onlineUsersSub = FirebaseFirestore.instance
        .collection('users')
        .where('role', isEqualTo: oppositeRole)
        .where('online', isEqualTo: true)
        .snapshots()
        .listen((snapshot) {
      onlineUsers
        ..clear()
        ..addAll(snapshot.docs.where((d) => d.id != firebaseUser?.uid).map((d) {
          final data = d.data();
          final name = (data['name'] as String?)?.trim();
          return UserProfile(
            id: d.id,
            name: (name == null || name.isEmpty) ? 'User' : name,
            age: 24,
            language: 'English',
            country: 'India',
            city: 'India',
            gender: oppositeRole,
            avatarColorIndex: d.id.hashCode.abs() % 6,
          );
        }));
      notifyListeners();
    }, onError: (_) {});
  }

  Future<void> logout() async {
    final uid = firebaseUser?.uid;
    if (uid != null) {
      try {
        await FirebaseFirestore.instance.collection('users').doc(uid).update({'online': false});
      } catch (_) {}
    }
    await _onlineUsersSub?.cancel();
    _onlineUsersSub = null;
    try {
      await FirebaseAuth.instance.signOut();
    } catch (_) {}
    isLoggedIn = false;
    firebaseUser = null;
    _verificationId = null;
    onlineUsers.clear();
    notifyListeners();
  }

  // ---------------- Wallet (male) ----------------
  double walletBalance = 240.0;
  static const double callRatePerMinuteMale = 5.0;

  final List<WalletTransaction> transactions = [
    WalletTransaction(
      title: 'Call — Priya',
      subtitle: 'Today, 6:42 PM',
      amount: -65,
      date: DateTime.now(),
      type: TransactionType.callCharge,
    ),
    WalletTransaction(
      title: 'Recharge — UPI',
      subtitle: 'Today, 2:10 PM',
      amount: 500,
      date: DateTime.now(),
      type: TransactionType.recharge,
    ),
    WalletTransaction(
      title: 'Call — Sneha',
      subtitle: 'Yesterday, 9:05 PM',
      amount: -120,
      date: DateTime.now().subtract(const Duration(days: 1)),
      type: TransactionType.callCharge,
    ),
  ];

  void recharge(double amount, {double bonus = 0}) {
    walletBalance += amount + bonus;
    transactions.insert(
      0,
      WalletTransaction(
        title: 'Recharge — UPI',
        subtitle: 'Just now',
        amount: amount + bonus,
        date: DateTime.now(),
        type: TransactionType.recharge,
      ),
    );
    notifyListeners();
  }

  // ---------------- Earnings (female) ----------------
  double todayEarnings = 180;
  double weekEarnings = 1240;
  double monthEarnings = 4860;
  double lifetimeEarnings = 28400;
  static const double earnRatePerMinuteFemale = 1.0;
  final List<double> weeklyBars = [34, 52, 28, 68, 46, 80, 38];

  bool requestWithdrawal(double amount) {
    if (amount < 500 || amount > lifetimeEarnings) return false;
    lifetimeEarnings -= amount;
    notifyListeners();
    return true;
  }

  // ---------------- Online users (real Firestore directory) ----------------
  bool amIOnline = true;

  void toggleOnline(bool value) {
    amIOnline = value;
    notifyListeners();
    final uid = firebaseUser?.uid;
    if (uid != null) {
      FirebaseFirestore.instance.collection('users').doc(uid).update({
        'online': value,
        'lastSeen': FieldValue.serverTimestamp(),
      }).catchError((_) {});
    }
  }

  /// Populated live from Firestore once logged in (see [_listenOnlineUsers]).
  /// Starts empty — no more hardcoded fake profiles.
  final List<UserProfile> onlineUsers = [];

  // ---------------- Call state ----------------
  CallStage callStage = CallStage.none;
  UserProfile? currentPeer;
  CallType currentCallType = CallType.audio;
  int callSeconds = 0;
  double sessionCharge = 0;
  double sessionEarning = 0;

  Timer? _callTimer;

  final List<CallLogEntry> callHistory = [];

  /// Male user places an outgoing call to [peer].
  void startOutgoingCall(UserProfile peer, CallType type) {
    currentPeer = peer;
    currentCallType = type;
    callStage = CallStage.outgoingRinging;
    callSeconds = 0;
    sessionCharge = 0;
    notifyListeners();
  }

  /// Demo helper: female role previews what an incoming call looks like,
  /// since there is no live backend to originate a real one yet.
  void simulateIncomingCall(UserProfile caller, CallType type) {
    currentPeer = caller;
    currentCallType = type;
    callStage = CallStage.incomingRinging;
    callSeconds = 0;
    sessionEarning = 0;
    notifyListeners();
  }

  /// Called once the (simulated) other party accepts. Starts the
  /// per-second timer that drives per-minute billing.
  void connectCall() {
    callStage = CallStage.active;
    callSeconds = 0;
    _callTimer?.cancel();
    _callTimer = Timer.periodic(const Duration(seconds: 1), (_) => _onTick());
    notifyListeners();
  }

  void _onTick() {
    callSeconds++;

    if (role == UserRole.male) {
      sessionCharge = (callSeconds / 60.0) * callRatePerMinuteMale;
      if (walletBalance - sessionCharge <= 0) {
        walletBalance = 0;
        endCall();
        return;
      }
    } else {
      sessionEarning = (callSeconds / 60.0) * earnRatePerMinuteFemale;
    }

    // Apply the actual per-minute ledger entries every 60 seconds, matching
    // the PRD's billing rule (₹5/min charged, ₹1/min credited).
    if (callSeconds % 60 == 0) {
      if (role == UserRole.male) {
        walletBalance -= callRatePerMinuteMale;
        if (walletBalance < 0) walletBalance = 0;
        transactions.insert(
          0,
          WalletTransaction(
            title: 'Call — ${currentPeer?.name ?? ""}',
            subtitle: 'Just now',
            amount: -callRatePerMinuteMale,
            date: DateTime.now(),
            type: TransactionType.callCharge,
          ),
        );
      } else {
        todayEarnings += earnRatePerMinuteFemale;
        weekEarnings += earnRatePerMinuteFemale;
        monthEarnings += earnRatePerMinuteFemale;
        lifetimeEarnings += earnRatePerMinuteFemale;
      }
    }

    notifyListeners();
  }

  void endCall() {
    _callTimer?.cancel();
    if (currentPeer != null && callSeconds > 0) {
      callHistory.insert(
        0,
        CallLogEntry(
          peer: currentPeer!,
          type: currentCallType,
          outcome: CallOutcome.completed,
          durationSeconds: callSeconds,
          charge: role == UserRole.male ? sessionCharge : sessionEarning,
          timestamp: DateTime.now(),
        ),
      );
    }
    callStage = CallStage.ended;
    notifyListeners();
  }

  void resetCall() {
    _callTimer?.cancel();
    callStage = CallStage.none;
    currentPeer = null;
    callSeconds = 0;
    sessionCharge = 0;
    sessionEarning = 0;
    notifyListeners();
  }

  @override
  void dispose() {
    _callTimer?.cancel();
    _onlineUsersSub?.cancel();
    super.dispose();
  }
}
