import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../models/user_model.dart';
import '../models/transaction_model.dart';
import '../models/call_log_model.dart';

enum UserRole { male, female }

enum CallStage { none, outgoingRinging, incomingRinging, active, ended }

/// Central in-memory state for the app.
///
/// Auth now goes through real Firebase Phone Authentication (real SMS OTP),
/// and the "online users" directory is a live Firestore query instead of a
/// hardcoded list — see [sendOtp], [verifyOtp] and [_listenOnlineUsers].
class AppState extends ChangeNotifier {
  // Business rules surfaced in the UI.
  static const String workingHours = '9:00 AM – 6:00 PM';
  static const String paymentTat = '4 hours';
  static const int freeMinutesForMale = 30;
  static const double signupBonusForFemale = 300;
  static const int minAgeYears = 18;
  static const int _workingHourStart = 9; // 9 AM, 24h clock
  static const int _workingHourEnd = 18; // 6 PM, 24h clock

  /// Withdrawals (payouts to female users) are only processed during working
  /// hours. Adding money (recharge) is NOT gated by this — that can happen
  /// any time; only the team's callback to collect payment happens during
  /// working hours.
  bool get isWithinWorkingHours {
    final h = DateTime.now().hour;
    return h >= _workingHourStart && h < _workingHourEnd;
  }

  /// Validates a date of birth against the 18+ requirement. Returns a
  /// user-facing error message if invalid, or null if the DOB is acceptable.
  static String? ageValidationError(DateTime? dob) {
    if (dob == null) return 'Please enter your date of birth as per your documents.';
    final now = DateTime.now();
    if (dob.isAfter(now)) return 'Please enter a valid date of birth.';
    int age = now.year - dob.year;
    if (now.month < dob.month || (now.month == dob.month && now.day < dob.day)) {
      age--;
    }
    if (age < minAgeYears) {
      return 'You must be at least 18 years old to use FriendConnect. Please enter your date of birth as per your official documents.';
    }
    return null;
  }

  // Internal QA / admin test account — always gets a healthy wallet balance
  // regardless of role, so your team can test calls without running out of
  // credits. Matched on the last 10 digits so it works with or without a
  // country code prefix.
  static const String adminTestPhoneDigits = '6363958868';
  static const double adminTestWalletBalance = 5000;

  bool get _isAdminTestAccount {
    final digits = phoneNumber.replaceAll(RegExp(r'\D'), '');
    if (digits.isEmpty) return false;
    final last10 = digits.length >= 10 ? digits.substring(digits.length - 10) : digits;
    return last10 == adminTestPhoneDigits;
  }

  // ---------------- Auth ----------------
  bool isLoggedIn = false;
  String phoneNumber = '';
  UserRole role = UserRole.male;
  String myName = 'You';
  DateTime? dateOfBirth;

  bool otpSending = false;
  String? authError;
  User? firebaseUser;
  String? _verificationId;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  /// Kicks off real Firebase Phone Auth for [phone] (10-digit Indian
  /// number, spaces allowed). Returns the verificationId once the SMS has
  /// been sent, or null if sending failed (see [authError]).
  Future<String?> sendOtp(String phone) async {
    phoneNumber = phone;
    otpSending = true;
    authError = null;
    notifyListeners();

    final digits = phone.replaceAll(RegExp(r'\D'), '');
    final e164 = digits.startsWith('91') && digits.length > 10 ? '+$digits' : '+91$digits';

    final completer = Completer<String?>();
    try {
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: e164,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (PhoneAuthCredential credential) async {
          // Android instant/auto verification — sign in right away.
          try {
            await FirebaseAuth.instance.signInWithCredential(credential);
          } catch (_) {}
        },
        verificationFailed: (FirebaseAuthException e) {
          otpSending = false;
          authError = e.message ?? 'Could not send OTP. Please try again.';
          notifyListeners();
          if (!completer.isCompleted) completer.complete(null);
        },
        codeSent: (String verificationId, int? resendToken) {
          _verificationId = verificationId;
          otpSending = false;
          notifyListeners();
          if (!completer.isCompleted) completer.complete(verificationId);
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          _verificationId = verificationId;
        },
      );
    } catch (e) {
      otpSending = false;
      authError = 'Could not send OTP. Please try again.';
      notifyListeners();
      if (!completer.isCompleted) completer.complete(null);
    }
    return completer.future;
  }

  /// Verifies the real SMS code the user typed in, and on success signs
  /// them in with Firebase Auth. Returning users get their existing profile
  /// loaded back; brand-new users get the role/name picked on this screen
  /// plus their one-time signup bonus.
  Future<bool> verifyOtp(String smsCode, UserRole selectedRole, String displayName, DateTime? dob) async {
    if (_verificationId == null) {
      authError = 'Please request the OTP again.';
      notifyListeners();
      return false;
    }
    try {
      final credential = PhoneAuthProvider.credential(verificationId: _verificationId!, smsCode: smsCode.trim());
      final userCred = await FirebaseAuth.instance.signInWithCredential(credential);
      firebaseUser = userCred.user;
      authError = null;
      final existing = await _tryLoadExistingProfile();
      if (!existing) {
        // New signup — DOB is required and must clear the 18+ check before
        // we create the profile or grant any signup economics.
        final ageError = ageValidationError(dob);
        if (ageError != null) {
          authError = ageError;
          try {
            await FirebaseAuth.instance.signOut();
          } catch (_) {}
          firebaseUser = null;
          notifyListeners();
          return false;
        }
        role = selectedRole;
        myName = displayName.trim().isEmpty ? 'User' : displayName.trim();
        dateOfBirth = dob;
        _applySignupEconomics();
        isLoggedIn = true;
        await _publishMyProfile(isNewUser: true);
        await _syncWalletToFirestore();
        _listenOnlineUsers();
        _listenKycStatus();
        _listenWallet();
      }
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      authError = e.message ?? 'Invalid code. Please try again.';
      notifyListeners();
      return false;
    } catch (e) {
      authError = 'Verification failed. Please try again.';
      notifyListeners();
      return false;
    }
  }

  /// Google Sign-In. Returns true if this is a returning user who is now
  /// fully logged in; false if this is a new account that still needs the
  /// name/role completion step (see [completeProfile]).
  Future<bool> signInWithGoogle() async {
    try {
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        authError = 'Sign-in cancelled.';
        notifyListeners();
        return false;
      }
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final userCred = await FirebaseAuth.instance.signInWithCredential(credential);
      firebaseUser = userCred.user;
      myName = userCred.user?.displayName ?? myName;
      authError = null;
      final existing = await _tryLoadExistingProfile();
      notifyListeners();
      return existing;
    } catch (e) {
      authError = 'Google sign-in failed. Please try again.';
      notifyListeners();
      return false;
    }
  }

  /// Creates a brand-new email/password account. Always needs the
  /// name/role completion step afterwards.
  Future<bool> signUpWithEmail(String email, String password) async {
    try {
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.trim(), password: password);
      firebaseUser = cred.user;
      authError = null;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      authError = e.message ?? 'Could not create account. Please try again.';
      notifyListeners();
      return false;
    }
  }

  /// Signs an existing email/password user back in. Returns true if their
  /// profile was found and they're now fully logged in.
  Future<bool> signInWithEmail(String email, String password) async {
    try {
      final cred = await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.trim(), password: password);
      firebaseUser = cred.user;
      authError = null;
      final existing = await _tryLoadExistingProfile();
      notifyListeners();
      return existing;
    } on FirebaseAuthException catch (e) {
      authError = e.message ?? 'Invalid email or password.';
      notifyListeners();
      return false;
    }
  }

  /// Completes sign-up for Google/Email accounts that don't yet have a
  /// Firestore profile — collects the name + role the phone flow gets from
  /// the OTP screen directly.
  Future<bool> completeProfile(String name, UserRole selectedRole, DateTime? dob) async {
    final ageError = ageValidationError(dob);
    if (ageError != null) {
      authError = ageError;
      notifyListeners();
      return false;
    }
    role = selectedRole;
    myName = name.trim().isEmpty ? 'User' : name.trim();
    dateOfBirth = dob;
    _applySignupEconomics();
    isLoggedIn = true;
    await _publishMyProfile(isNewUser: true);
    await _syncWalletToFirestore();
    _listenOnlineUsers();
    _listenKycStatus();
    _listenWallet();
    notifyListeners();
    return true;
  }

  /// Looks up whether this Firebase user already has a Firestore profile
  /// (a returning user). If found, loads it and finishes login without
  /// touching wallet/earnings or re-granting the signup bonus.
  Future<bool> _tryLoadExistingProfile() async {
    final uid = firebaseUser?.uid;
    if (uid == null) return false;
    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (doc.exists) {
        final data = doc.data() ?? {};
        final name = (data['name'] as String?)?.trim();
        if (name != null && name.isNotEmpty) myName = name;
        final phone = data['phone'] as String?;
        if (phone != null && phone.isNotEmpty) phoneNumber = phone;
        role = (data['role'] == 'female') ? UserRole.female : UserRole.male;
        final dobTs = data['dob'];
        if (dobTs is Timestamp) dateOfBirth = dobTs.toDate();

        // Load the REAL wallet balance from Firestore — this is where any
        // recharge an admin approved in the CRM actually lives. Falls back
        // to the local default only if the wallet doc doesn't exist yet
        // (e.g. accounts created before this field was introduced).
        try {
          final walletDoc = await FirebaseFirestore.instance.collection('wallets').doc(uid).get();
          final bal = walletDoc.data()?['balance'];
          if (bal is num) walletBalance = bal.toDouble();
        } catch (_) {}

        if (_isAdminTestAccount && walletBalance < adminTestWalletBalance) {
          walletBalance = adminTestWalletBalance;
        }
        isLoggedIn = true;
        await _publishMyProfile();
        await _syncWalletToFirestore();
        _listenOnlineUsers();
        _listenKycStatus();
        _listenWallet();
        return true;
      }
    } catch (_) {
      // Firestore unreachable — fall through and treat as a new signup.
    }
    return false;
  }

  /// One-time economics applied only when a Firestore profile is created
  /// for the very first time: 30 free calling minutes for male users, a
  /// ₹300 wallet welcome bonus for female users.
  void _applySignupEconomics() {
    if (_isAdminTestAccount) {
      walletBalance = adminTestWalletBalance;
      freeSecondsRemaining = freeMinutesForMale * 60;
      return;
    }
    if (role == UserRole.male) {
      walletBalance = 0;
      freeSecondsRemaining = freeMinutesForMale * 60;
    } else {
      walletBalance = signupBonusForFemale;
      transactions.insert(
        0,
        WalletTransaction(
          title: 'Signup Bonus',
          subtitle: 'Welcome to FriendConnect',
          amount: signupBonusForFemale,
          date: DateTime.now(),
          type: TransactionType.recharge,
        ),
      );
      todayEarnings = 0;
      weekEarnings = 0;
      monthEarnings = 0;
      lifetimeEarnings = 0;
    }
  }

  Future<void> _publishMyProfile({bool isNewUser = false}) async {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    try {
      final data = <String, dynamic>{
        'name': myName,
        'phone': phoneNumber,
        'role': role == UserRole.male ? 'male' : 'female',
        'online': amIOnline,
        'lastSeen': FieldValue.serverTimestamp(),
        if (dateOfBirth != null) 'dob': Timestamp.fromDate(dateOfBirth!),
      };
      // Only stamp createdAt the very first time this profile is published,
      // so repeat merges (login, toggling online) never overwrite it — the
      // CRM uses this for "new signups" reporting.
      if (isNewUser) data['createdAt'] = FieldValue.serverTimestamp();
      await FirebaseFirestore.instance.collection('users').doc(uid).set(data, SetOptions(merge: true));
    } catch (_) {
      // Non-fatal — the app still works locally if Firestore write fails.
    }
  }

  // ---------------- Wallet sync (Firestore) ----------------
  // Wallet balance is intentionally stored in its OWN collection
  // ('wallets/{uid}'), separate from the public 'users' profile doc that
  // opposite-role peers can list to find who's online. That query only ever
  // returns name/role/online — never financial data. The CRM (and this app)
  // read/write 'wallets/{uid}.balance' directly, so recharge credits an
  // admin approves in the CRM show up here live.
  StreamSubscription? _walletSub;

  Future<void> _syncWalletToFirestore() async {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    try {
      await FirebaseFirestore.instance.collection('wallets').doc(uid).set({
        'balance': walletBalance,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (_) {
      // Non-fatal — local balance still works if Firestore write fails.
    }
  }

  void _listenWallet() {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    _walletSub?.cancel();
    _walletSub = FirebaseFirestore.instance.collection('wallets').doc(uid).snapshots().listen((doc) {
      if (doc.exists) {
        final bal = doc.data()?['balance'];
        if (bal is num) {
          walletBalance = bal.toDouble();
          notifyListeners();
        }
      }
    }, onError: (_) {});
  }

  Future<void> _logWalletTransaction({required String type, required double amount, String? note}) async {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    try {
      await FirebaseFirestore.instance.collection('walletTransactions').add({
        'uid': uid,
        'name': myName,
        'phone': phoneNumber,
        'type': type,
        'amount': amount,
        if (note != null) 'note': note,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {
      // Non-fatal — this is a reporting ledger for the CRM, not core to the call/wallet flow.
    }
  }

  // ---------------- KYC (female role, reviewed manually by the ops team) ----------------
  // Status lives entirely in Firestore ('kyc/{uid}') so the telecalling team
  // can review and flip pending -> verified/rejected straight from the
  // Firebase console — no separate admin app needed for now.
  String kycStatus = 'not_submitted'; // not_submitted | pending | verified | rejected
  bool kycUploading = false;
  String? kycError;
  StreamSubscription? _kycSub;

  void _listenKycStatus() {
    final uid = firebaseUser?.uid;
    if (uid == null) return;
    _kycSub?.cancel();
    _kycSub = FirebaseFirestore.instance.collection('kyc').doc(uid).snapshots().listen((doc) {
      if (doc.exists) {
        kycStatus = (doc.data()?['status'] as String?) ?? 'pending';
      }
      notifyListeners();
    }, onError: (_) {});
  }

  Future<bool> submitKyc({required File idFront, required File idBack, required File selfie}) async {
    final uid = firebaseUser?.uid;
    if (uid == null) return false;
    kycUploading = true;
    kycError = null;
    notifyListeners();
    try {
      Future<String> upload(File f, String name) async {
        final ref = FirebaseStorage.instance.ref('kyc/$uid/$name.jpg');
        await ref.putFile(f);
        return ref.getDownloadURL();
      }

      final frontUrl = await upload(idFront, 'id_front');
      final backUrl = await upload(idBack, 'id_back');
      final selfieUrl = await upload(selfie, 'selfie');
      await FirebaseFirestore.instance.collection('kyc').doc(uid).set({
        'name': myName,
        'phone': phoneNumber,
        'idFrontUrl': frontUrl,
        'idBackUrl': backUrl,
        'selfieUrl': selfieUrl,
        'status': 'pending',
        'submittedAt': FieldValue.serverTimestamp(),
      });
      kycStatus = 'pending';
      kycUploading = false;
      notifyListeners();
      return true;
    } catch (e) {
      kycUploading = false;
      kycError = 'Upload failed. Check your connection and try again.';
      notifyListeners();
      return false;
    }
  }

  // ---------------- Wallet recharge (manual — ops team calls to collect payment) ----------------
  bool rechargeTicketRaised = false;
  double lastRechargeRequestAmount = 0;

  Future<bool> requestRecharge(double amount) async {
    final uid = firebaseUser?.uid;
    try {
      await FirebaseFirestore.instance.collection('rechargeTickets').add({
        'uid': uid,
        'name': myName,
        'phone': phoneNumber,
        'amount': amount,
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });
      rechargeTicketRaised = true;
      lastRechargeRequestAmount = amount;
      notifyListeners();
      return true;
    } catch (e) {
      return false;
    }
  }

  StreamSubscription? _onlineUsersSub;

  /// Live query of real Firestore-backed users of the opposite role who are
  /// currently marked online — this replaces the old hardcoded fake list.
  void _listenOnlineUsers() {
    _onlineUsersSub?.cancel();
    final oppositeRole = role == UserRole.male ? 'female' : 'male';
    _onlineUsersSub = FirebaseFirestore.instance
        .collection('users')
        .where('role', isEqualTo: oppositeRole)
        .where('online', isEqualTo: true)
        .snapshots()
        .listen((snapshot) {
      onlineUsers
        ..clear()
        ..addAll(snapshot.docs.where((d) => d.id != firebaseUser?.uid).map((d) {
          final data = d.data();
          final name = (data['name'] as String?)?.trim();
          return UserProfile(
            id: d.id,
            name: (name == null || name.isEmpty) ? 'User' : name,
            age: 24,
            language: 'English',
            country: 'India',
            city: 'India',
            gender: oppositeRole,
            avatarColorIndex: d.id.hashCode.abs() % 6,
          );
        }));
      notifyListeners();
    }, onError: (_) {});
  }

  Future<void> logout() async {
    final uid = firebaseUser?.uid;
    if (uid != null) {
      try {
        await FirebaseFirestore.instance.collection('users').doc(uid).update({'online': false});
      } catch (_) {}
    }
    await _onlineUsersSub?.cancel();
    _onlineUsersSub = null;
    await _kycSub?.cancel();
    _kycSub = null;
    await _walletSub?.cancel();
    _walletSub = null;
    try {
      await FirebaseAuth.instance.signOut();
    } catch (_) {}
    try {
      await _googleSignIn.signOut();
    } catch (_) {}
    isLoggedIn = false;
    firebaseUser = null;
    _verificationId = null;
    kycStatus = 'not_submitted';
    rechargeTicketRaised = false;
    onlineUsers.clear();
    notifyListeners();
  }

  // ---------------- Wallet (male) ----------------
  double walletBalance = 240.0;
  static const double callRatePerMinuteMale = 5.0;

  /// Bank of free calling seconds granted at signup (30 min for male
  /// users). Consumed before the wallet is ever charged.
  int freeSecondsRemaining = 0;
  int _chargedSecondsThisSession = 0;

  final List<WalletTransaction> transactions = [
    WalletTransaction(
      title: 'Call — Priya',
      subtitle: 'Today, 6:42 PM',
      amount: -65,
      date: DateTime.now(),
      type: TransactionType.callCharge,
    ),
    WalletTransaction(
      title: 'Recharge — UPI',
      subtitle: 'Today, 2:10 PM',
      amount: 500,
      date: DateTime.now(),
      type: TransactionType.recharge,
    ),
    WalletTransaction(
      title: 'Call — Sneha',
      subtitle: 'Yesterday, 9:05 PM',
      amount: -120,
      date: DateTime.now().subtract(const Duration(days: 1)),
      type: TransactionType.callCharge,
    ),
  ];

  void recharge(double amount, {double bonus = 0}) {
    walletBalance += amount + bonus;
    transactions.insert(
      0,
      WalletTransaction(
        title: 'Recharge — UPI',
        subtitle: 'Just now',
        amount: amount + bonus,
        date: DateTime.now(),
        type: TransactionType.recharge,
      ),
    );
    _syncWalletToFirestore();
    _logWalletTransaction(type: 'recharge', amount: amount + bonus, note: 'In-app recharge');
    notifyListeners();
  }

  // ---------------- Earnings (female) ----------------
  double todayEarnings = 180;
  double weekEarnings = 1240;
  double monthEarnings = 4860;
  double lifetimeEarnings = 28400;
  static const double earnRatePerMinuteFemale = 1.0;
  final List<double> weeklyBars = [34, 52, 28, 68, 46, 80, 38];

  /// Set whenever [requestWithdrawal] fails, so the UI can show the exact
  /// reason (outside working hours vs. below minimum vs. insufficient
  /// balance) instead of one generic message.
  String? lastWithdrawalError;

  bool requestWithdrawal(double amount) {
    // Working hours gate WITHDRAWALS only — adding money (recharge) is
    // allowed any time, see requestRecharge() / recharge() above which have
    // no such check.
    if (!isWithinWorkingHours) {
      lastWithdrawalError = 'Withdrawals are processed only during working hours ($workingHours). Please raise your withdrawal request again during working hours.';
      notifyListeners();
      return false;
    }
    if (amount < 500) {
      lastWithdrawalError = 'Minimum withdrawal amount is ₹500.';
      notifyListeners();
      return false;
    }
    if (amount > lifetimeEarnings) {
      lastWithdrawalError = 'Insufficient balance for this withdrawal.';
      notifyListeners();
      return false;
    }
    lifetimeEarnings -= amount;
    lastWithdrawalError = null;
    notifyListeners();
    return true;
  }

  // ---------------- Online users (real Firestore directory) ----------------
  bool amIOnline = true;

  void toggleOnline(bool value) {
    amIOnline = value;
    notifyListeners();
    final uid = firebaseUser?.uid;
    if (uid != null) {
      FirebaseFirestore.instance.collection('users').doc(uid).update({
        'online': value,
        'lastSeen': FieldValue.serverTimestamp(),
      }).catchError((_) {});
    }
  }

  /// Populated live from Firestore once logged in (see [_listenOnlineUsers]).
  /// Starts empty — no more hardcoded fake profiles.
  final List<UserProfile> onlineUsers = [];

  // ---------------- Call state ----------------
  CallStage callStage = CallStage.none;
  UserProfile? currentPeer;
  CallType currentCallType = CallType.audio;
  int callSeconds = 0;
  double sessionCharge = 0;
  double sessionEarning = 0;

  Timer? _callTimer;

  final List<CallLogEntry> callHistory = [];

  /// Male user places an outgoing call to [peer].
  void startOutgoingCall(UserProfile peer, CallType type) {
    currentPeer = peer;
    currentCallType = type;
    callStage = CallStage.outgoingRinging;
    callSeconds = 0;
    sessionCharge = 0;
    notifyListeners();
  }

  /// Demo helper: female role previews what an incoming call looks like,
  /// since there is no live backend to originate a real one yet.
  void simulateIncomingCall(UserProfile caller, CallType type) {
    currentPeer = caller;
    currentCallType = type;
    callStage = CallStage.incomingRinging;
    callSeconds = 0;
    sessionEarning = 0;
    notifyListeners();
  }

  /// Called once the (simulated) other party accepts. Starts the
  /// per-second timer that drives per-minute billing.
  void connectCall() {
    callStage = CallStage.active;
    callSeconds = 0;
    _chargedSecondsThisSession = 0;
    _callTimer?.cancel();
    _callTimer = Timer.periodic(const Duration(seconds: 1), (_) => _onTick());
    notifyListeners();
  }

  void _onTick() {
    callSeconds++;

    if (role == UserRole.male) {
      if (freeSecondsRemaining > 0) {
        // Still inside the 30 free minutes — no charge, no ledger entry.
        freeSecondsRemaining--;
      } else {
        _chargedSecondsThisSession++;
        sessionCharge = (_chargedSecondsThisSession / 60.0) * callRatePerMinuteMale;
        if (walletBalance - sessionCharge <= 0) {
          walletBalance = 0;
          endCall();
          return;
        }
        // Apply the actual per-minute ledger entry every 60 charged
        // seconds, matching the PRD's billing rule (₹5/min charged).
        if (_chargedSecondsThisSession % 60 == 0) {
          walletBalance -= callRatePerMinuteMale;
          if (walletBalance < 0) walletBalance = 0;
          transactions.insert(
            0,
            WalletTransaction(
              title: 'Call — ${currentPeer?.name ?? ""}',
              subtitle: 'Just now',
              amount: -callRatePerMinuteMale,
              date: DateTime.now(),
              type: TransactionType.callCharge,
            ),
          );
          _syncWalletToFirestore();
          _logWalletTransaction(type: 'callCharge', amount: -callRatePerMinuteMale, note: currentPeer?.name);
        }
      }
    } else {
      sessionEarning = (callSeconds / 60.0) * earnRatePerMinuteFemale;
      if (callSeconds % 60 == 0) {
        todayEarnings += earnRatePerMinuteFemale;
        weekEarnings += earnRatePerMinuteFemale;
        monthEarnings += earnRatePerMinuteFemale;
        lifetimeEarnings += earnRatePerMinuteFemale;
      }
    }

    notifyListeners();
  }

  void endCall() {
    _callTimer?.cancel();
    if (currentPeer != null && callSeconds > 0) {
      callHistory.insert(
        0,
        CallLogEntry(
          peer: currentPeer!,
          type: currentCallType,
          outcome: CallOutcome.completed,
          durationSeconds: callSeconds,
          charge: role == UserRole.male ? sessionCharge : sessionEarning,
          timestamp: DateTime.now(),
        ),
      );
    }
    callStage = CallStage.ended;
    notifyListeners();
  }

  void resetCall() {
    _callTimer?.cancel();
    callStage = CallStage.none;
    currentPeer = null;
    callSeconds = 0;
    sessionCharge = 0;
    sessionEarning = 0;
    notifyListeners();
  }

  @override
  void dispose() {
    _callTimer?.cancel();
    _onlineUsersSub?.cancel();
    _kycSub?.cancel();
    _walletSub?.cancel();
    super.dispose();
  }
}
