import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Abstract gradient + initials placeholder avatar (no photos).
class AvatarCircle extends StatelessWidget {
  final String initial;
  final int colorIndex;
  final double size;
  final double fontSize;
  final BorderRadius? borderRadius;

  const AvatarCircle({
    super.key,
    required this.initial,
    this.colorIndex = 0,
    this.size = 48,
    this.fontSize = 20,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    final gradient = AppColors.avatarGradients[colorIndex % AppColors.avatarGradients.length];
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: borderRadius ?? BorderRadius.circular(size / 2),
      ),
      alignment: Alignment.center,
      child: Text(
        initial.toUpperCase(),
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: fontSize),
      ),
    );
  }
}
