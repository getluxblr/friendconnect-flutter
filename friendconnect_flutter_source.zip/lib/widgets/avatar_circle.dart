import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Abstract gradient placeholder avatar (no photos). Shows a male/female
/// icon when a gender is supplied (this is the normal case — every real
/// user profile has one), and falls back to the name's initial letter only
/// when gender is unknown.
class AvatarCircle extends StatelessWidget {
  final String initial;
  final int colorIndex;
  final double size;
  final double fontSize;
  final BorderRadius? borderRadius;
  final String? gender; // 'male' or 'female'

  const AvatarCircle({
    super.key,
    required this.initial,
    this.colorIndex = 0,
    this.size = 48,
    this.fontSize = 20,
    this.borderRadius,
    this.gender,
  });

  @override
  Widget build(BuildContext context) {
    final gradient = AppColors.avatarGradients[colorIndex % AppColors.avatarGradients.length];
    IconData? genderIcon;
    if (gender == 'male') {
      genderIcon = Icons.man_rounded;
    } else if (gender == 'female') {
      genderIcon = Icons.woman_rounded;
    }
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: borderRadius ?? BorderRadius.circular(size / 2),
      ),
      alignment: Alignment.center,
      child: genderIcon != null
          ? Icon(genderIcon, color: Colors.white, size: fontSize * 2.2)
          : Text(
              initial.toUpperCase(),
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: fontSize),
            ),
    );
  }
}
