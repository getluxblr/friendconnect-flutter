# FriendConnect — Flutter Demo Build

This is a working Flutter source project implementing the FriendConnect UI/UX
end to end: login (mock OTP), role selection, browsing online users, an
outgoing/incoming call flow with a live per-second timer, ₹5/min wallet
billing for male users, ₹1/min earnings for female users, wallet recharge,
withdrawals, call history, ratings, and a profile screen.

**This is a self-contained prototype, not the production app.** It proves out
every screen and the billing math with realistic mock data and simulated call
connection. It is **not** wired to a real backend, so it cannot yet:

- Place a real audio/video call between two different phones (needs a
  Socket.IO signaling server + WebRTC + a TURN/STUN server such as coturn)
- Verify a real OTP (needs Firebase Authentication)
- Process a real payment (needs a Razorpay merchant account + backend)
- Enforce real KYC / admin approval (needs the admin panel + backend + storage)

Those all require your own accounts/credentials and a hosted backend, which is
why they're left as clearly-marked integration points rather than faked in a
way that would look production-ready but isn't.

## Why there's no `android/` folder in this repo

Android builds need the Android Gradle Plugin and AndroidX libraries from
Google's Maven repository, plus the Flutter engine binaries — multi-hundred
MB of tooling this project was generated in an environment that couldn't
download. Rather than hand-write Gradle files that might drift out of sync
with whatever Flutter version you build with, this repo ships `lib/` +
`pubspec.yaml` only, and the `android/` (and `ios/`, `web/`, etc.) folders are
generated fresh by `flutter create`, guaranteed to match your toolchain.

## Fastest path: build the APK with GitHub Actions (no local setup)

1. Create a new GitHub repository and push this project's contents to it.
2. The included workflow at `.github/workflows/build-apk.yml` runs
   automatically on every push to `main` (or trigger it manually from the
   **Actions** tab → **Build APK** → **Run workflow**).
3. It installs Flutter, runs `flutter create --platforms=android .` to
   generate the Android project, then `flutter build apk --release`.
4. When the run finishes, open it and download the **friendconnect-apk**
   artifact — that's your installable `.apk`.

This needs nothing installed on your machine — GitHub's runners have full
internet access to fetch the Flutter SDK and Android build tools that this
sandbox couldn't reach.

## Building locally instead

If you have Flutter installed (`flutter doctor` should show no blocking
issues) and Android Studio / Android SDK set up:

```bash
cd friendconnect            # this project's folder
flutter create --platforms=android .   # generates android/ to match your Flutter version
flutter pub get
flutter build apk --release
# APK will be at: build/app/outputs/flutter-apk/app-release.apk
```

For a quicker debug build while iterating: `flutter build apk --debug` or
just `flutter run` with a device/emulator connected.

## What to wire up next for a real production build

- **Auth:** replace the mock OTP in `lib/screens/auth/otp_screen.dart` with
  Firebase Authentication (phone auth).
- **Calling:** implement `flutter_webrtc` + `socket_io_client` and connect to
  a NestJS/Socket.IO signaling server with a coturn TURN/STUN server. The
  simulated call flow in `lib/state/app_state.dart`
  (`startOutgoingCall` / `simulateIncomingCall` / `connectCall`) is the
  natural place to swap in real signaling events.
- **Payments:** integrate the `razorpay_flutter` package and a backend
  endpoint to create/verify orders; replace `AppState.recharge()`.
- **Backend:** the wallet, transactions, call history, and earnings currently
  live only in local memory (`AppState`) and reset when the app restarts —
  they need a real API + database (PostgreSQL, per the original spec) behind
  them.
- **KYC/Admin:** female verification, admin approval, and the admin panel
  itself are out of scope for a mobile client and need the backend + a
  separate React admin app.

## Project layout

```
lib/
  main.dart                 # app entry point, routes between login and home
  theme/app_theme.dart       # colors + ThemeData
  models/                    # UserProfile, WalletTransaction, CallLogEntry
  state/app_state.dart       # all in-memory demo logic (billing, calls, etc.)
  widgets/                   # shared building blocks (avatar, buttons, etc.)
  screens/
    auth/                    # login, OTP + role select
    home/                    # browse grid (male) / status dashboard (female)
    call/                    # outgoing, incoming, active call screens
    wallet/                  # male wallet + recharge
    earnings/                # female earnings dashboard + withdraw
    history/                 # call history + rating dialog
    profile/                 # profile + settings menu
```
