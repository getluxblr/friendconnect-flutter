import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../theme/app_theme.dart';
import '../../widgets/section_title.dart';
import '../../widgets/pill_button.dart';

class EarningsScreen extends StatelessWidget {
  const EarningsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    final maxBar = state.weeklyBars.reduce((a, b) => a > b ? a : b);

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('My Earnings', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textMain)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: AppColors.accent2.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                child: const Text('✓ KYC Verified', style: TextStyle(color: Color(0xFFC4B5FD), fontSize: 10, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.7,
            children: [
              _statCard('₹${state.todayEarnings.toStringAsFixed(0)}', "Today's Earnings"),
              _statCard('₹${state.weekEarnings.toStringAsFixed(0)}', 'This Week'),
              _statCard('₹${state.monthEarnings.toStringAsFixed(0)}', 'This Month'),
              _statCard('₹${state.lifetimeEarnings.toStringAsFixed(0)}', 'Lifetime'),
            ],
          ),
          const SectionTitle('Weekly Earnings'),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.divider)),
            child: SizedBox(
              height: 110,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: List.generate(7, (i) {
                  final h = 20 + (state.weeklyBars[i] / maxBar) * 70;
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                            height: h,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(colors: [AppColors.accent1, AppColors.accent2], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(days[i], style: const TextStyle(color: AppColors.textDim2, fontSize: 9)),
                        ],
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
          const SectionTitle('Withdraw'),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.divider)),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Available balance', style: TextStyle(fontSize: 12, color: AppColors.textDim2)),
                      Text('₹${state.lifetimeEarnings.toStringAsFixed(0)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.textMain)),
                      const Text('Min. withdrawal ₹500', style: TextStyle(fontSize: 10.5, color: AppColors.textDim2)),
                    ],
                  ),
                ),
                SizedBox(
                  width: 130,
                  child: PillButton(
                    label: 'Withdraw',
                    onTap: () {
                      final ok = state.requestWithdrawal(500);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(ok ? 'Withdrawal of ₹500 requested — pending admin approval' : 'Minimum withdrawal is ₹500')),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statCard(String val, String lbl) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: AppColors.bgCard, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.divider)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(val, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: AppColors.textMain)),
          const SizedBox(height: 2),
          Text(lbl, style: const TextStyle(fontSize: 10.5, color: AppColors.textDim2)),
        ],
      ),
    );
  }
}
