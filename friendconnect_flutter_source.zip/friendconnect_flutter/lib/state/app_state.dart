import 'dart:async';
import 'package:flutter/foundation.dart';

import '../models/user_model.dart';
import '../models/transaction_model.dart';
import '../models/call_log_model.dart';

enum UserRole { male, female }

enum CallStage { none, outgoingRinging, incomingRinging, active, ended }

/// Central in-memory state for the demo build.
///
/// NOTE: This drives a self-contained prototype. Real calling between two
/// separate devices requires a signaling server (Socket.IO), STUN/TURN
/// (coturn) and WebRTC peer connections on both ends — none of which exist
/// yet. The methods below simulate that flow locally (see
/// [startOutgoingCall], [simulateIncomingCall], [connectCall]) so every
/// screen and the per-minute billing logic can be demonstrated end-to-end.
class AppState extends ChangeNotifier {
  // ---------------- Auth ----------------
  bool isLoggedIn = false;
  String phoneNumber = '';
  UserRole role = UserRole.male;
  final String myName = 'Rahul';

  void loginWithPhone(String phone) {
    phoneNumber = phone;
    notifyListeners();
  }

  void verifyOtpAndSelectRole(UserRole selectedRole) {
    role = selectedRole;
    isLoggedIn = true;
    notifyListeners();
  }

  void logout() {
    isLoggedIn = false;
    notifyListeners();
  }

  // ---------------- Wallet (male) ----------------
  double walletBalance = 240.0;
  static const double callRatePerMinuteMale = 5.0;

  final List<WalletTransaction> transactions = [
    WalletTransaction(
      title: 'Call — Priya',
      subtitle: 'Today, 6:42 PM',
      amount: -65,
      date: DateTime.now(),
      type: TransactionType.callCharge,
    ),
    WalletTransaction(
      title: 'Recharge — UPI',
      subtitle: 'Today, 2:10 PM',
      amount: 500,
      date: DateTime.now(),
      type: TransactionType.recharge,
    ),
    WalletTransaction(
      title: 'Call — Sneha',
      subtitle: 'Yesterday, 9:05 PM',
      amount: -120,
      date: DateTime.now().subtract(const Duration(days: 1)),
      type: TransactionType.callCharge,
    ),
  ];

  void recharge(double amount, {double bonus = 0}) {
    walletBalance += amount + bonus;
    transactions.insert(
      0,
      WalletTransaction(
        title: 'Recharge — UPI',
        subtitle: 'Just now',
        amount: amount + bonus,
        date: DateTime.now(),
        type: TransactionType.recharge,
      ),
    );
    notifyListeners();
  }

  // ---------------- Earnings (female) ----------------
  double todayEarnings = 180;
  double weekEarnings = 1240;
  double monthEarnings = 4860;
  double lifetimeEarnings = 28400;
  static const double earnRatePerMinuteFemale = 1.0;
  final List<double> weeklyBars = [34, 52, 28, 68, 46, 80, 38];

  bool requestWithdrawal(double amount) {
    if (amount < 500 || amount > lifetimeEarnings) return false;
    lifetimeEarnings -= amount;
    notifyListeners();
    return true;
  }

  // ---------------- Online users (mock directory) ----------------
  bool amIOnline = true;

  void toggleOnline(bool value) {
    amIOnline = value;
    notifyListeners();
  }

  final List<UserProfile> onlineUsers = [
    UserProfile(id: '1', name: 'Priya', age: 24, language: 'Hindi', country: 'India', city: 'Mumbai', gender: 'female', avatarColorIndex: 0),
    UserProfile(id: '2', name: 'Anjali', age: 26, language: 'English', country: 'India', city: 'Delhi', gender: 'female', avatarColorIndex: 1),
    UserProfile(id: '3', name: 'Sneha', age: 23, language: 'Tamil', country: 'India', city: 'Chennai', gender: 'female', avatarColorIndex: 5),
    UserProfile(id: '4', name: 'Kavya', age: 25, language: 'Telugu', country: 'India', city: 'Hyderabad', gender: 'female', avatarColorIndex: 3),
    UserProfile(id: '5', name: 'Divya', age: 27, language: 'Kannada', country: 'India', city: 'Bengaluru', gender: 'female', avatarColorIndex: 2),
    UserProfile(id: '6', name: 'Meera', age: 22, language: 'Malayalam', country: 'India', city: 'Kochi', gender: 'female', avatarColorIndex: 4),
  ];

  // ---------------- Call state ----------------
  CallStage callStage = CallStage.none;
  UserProfile? currentPeer;
  CallType currentCallType = CallType.audio;
  int callSeconds = 0;
  double sessionCharge = 0;
  double sessionEarning = 0;

  Timer? _callTimer;

  final List<CallLogEntry> callHistory = [];

  /// Male user places an outgoing call to [peer].
  void startOutgoingCall(UserProfile peer, CallType type) {
    currentPeer = peer;
    currentCallType = type;
    callStage = CallStage.outgoingRinging;
    callSeconds = 0;
    sessionCharge = 0;
    notifyListeners();
  }

  /// Demo helper: female role previews what an incoming call looks like,
  /// since there is no live backend to originate a real one yet.
  void simulateIncomingCall(UserProfile caller, CallType type) {
    currentPeer = caller;
    currentCallType = type;
    callStage = CallStage.incomingRinging;
    callSeconds = 0;
    sessionEarning = 0;
    notifyListeners();
  }

  /// Called once the (simulated) other party accepts. Starts the
  /// per-second timer that drives per-minute billing.
  void connectCall() {
    callStage = CallStage.active;
    callSeconds = 0;
    _callTimer?.cancel();
    _callTimer = Timer.periodic(const Duration(seconds: 1), (_) => _onTick());
    notifyListeners();
  }

  void _onTick() {
    callSeconds++;

    if (role == UserRole.male) {
      sessionCharge = (callSeconds / 60.0) * callRatePerMinuteMale;
      if (walletBalance - sessionCharge <= 0) {
        walletBalance = 0;
        endCall();
        return;
      }
    } else {
      sessionEarning = (callSeconds / 60.0) * earnRatePerMinuteFemale;
    }

    // Apply the actual per-minute ledger entries every 60 seconds, matching
    // the PRD's billing rule (₹5/min charged, ₹1/min credited).
    if (callSeconds % 60 == 0) {
      if (role == UserRole.male) {
        walletBalance -= callRatePerMinuteMale;
        if (walletBalance < 0) walletBalance = 0;
        transactions.insert(
          0,
          WalletTransaction(
            title: 'Call — ${currentPeer?.name ?? ""}',
            subtitle: 'Just now',
            amount: -callRatePerMinuteMale,
            date: DateTime.now(),
            type: TransactionType.callCharge,
          ),
        );
      } else {
        todayEarnings += earnRatePerMinuteFemale;
        weekEarnings += earnRatePerMinuteFemale;
        monthEarnings += earnRatePerMinuteFemale;
        lifetimeEarnings += earnRatePerMinuteFemale;
      }
    }

    notifyListeners();
  }

  void endCall() {
    _callTimer?.cancel();
    if (currentPeer != null && callSeconds > 0) {
      callHistory.insert(
        0,
        CallLogEntry(
          peer: currentPeer!,
          type: currentCallType,
          outcome: CallOutcome.completed,
          durationSeconds: callSeconds,
          charge: role == UserRole.male ? sessionCharge : sessionEarning,
          timestamp: DateTime.now(),
        ),
      );
    }
    callStage = CallStage.ended;
    notifyListeners();
  }

  void resetCall() {
    _callTimer?.cancel();
    callStage = CallStage.none;
    currentPeer = null;
    callSeconds = 0;
    sessionCharge = 0;
    sessionEarning = 0;
    notifyListeners();
  }

  @override
  void dispose() {
    _callTimer?.cancel();
    super.dispose();
  }
}
